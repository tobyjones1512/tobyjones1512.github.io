"""
XTream Codes API client.
Handles authentication, channel listing, EPG retrieval, and stream URLs.
"""
import json
import logging
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from typing import Optional

import pytz
import requests
import urllib3
from dateutil import parser as dateutil_parser

# IPTV servers commonly use self-signed certs — suppress the noisy warning
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)
UK_TZ = pytz.timezone("Europe/London")
UTC = pytz.utc

CACHE_PATH = Path(__file__).parent / "data" / "channels_cache.json"


class XtreamClient:
    def __init__(self, host: str, username: str, password: str):
        self.host = host.rstrip("/")
        self.username = username
        self.password = password
        self._session = requests.Session()
        self._session.headers.update({"User-Agent": "Mozilla/5.0"})

    # ─── Internal ────────────────────────────────────────────────────────────

    def _api_url(self):
        return f"{self.host}/player_api.php"

    def _get(self, timeout=20, **params):
        p = {"username": self.username, "password": self.password, **params}
        resp = self._session.get(
            self._api_url(),
            params=p,
            timeout=timeout,
            verify=False,   # IPTV servers commonly use self-signed certs
            proxies={},     # bypass any macOS system proxy settings
        )
        resp.raise_for_status()
        return resp.json()

    # ─── Auth ─────────────────────────────────────────────────────────────────

    def authenticate(self):
        """Verify credentials and return server info."""
        data = self._get(timeout=10)
        if not isinstance(data, dict):
            raise ValueError("Unexpected response from server")
        if data.get("user_info", {}).get("auth") == 0:
            raise ValueError("Authentication failed — check username/password")
        return data

    def test_connection(self):
        try:
            data = self.authenticate()
            info = data.get("server_info", {})
            user = data.get("user_info", {})
            return True, {
                "server_url": info.get("server_url", self.host),
                "timezone": info.get("timezone", ""),
                "status": user.get("status", ""),
                "expiry": user.get("exp_date", ""),
                "max_connections": user.get("max_connections", ""),
                "active_connections": user.get("active_cons", ""),
            }
        except Exception as e:
            return False, str(e)

    # ─── Channels ─────────────────────────────────────────────────────────────

    def get_live_streams(self):
        """Return all live streams from the server."""
        return self._get(action="get_live_streams", timeout=60)

    def get_live_categories(self):
        """Return all live categories."""
        return self._get(action="get_live_categories", timeout=15)

    def get_stream_url(self, stream_id: int, fmt: str = "m3u8") -> str:
        return f"{self.host}/live/{self.username}/{self.password}/{stream_id}.{fmt}"

    # ─── VOD ──────────────────────────────────────────────────────────────────

    def get_vod_categories(self):
        """Return all VOD movie categories."""
        return self._get(action="get_vod_categories", timeout=15)

    def get_vod_streams(self, category_id=None):
        """Return VOD streams, optionally filtered by category_id."""
        extra = {"category_id": category_id} if category_id else {}
        return self._get(action="get_vod_streams", timeout=60, **extra)

    def get_vod_info(self, vod_id: int):
        """Return detailed info for a VOD item (plot, cast, streams, etc.)."""
        return self._get(action="get_vod_info", vod_id=vod_id, timeout=15)

    def get_vod_stream_url(self, stream_id: int, ext: str = "mp4") -> str:
        return f"{self.host}/movie/{self.username}/{self.password}/{stream_id}.{ext}"

    # ─── Series ───────────────────────────────────────────────────────────────

    def get_series_categories(self):
        """Return all series categories."""
        return self._get(action="get_series_categories", timeout=15)

    def get_series(self, category_id=None):
        """Return all series, optionally filtered by category_id."""
        extra = {"category_id": category_id} if category_id else {}
        return self._get(action="get_series", timeout=60, **extra)

    def get_series_info(self, series_id: int):
        """Return detailed info for a series including seasons and episodes."""
        return self._get(action="get_series_info", series_id=series_id, timeout=15)

    def get_series_stream_url(self, stream_id: int, ext: str = "mp4") -> str:
        return f"{self.host}/series/{self.username}/{self.password}/{stream_id}.{ext}"

    # ─── EPG ──────────────────────────────────────────────────────────────────

    def get_epg_for_stream(self, stream_id: int, limit: int = 20) -> list:
        """Return EPG listing for a single stream, normalised to UK time."""
        try:
            data = self._get(
                action="get_simple_epg_listing",
                stream_id=stream_id,
                limit=limit,
                timeout=15,
            )
            listings = data.get("epg_listings", [])
            return [self._normalise_epg_entry(e) for e in listings]
        except Exception as e:
            logger.warning(f"EPG fetch failed for stream {stream_id}: {e}")
            return []

    def get_epg_bulk(self, stream_ids: list, limit: int = 10) -> dict:
        """Fetch EPG for multiple streams. Returns dict stream_id → [entries]."""
        result = {}
        for sid in stream_ids:
            result[str(sid)] = self.get_epg_for_stream(sid, limit=limit)
        return result

    def _normalise_epg_entry(self, entry: dict) -> dict:
        """Parse XTream EPG entry and return standardised dict with UK times."""
        start = self._parse_epg_time(entry.get("start") or entry.get("start_timestamp"))
        end = self._parse_epg_time(entry.get("stop") or entry.get("end") or entry.get("stop_timestamp"))

        title = entry.get("title", "Unknown")
        # XTream sometimes base64-encodes titles
        if title and len(title) > 4:
            try:
                import base64
                decoded = base64.b64decode(title).decode("utf-8", errors="ignore")
                if decoded.isprintable():
                    title = decoded
            except Exception:
                pass

        description = entry.get("description", "") or entry.get("desc", "") or ""
        if description:
            try:
                import base64
                decoded = base64.b64decode(description).decode("utf-8", errors="ignore")
                if decoded.isprintable():
                    description = decoded
            except Exception:
                pass

        return {
            "title": title,
            "description": description,
            "start": start.isoformat() if start else None,
            "end": end.isoformat() if end else None,
            "start_uk": self._to_uk(start),
            "end_uk": self._to_uk(end),
        }

    def _parse_epg_time(self, value) -> Optional[datetime]:
        if value is None:
            return None
        if isinstance(value, (int, float)):
            return datetime.fromtimestamp(int(value), tz=UTC)
        if isinstance(value, str):
            try:
                # Format: "2024-01-20 21:00:00" (usually server local time, treat as UTC)
                dt = dateutil_parser.parse(value)
                if dt.tzinfo is None:
                    dt = UTC.localize(dt)
                return dt
            except Exception:
                return None
        return None

    def _to_uk(self, dt: Optional[datetime]) -> Optional[str]:
        if dt is None:
            return None
        return dt.astimezone(UK_TZ).isoformat()

    # ─── XMLTV ────────────────────────────────────────────────────────────────

    def get_xmltv_url(self) -> str:
        return f"{self.host}/xmltv.php?username={self.username}&password={self.password}"

    def fetch_epg_xmltv(self) -> dict:
        """Fetch the XMLTV feed and return {epg_channel_id: [normalised_entry]} dict.

        This gives much richer EPG data than the JSON API and covers the full
        broadcast day in one request.
        """
        url = self.get_xmltv_url()
        resp = self._session.get(
            url, timeout=120, verify=False, proxies={}, stream=True
        )
        resp.raise_for_status()

        root = ET.fromstring(resp.content)
        result: dict = {}

        for prog in root.findall("programme"):
            channel_id = prog.get("channel", "")
            if not channel_id:
                continue

            start = _parse_xmltv_time(prog.get("start", ""))
            stop  = _parse_xmltv_time(prog.get("stop", ""))

            title_el = prog.find("title")
            desc_el  = prog.find("desc")
            title       = (title_el.text or "").strip() if title_el is not None else "Unknown"
            description = (desc_el.text  or "").strip() if desc_el  is not None else ""

            entry = {
                "title":       title or "Unknown",
                "description": description,
                "start":       start.isoformat() if start else None,
                "end":         stop.isoformat()  if stop  else None,
                "start_uk":    self._to_uk(start),
                "end_uk":      self._to_uk(stop),
            }
            result.setdefault(channel_id, []).append(entry)

        return result


# ─── XMLTV time parser ────────────────────────────────────────────────────────

def _parse_xmltv_time(s: str) -> Optional[datetime]:
    """Parse XMLTV timestamp: '20240120210000 +0000' or '20240120210000 +0100'."""
    if not s:
        return None
    s = s.strip()
    try:
        if len(s) >= 14 and s[:14].isdigit():
            dt_part = s[:14]
            tz_part = s[14:].strip().replace(":", "")
            if not tz_part:
                tz_part = "+0000"
            dt = datetime.strptime(dt_part + tz_part, "%Y%m%d%H%M%S%z")
        else:
            dt = dateutil_parser.parse(s)
            if dt.tzinfo is None:
                dt = UTC.localize(dt)
        return dt.astimezone(UTC)
    except Exception:
        return None


# ─── Channel cache ────────────────────────────────────────────────────────────

def load_channel_cache():
    if CACHE_PATH.exists():
        try:
            return json.loads(CACHE_PATH.read_text())
        except Exception:
            return None
    return None


def save_channel_cache(channels: list):
    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    CACHE_PATH.write_text(json.dumps(channels, default=str))


def clear_channel_cache():
    """Delete the on-disk channel cache file if it exists."""
    try:
        if CACHE_PATH.exists():
            CACHE_PATH.unlink()
    except Exception:
        pass
