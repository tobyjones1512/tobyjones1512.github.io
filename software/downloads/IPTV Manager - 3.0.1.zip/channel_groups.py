"""
Channel grouping / deduplication.

Channels like "BBC One", "BBC One HD", "BBC ONE FHD" are merged into a single
ChannelGroup. The highest-quality variant is used as the default stream;
lower-quality variants are listed as alternatives.
"""
import re
from dataclasses import dataclass, field
from typing import List

# (regex pattern, quality label, rank)  — higher rank = better quality
QUALITY_PATTERNS = [
    (r"\b4K\b|\bUHD\b|\b2160[pi]?\b", "4K", 4),
    (r"\bFHD\b|\b1080[pi]?\b|\bFull\s*HD\b", "FHD", 3),
    (r"\bHD\b|\b720[pi]?\b", "HD", 2),
    (r"\bSD\b|\b576[pi]?\b|\b480[pi]?\b", "SD", 1),
]

# Suffixes to strip that don't indicate quality but clutter names
_STRIP_SUFFIXES = re.compile(
    r"[\s\-_|]+(H264|H265|HEVC|AAC|AC3|MPEG|HLS|RTMP|BACKUP|BAK|"
    r"MIRROR|RESCAN|TEST|NEW|V\d+|\d+MBPS?|STREAM\s*\d*)[\s\-_|]*$",
    re.IGNORECASE,
)


@dataclass
class ChannelVariant:
    stream_id: int
    name: str
    quality: str
    quality_rank: int
    group_title: str
    epg_channel_id: str
    stream_icon: str
    num: int

    def to_dict(self) -> dict:
        return {
            "stream_id": self.stream_id,
            "name": self.name,
            "quality": self.quality,
            "quality_rank": self.quality_rank,
        }


@dataclass
class ChannelGroup:
    normalized_name: str
    primary: ChannelVariant
    variants: List[ChannelVariant] = field(default_factory=list)

    @property
    def group_id(self) -> str:
        """URL-safe identifier for this group."""
        return re.sub(r"[^a-z0-9]+", "-", self.normalized_name.lower()).strip("-")

    @property
    def display_name(self) -> str:
        # Use the cleanest-looking name among variants
        # Prefer the name without quality suffixes if there are multiple variants
        if len(self.variants) > 1:
            return self.normalized_name.title() if self.normalized_name else self.primary.name
        return self.primary.name

    def to_dict(self) -> dict:
        return {
            "group_id": self.group_id,
            "display_name": self.display_name,
            "primary_stream_id": self.primary.stream_id,
            "epg_channel_id": self.primary.epg_channel_id,
            "stream_icon": self.primary.stream_icon,
            "group_title": self.primary.group_title,
            "num": self.primary.num,
            "variants": [v.to_dict() for v in self.variants],
            "has_multiple": len(self.variants) > 1,
        }


# ─── Public API ───────────────────────────────────────────────────────────────

def group_channels(channels: list) -> List[ChannelGroup]:
    """
    Take a flat list of XTream channel dicts and return grouped ChannelGroup
    objects, deduplicated by normalised name.
    """
    bucket: dict[str, list] = {}

    for ch in channels:
        raw_name = (ch.get("name") or "").strip()
        if not raw_name:
            continue

        normalized = _normalize_name(raw_name)
        if not normalized:
            normalized = raw_name

        quality, rank = _detect_quality(raw_name)

        variant = ChannelVariant(
            stream_id=int(ch.get("stream_id", 0)),
            name=raw_name,
            quality=quality,
            quality_rank=rank,
            group_title=ch.get("category_name") or ch.get("category_id") or "",
            epg_channel_id=ch.get("epg_channel_id") or "",
            stream_icon=ch.get("stream_icon") or "",
            num=int(ch.get("num") or 0),
        )

        bucket.setdefault(normalized, []).append(variant)

    groups: list[ChannelGroup] = []
    for normalized_name, variants in bucket.items():
        # Best quality first, then alphabetical
        variants.sort(key=lambda v: (-v.quality_rank, v.name.lower()))
        groups.append(
            ChannelGroup(
                normalized_name=normalized_name,
                primary=variants[0],
                variants=variants,
            )
        )

    # Sort by channel number of the primary variant
    groups.sort(key=lambda g: (g.primary.num, g.normalized_name.lower()))
    return groups


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _normalize_name(name: str) -> str:
    result = name

    # Strip trailing technical suffixes first
    result = _STRIP_SUFFIXES.sub("", result)

    # Treat pipe as a plain separator (e.g. "ITV | HD" → "ITV HD")
    result = re.sub(r"\s*\|\s*", " ", result).strip()

    # Strip quality indicators
    for pattern, _, _ in QUALITY_PATTERNS:
        result = re.sub(pattern, "", result, flags=re.IGNORECASE)

    # Strip trailing punctuation / separators
    result = re.sub(r"[\s\-_]+$", "", result)
    result = re.sub(r"^[\s\-_]+", "", result)
    result = result.strip()

    return result


def _detect_quality(name: str):
    for pattern, quality, rank in QUALITY_PATTERNS:
        if re.search(pattern, name, re.IGNORECASE):
            return quality, rank
    return "unknown", 0
