@echo off
setlocal enabledelayedexpansion

set "DIR=%~dp0"
set "DIR=%DIR:~0,-1%"
set "VENV=%DIR%\.venv"
set "LOG=%DIR%\data\install.log"
set "ERRORS=0"

if not exist "%DIR%\data" mkdir "%DIR%\data"

cls
echo.
echo   ==========================================
echo      IPTV Manager -- Windows Installer
echo   ==========================================
echo.
echo   This installer will set up everything needed to run IPTV Manager.
echo   Log: %LOG%
echo.
echo. > "%LOG%"

REM ── 1. Python 3.9+ ───────────────────────────────────────────────────────────
echo [1/5] Checking Python 3.9+...

python -c "import sys; exit(0 if sys.version_info >= (3,9) else 1)" >nul 2>&1
if errorlevel 1 (
    echo    ERROR: Python 3.9+ not found or version is too old.
    echo    Please download and install Python 3.11+ from:
    echo      https://www.python.org/downloads/
    echo    IMPORTANT: Check "Add Python to PATH" during installation.
    echo.
    set /a ERRORS+=1
    set "PY="
    goto :checkffmpeg
)

for /f "tokens=2" %%V in ('python --version 2^>^&1') do (
    echo    OK: Python %%V found
    set "PY=python"
)

:checkmpv
REM ── 2. mpv (video player) ────────────────────────────────────────────────────
echo.
echo [2/6] Checking mpv (video player)...

where mpv >nul 2>&1
if errorlevel 1 (
    echo    mpv not found - attempting to install via winget...
    winget install --id=mpv.mpv -e --accept-source-agreements --accept-package-agreements >nul 2>&1
    where mpv >nul 2>&1
    if errorlevel 1 (
        echo    WARNING: mpv could not be installed automatically.
        echo    Video playback will not work until mpv is installed.
        echo    Install manually from: https://mpv.io/installation/
        echo    After installing, add the mpv folder to your PATH.
        set /a ERRORS+=1
    ) else (
        echo    OK: mpv installed successfully
    )
) else (
    for /f "tokens=1,2" %%A in ('mpv --version 2^>^&1 ^| findstr /I "mpv"') do (
        echo    OK: %%A %%B
        goto :mpvdone
    )
    :mpvdone
)

:checkffmpeg
REM ── 3. FFmpeg + ffplay (full build with libx265) ──────────────────────────────
echo.
echo [3/6] Checking FFmpeg, ffplay + ffprobe ^(full build with libx265^)...

REM If mpv is NOT installed, reinstall FFmpeg to ensure ffplay (fallback player) is present.
where mpv >nul 2>&1
if errorlevel 1 (
    where ffmpeg >nul 2>&1
    if not errorlevel 1 (
        echo    mpv not found - reinstalling FFmpeg ^(full build^) to ensure ffplay is included...
        winget uninstall --id Gyan.FFmpeg.Shared --silent >nul 2>&1
        winget uninstall --id Gyan.FFmpeg --silent >nul 2>&1
        winget install --id Gyan.FFmpeg.Shared -e --accept-source-agreements --accept-package-agreements >nul 2>&1
    )
)

where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo    FFmpeg not found - installing full build via winget ^(includes libx265^)...
    winget install --id Gyan.FFmpeg.Shared -e --accept-source-agreements --accept-package-agreements >nul 2>&1
    where ffmpeg >nul 2>&1
    if errorlevel 1 (
        echo    WARNING: FFmpeg could not be installed automatically.
        echo    FFmpeg is required for recording and downloading. Install options:
        echo      Option A - winget ^(full^): winget install --id Gyan.FFmpeg.Shared -e
        echo      Option B - Chocolatey:    choco install ffmpeg
        echo      Option C - Manual:        https://www.gyan.dev/ffmpeg/builds/
        echo    Download the "full_build" or "essentials+x265" ZIP and add bin\ to PATH.
        set /a ERRORS+=1
    ) else (
        for /f "tokens=1,2,3" %%A in ('ffmpeg -version 2^>^&1 ^| findstr /I "ffmpeg version"') do (
            echo    OK: %%A %%B %%C
        )
    )
) else (
    for /f "tokens=1,2,3" %%A in ('ffmpeg -version 2^>^&1 ^| findstr /I "ffmpeg version"') do (
        echo    OK: %%A %%B %%C
    )
)

where ffprobe >nul 2>&1
if errorlevel 1 (
    echo    WARNING: ffprobe not found ^(part of FFmpeg - check your FFmpeg installation^)
    set /a ERRORS+=1
) else (
    echo    OK: ffprobe found
)

where ffplay >nul 2>&1
if errorlevel 1 (
    echo    WARNING: ffplay not found ^(part of FFmpeg - check your FFmpeg installation^)
    set /a ERRORS+=1
) else (
    echo    OK: ffplay found
)

REM Check libx265 is available in this FFmpeg build
where ffmpeg >nul 2>&1
if not errorlevel 1 (
    ffmpeg -encoders 2>nul | findstr /I "libx265" >nul 2>&1
    if errorlevel 1 (
        echo    WARNING: libx265 encoder not found in this FFmpeg build.
        echo    HEVC recording quality will not work.
        echo    Install the full build: winget install --id Gyan.FFmpeg.Shared -e
        echo    Or download from: https://www.gyan.dev/ffmpeg/builds/
        set /a ERRORS+=1
    ) else (
        echo    OK: libx265 ^(HEVC encoder^) found
    )
)

REM ── 4. Virtual environment ───────────────────────────────────────────────────
echo.
echo [4/6] Creating Python virtual environment...

if not defined PY (
    echo    SKIPPED: Python not found. Fix Python installation first.
    goto :done
)

if exist "%VENV%" (
    echo    Removing existing virtual environment...
    rmdir /s /q "%VENV%" >> "%LOG%" 2>&1
)

%PY% -m venv "%VENV%" >> "%LOG%" 2>&1
if errorlevel 1 (
    echo    ERROR: Failed to create virtual environment.
    echo    Check %LOG% for details.
    set /a ERRORS+=1
    goto :done
)

if not exist "%VENV%\Scripts\python.exe" (
    echo    ERROR: Virtual environment created but python.exe not found.
    set /a ERRORS+=1
    goto :done
)

echo    OK: Virtual environment created at .venv\

REM ── 4. Python dependencies ───────────────────────────────────────────────────
echo.
echo [5/6] Installing Python dependencies...
echo    Installing: flask, requests, APScheduler, pytz, python-dateutil, pystray, Pillow...

"%VENV%\Scripts\pip" install --upgrade pip setuptools wheel -q >> "%LOG%" 2>&1
"%VENV%\Scripts\pip" install -r "%DIR%\requirements.txt" >> "%LOG%" 2>&1
if errorlevel 1 (
    echo    ERROR: Failed to install dependencies.
    echo    Check %LOG% for details.
    set /a ERRORS+=1
    goto :initdb
)

REM Verify critical packages
for %%P in (flask requests apscheduler pytz dateutil pystray PIL) do (
    "%VENV%\Scripts\python" -c "import %%P" >nul 2>&1
    if errorlevel 1 (
        echo    WARNING: Package '%%P' failed to import -- check %LOG%
        set /a ERRORS+=1
    ) else (
        echo    OK: %%P
    )
)

REM ── 5. Initialise database ───────────────────────────────────────────────────
:initdb
echo.
echo [6/6] Initialising database...

"%VENV%\Scripts\python" -c "import sys, os; sys.path.insert(0, r'%DIR%'); os.chdir(r'%DIR%'); import database; database.init_db(); print('Database OK')" >> "%LOG%" 2>&1
if errorlevel 1 (
    echo    WARNING: Database initialisation may have failed. Check %LOG%.
    set /a ERRORS+=1
) else (
    echo    OK: Database initialised at data\iptv_manager.db
)

REM ── Done ─────────────────────────────────────────────────────────────────────
:done
echo.
echo   ==========================================
if !ERRORS! equ 0 (
    echo      Installation complete!
) else (
    echo      Installation finished with !ERRORS! warning^(s^).
    echo      Check the log for details: %LOG%
)
echo   ==========================================
echo.
echo   To launch IPTV Manager:
echo     - Double-click "Start IPTV Manager.bat"
echo     - Look for the TV icon in your system tray
echo     - Or open http://localhost:5001 in your browser
echo.
if !ERRORS! gtr 0 (
    echo   Log file: %LOG%
    echo.
)
pause
