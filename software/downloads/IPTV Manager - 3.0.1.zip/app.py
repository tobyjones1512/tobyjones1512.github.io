#!/usr/bin/env python3
"""
IPTV Manager - XTream Codes web UI for macOS.

Run:  python app.py
Then open:  http://localhost:5001
"""
import json
import logging
import os
import sys
import shutil
import subprocess
import tempfile
import threading
import time
import uuid
import webbrowser
from datetime import datetime, timedelta
from pathlib import Path

import pytz
import requests
from dateutil import parser as dateutil_parser
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.date import DateTrigger
from apscheduler.triggers.interval import IntervalTrigger
from flask import Flask, jsonify, render_template, request, Response, send_file

import database as db
import recorder
from channel_groups import group_channels
from xtream import XtreamClient, load_channel_cache, save_channel_cache, clear_channel_cache

# ─── Version ──────────────────────────────────────────────────────────────────

UPDATE_CSV_URL = "https://tobyjones.ca/software/downloads/iptv-manager-versions.csv"


def _read_version() -> str:
    try:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "version.txt")
        return open(p).read().strip()
    except Exception:
        return "0.0.0"


def _parse_version(v: str) -> tuple:
    try:
        return tuple(int(x) for x in v.strip().split("."))
    except Exception:
        return (0,)


APP_VERSION = _read_version()


# ─── Setup ────────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

UTC = pytz.utc


def get_recording_tz():
    """Return the pytz timezone configured for recording times."""
    tz_name = db.get_settings().get("timezone", "Europe/London")
    if tz_name == "local":
        try:
            import tzlocal
            return tzlocal.get_localzone()
        except Exception:
            pass
    try:
        return pytz.timezone(tz_name)
    except Exception:
        return pytz.timezone("Europe/London")

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False

# Register RFC 8216 compliant MIME type for HLS playlists
import mimetypes as _mt
_mt.add_type("application/vnd.apple.mpegurl", ".m3u8")

# ─── Trial mode ───────────────────────────────────────────────────────────────
_TRIAL_FLAG           = Path(__file__).parent / "data" / "trial.flag"
_TRIAL_LIMIT          = 2          # max recordings
_TRIAL_MAX_DURATION   = 1800       # 30 minutes per recording (seconds)
_TRIAL_STREAM_LIMIT   = 5          # max concurrent live streams
_TRIAL_STREAM_DURATION = 1800      # 30 minutes per live stream (seconds)
_TRIAL_BUY_URL        = "https://tobyjones.ca/software"

# Active live-stream processes (trial mode only): key -> subprocess.Popen
_trial_streams: dict = {}
_trial_streams_lock = threading.Lock()


def _trial_stream_count() -> int:
    """Return number of currently running trial live streams, pruning dead ones."""
    with _trial_streams_lock:
        dead = [k for k, p in _trial_streams.items() if p.poll() is not None]
        for k in dead:
            del _trial_streams[k]
        return len(_trial_streams)

def _is_trial() -> bool:
    return _TRIAL_FLAG.exists()

def _trial_recording_count() -> int:
    """Count recordings that were not cancelled (they consumed a trial slot)."""
    recs = db.get_all_recordings()
    return sum(1 for r in recs if r.get("status") not in ("cancelled",))

scheduler = BackgroundScheduler(timezone="Europe/London")

# Global XTream client (refreshed when settings change)
_xtream_lock = threading.Lock()
_xtream_client = None

# In-memory channel groups cache
_channel_groups_cache = None
_channel_groups_lock = threading.Lock()

# XMLTV EPG cache  {epg_channel_id: [entry, ...]}
_xmltv_cache: dict = {}
_xmltv_cache_lock = threading.Lock()
_xmltv_last_fetch = None   # datetime or None

# Persistent XMLTV cache on disk (survives server restarts)
_XMLTV_DISK_PATH = Path(__file__).parent / "data" / "xmltv_cache.json"

def _persist_xmltv():
    """Save the current XMLTV cache to disk."""
    try:
        _XMLTV_DISK_PATH.parent.mkdir(parents=True, exist_ok=True)
        with _xmltv_cache_lock:
            payload = {
                "last_fetch": _xmltv_last_fetch.isoformat() if _xmltv_last_fetch else None,
                "cache": _xmltv_cache,
            }
        _XMLTV_DISK_PATH.write_text(json.dumps(payload, default=str))
    except Exception as e:
        logger.warning(f"Could not persist XMLTV cache: {e}")

def _restore_xmltv():
    """Load XMLTV cache from disk on startup."""
    global _xmltv_cache, _xmltv_last_fetch
    try:
        if not _XMLTV_DISK_PATH.exists():
            return
        payload = json.loads(_XMLTV_DISK_PATH.read_text())
        with _xmltv_cache_lock:
            _xmltv_cache = payload.get("cache", {})
            lf = payload.get("last_fetch")
            _xmltv_last_fetch = datetime.fromisoformat(lf) if lf else None
        logger.info(f"Restored XMLTV cache from disk ({len(_xmltv_cache)} channels)")
    except Exception as e:
        logger.warning(f"Could not restore XMLTV cache: {e}")

# Active downloads tracker  {dl_id: {title, filepath, proc, progress_file, total_secs, status}}
_active_downloads: dict = {}
_downloads_lock = threading.Lock()

# Active transcodes tracker  {rec_id: {title, codec, proc, progress_file, status}}
_active_transcodes: dict = {}
_transcodes_lock = threading.Lock()


# ─── XTream client management ────────────────────────────────────────────────

def get_xtream_client():
    global _xtream_client
    with _xtream_lock:
        if _xtream_client:
            return _xtream_client
        settings = db.get_settings()
        host = settings.get("xtream_host", "")
        user = settings.get("xtream_username", "")
        pwd = settings.get("xtream_password", "")
        if host and user and pwd:
            _xtream_client = XtreamClient(host, user, pwd)
        return _xtream_client


def refresh_xtream_client():
    global _xtream_client
    with _xtream_lock:
        settings = db.get_settings()
        host = settings.get("xtream_host", "")
        user = settings.get("xtream_username", "")
        pwd = settings.get("xtream_password", "")
        if host and user and pwd:
            _xtream_client = XtreamClient(host, user, pwd)
        else:
            _xtream_client = None


def get_channel_groups(force_refresh: bool = False):
    global _channel_groups_cache
    with _channel_groups_lock:
        if _channel_groups_cache and not force_refresh:
            return _channel_groups_cache

        client = get_xtream_client()
        if not client:
            return []

        try:
            # Fetch category names and build an id→name map
            try:
                cats = client.get_live_categories()
                cat_map = {str(c["category_id"]): c.get("category_name", "")
                           for c in cats if c.get("category_id")}
            except Exception:
                cat_map = {}

            channels = client.get_live_streams()
            # Inject the human-readable category name into each stream dict
            for ch in channels:
                cid = str(ch.get("category_id", ""))
                if cid and cid in cat_map:
                    ch["category_name"] = cat_map[cid]

            groups = group_channels(channels)
            _channel_groups_cache = [g.to_dict() for g in groups]
            save_channel_cache(_channel_groups_cache)
            return _channel_groups_cache
        except Exception as e:
            logger.error(f"Channel refresh failed: {e}")
            # Fall back to disk cache
            cached = load_channel_cache()
            if cached:
                _channel_groups_cache = cached
                return cached
            return []


# ─── Recording scheduler jobs ─────────────────────────────────────────────────

def _find_existing_occurrence(template_id: str, occurrence_start: datetime) -> str | None:
    """Return the ID of an active (non-terminal) child occurrence whose
    start_time is within ±1 hour of *occurrence_start*, or None.

    Used to prevent duplicate occurrence rows when both a pre-created
    DateTrigger child and the recurring CronTrigger fire around the same time,
    or when the server is restarted mid-day.
    """
    window_start = (occurrence_start - timedelta(hours=1)).isoformat()
    window_end   = (occurrence_start + timedelta(hours=1)).isoformat()
    with db.get_db() as conn:
        row = conn.execute(
            """
            SELECT id FROM recordings
            WHERE parent_id = ?
              AND start_time >= ? AND start_time <= ?
              AND status NOT IN ('completed', 'failed', 'cancelled')
            LIMIT 1
            """,
            (template_id, window_start, window_end),
        ).fetchone()
    return row["id"] if row else None


def _spawn_occurrence(template: dict) -> str | None:
    """Create a new one-time recording row for this firing of a recurring schedule.

    The recurring template row is never modified here (its status stays
    'recurring' permanently).  The spawned child row owns the full
    scheduled → recording → completed/failed lifecycle for this single
    occurrence, keeping history clean.

    Returns the new recording's ID, or None if spawning failed.
    """
    now_dt        = datetime.now(UTC)
    padding_start = int(template.get("padding_start") or 0)

    # Nominal start for this occurrence = job fire time + pre-roll padding
    occurrence_start = now_dt + timedelta(minutes=padding_start)

    # ── Dedup guard ───────────────────────────────────────────────────────────
    # _check_immediate_occurrence may have already pre-created a child for today;
    # if so, reuse it rather than spawning a duplicate.
    existing_id = _find_existing_occurrence(template["id"], occurrence_start)
    if existing_id:
        logger.info(
            f"_spawn_occurrence: reusing pre-created occurrence {existing_id} "
            f"for template {template['id']} ({template['show_name']})"
        )
        return existing_id
    # ─────────────────────────────────────────────────────────────────────────

    # Duration comes from the template's original time window
    try:
        tmpl_start = dateutil_parser.parse(template["start_time"])
        tmpl_end   = dateutil_parser.parse(template["end_time"])
        if tmpl_start.tzinfo is None:
            tmpl_start = UTC.localize(tmpl_start)
        if tmpl_end.tzinfo is None:
            tmpl_end = UTC.localize(tmpl_end)
        base_duration = tmpl_end - tmpl_start
        if base_duration.total_seconds() <= 0:
            base_duration = timedelta(hours=1)
    except Exception:
        base_duration = timedelta(hours=1)

    occurrence_end = occurrence_start + base_duration

    # Grab the current episode number before incrementing the template
    current_episode = int(template.get("episode") or 1)
    db.update_recording_episode(template["id"], current_episode + 1)

    occ_id = str(uuid.uuid4())
    occurrence = {
        "id":           occ_id,
        "type":         "once",
        "channel_id":   template["channel_id"],
        "channel_name": template["channel_name"],
        "show_name":    template["show_name"],
        "season":       int(template.get("season") or 1),
        "episode":      current_episode,
        "save_path":    template["save_path"],
        "quality":      template["quality"],
        "start_time":   occurrence_start.isoformat(),
        "end_time":     occurrence_end.isoformat(),
        "status":       "scheduled",
        "recurrence":   None,
        "output_file":  None,
        "created_at":   now_dt.isoformat(),
        "scheduler_id": None,
        "padding_start": int(template.get("padding_start") or 0),
        "padding_end":   int(template.get("padding_end")   or 0),
        "paused_until":  None,
        "parent_id":     template["id"],
    }

    try:
        db.save_recording(occurrence)
        logger.info(
            f"Spawned occurrence {occ_id} (ep {current_episode}) "
            f"for recurring template {template['id']} ({template['show_name']})"
        )
        return occ_id
    except Exception as e:
        logger.error(f"Failed to spawn occurrence for {template['id']}: {e}")
        return None


def _check_immediate_occurrence(template: dict):
    """If today is a scheduled recording day and the trigger time is still in
    the future, pre-create a *status="scheduled"* child occurrence so it
    appears in the UI straight away (rather than only appearing when the cron
    fires).

    The CronTrigger will later call _spawn_occurrence which finds the
    pre-created child via _find_existing_occurrence and reuses it — no
    duplicate or race condition.
    """
    recurrence = template.get("recurrence")
    if not recurrence:
        return

    # Respect pause state
    paused_until = template.get("paused_until")
    if paused_until:
        try:
            pu_dt = dateutil_parser.parse(paused_until)
            if pu_dt.tzinfo is None:
                pu_dt = UTC.localize(pu_dt)
            if datetime.now(UTC) < pu_dt:
                return
        except Exception:
            pass

    rec_tz   = get_recording_tz()
    now_utc  = datetime.now(UTC)
    today_local = now_utc.astimezone(rec_tz)
    today_dow   = today_local.weekday()   # 0=Mon … 6=Sun

    # ── Determine scheduled days and nominal start time ───────────────────────
    if "days" in recurrence:
        # New format: {days: [0-6, ...], time_start: "HH:MM", time_end: "HH:MM"}
        scheduled_days = [int(d) for d in recurrence.get("days", list(range(7)))]
        time_str       = recurrence.get("time_start", "21:00")
    else:
        # Legacy format: {pattern: "...", time: "HH:MM", day_of_week: N}
        pattern  = recurrence.get("pattern", "weekly")
        time_str = recurrence.get("time", "21:00")
        if pattern == "daily":
            scheduled_days = list(range(7))
        elif pattern == "weekly":
            scheduled_days = [int(recurrence.get("day_of_week", 0))]
        elif pattern == "weekdays":
            scheduled_days = [0, 1, 2, 3, 4]
        elif pattern == "weekends":
            scheduled_days = [5, 6]
        else:
            scheduled_days = list(range(7))

    if today_dow not in scheduled_days:
        return   # not scheduled to fire today

    # ── Compute today's occurrence start in UTC ───────────────────────────────
    try:
        hour, minute = (int(x) for x in time_str.split(":"))
        # Build a naive local datetime from today's date + scheduled time, then
        # localise properly (handles DST correctly).
        naive_dt = today_local.replace(
            hour=hour, minute=minute, second=0, microsecond=0, tzinfo=None
        )
        occurrence_start_utc = rec_tz.localize(naive_dt).astimezone(UTC)
    except Exception as e:
        logger.warning(f"_check_immediate_occurrence: bad time_str '{time_str}': {e}")
        return

    padding_start = int(template.get("padding_start") or 0)
    trigger_time  = occurrence_start_utc - timedelta(minutes=padding_start)

    if trigger_time <= now_utc:
        # Trigger already passed today — the cron will handle it (or it's done)
        return

    # ── Skip if a matching occurrence already exists ──────────────────────────
    if _find_existing_occurrence(template["id"], occurrence_start_utc):
        return

    # ── Compute duration from template's stored window ───────────────────────
    try:
        tmpl_start = dateutil_parser.parse(template["start_time"])
        tmpl_end   = dateutil_parser.parse(template["end_time"])
        if tmpl_start.tzinfo is None: tmpl_start = UTC.localize(tmpl_start)
        if tmpl_end.tzinfo is None:   tmpl_end   = UTC.localize(tmpl_end)
        base_duration = tmpl_end - tmpl_start
        if base_duration.total_seconds() <= 0:
            base_duration = timedelta(hours=1)
    except Exception:
        base_duration = timedelta(hours=1)

    occurrence_end_utc = occurrence_start_utc + base_duration

    # ── Increment episode on template and create child occurrence ─────────────
    current_episode = int(template.get("episode") or 1)
    db.update_recording_episode(template["id"], current_episode + 1)

    occ_id = str(uuid.uuid4())
    occurrence = {
        "id":           occ_id,
        "type":         "once",
        "channel_id":   template["channel_id"],
        "channel_name": template["channel_name"],
        "show_name":    template["show_name"],
        "season":       int(template.get("season") or 1),
        "episode":      current_episode,
        "save_path":    template["save_path"],
        "quality":      template["quality"],
        "start_time":   occurrence_start_utc.isoformat(),
        "end_time":     occurrence_end_utc.isoformat(),
        "status":       "scheduled",
        "recurrence":   None,
        "output_file":  None,
        "created_at":   now_utc.isoformat(),
        "scheduler_id": None,
        "padding_start": int(template.get("padding_start") or 0),
        "padding_end":   int(template.get("padding_end")   or 0),
        "paused_until":  None,
        "parent_id":     template["id"],
    }

    try:
        db.save_recording(occurrence)
        logger.info(
            f"_check_immediate_occurrence: pre-created occurrence {occ_id} "
            f"(ep {current_episode}) for '{template['show_name']}', "
            f"trigger at {trigger_time.isoformat()}"
        )
    except Exception as e:
        logger.error(f"_check_immediate_occurrence: failed to save occurrence: {e}")


def _do_recording(rec_id: str):
    """APScheduler job: start the FFmpeg process for a scheduled recording.

    For recurring templates the job fires here but we never record onto the
    template row itself.  Instead we spawn a fresh one-time child row for this
    occurrence and proceed using that child's ID.  The template's status
    therefore stays 'recurring' indefinitely, giving a clean history of
    individual completed recordings alongside the standing schedule.
    """
    rec = db.get_recording(rec_id)
    if not rec:
        logger.warning(f"Recording {rec_id} not found in DB")
        return

    if rec["status"] not in ("scheduled", "recurring"):
        logger.info(f"Recording {rec_id} status={rec['status']}, skipping")
        return

    # Check if paused (always against the template / original record)
    paused_until = rec.get("paused_until")
    if paused_until:
        try:
            paused_dt = dateutil_parser.parse(paused_until)
            if paused_dt.tzinfo is None:
                paused_dt = UTC.localize(paused_dt)
            if datetime.now(UTC) < paused_dt:
                logger.info(f"Recording {rec_id} is paused until {paused_until}, skipping")
                return
        except Exception:
            pass

    # ── Recurring template: spawn a child occurrence and work on that ─────────
    if rec.get("recurrence"):
        child_id = _spawn_occurrence(rec)
        if not child_id:
            logger.error(f"Could not spawn occurrence for recurring {rec_id}, skipping")
            return
        rec_id = child_id
        rec = db.get_recording(rec_id)
        if not rec:
            return
    # ─────────────────────────────────────────────────────────────────────────

    client = get_xtream_client()
    if not client:
        logger.error("No XTream client - cannot start recording")
        db.update_recording_status(rec_id, "failed")
        return

    # Determine stream ID: use primary or a specific variant
    channel_id = rec.get("channel_id")
    if not channel_id:
        logger.error(f"Recording {rec_id} has no channel_id")
        db.update_recording_status(rec_id, "failed")
        return

    stream_url = client.get_stream_url(int(channel_id))

    # Calculate duration, including any padding
    padding_start = int(rec.get("padding_start") or 0)
    padding_end   = int(rec.get("padding_end")   or 0)
    start_str = rec["start_time"]
    end_str   = rec["end_time"]
    try:
        start_dt = dateutil_parser.parse(start_str)
        end_dt   = dateutil_parser.parse(end_str)
        # padding_start is already baked into the trigger time (job fires early),
        # so total duration = programme duration + both padding values
        duration_secs = int((end_dt - start_dt).total_seconds())
        duration_secs += (padding_start + padding_end) * 60
    except Exception:
        duration_secs = None

    # Trial: cap recording duration at 30 minutes
    if _is_trial() and duration_secs is not None:
        duration_secs = min(duration_secs, _TRIAL_MAX_DURATION)
    elif _is_trial() and duration_secs is None:
        duration_secs = _TRIAL_MAX_DURATION

    # Resolve output path
    epg_title = ""  # Could pass from EPG if available
    output_path = recorder.build_output_path(
        save_path=rec["save_path"],
        show_name=rec["show_name"],
        season=rec["season"],
        episode=rec["episode"],
        quality=rec["quality"],
        title=epg_title,
    )

    db.update_recording_status(rec_id, "recording", output_path)

    try:
        recorder.start_recording(
            recording_id=rec_id,
            stream_url=stream_url,
            output_path=output_path,
            duration_seconds=duration_secs,
            quality=rec["quality"],
        )
        # Schedule a follow-up to mark completion
        if duration_secs:
            run_at = datetime.now(UTC) + timedelta(seconds=duration_secs + 60)
            scheduler.add_job(
                _finish_recording,
                trigger=DateTrigger(run_date=run_at),
                args=[rec_id],
                id=f"finish_{rec_id}",
                replace_existing=True,
            )
    except Exception as e:
        logger.error(f"Failed to start recording {rec_id}: {e}")
        db.update_recording_status(rec_id, "failed")


def _on_recording_finished(rec_id: str):
    """Central completion handler: start transcode or mark completed.

    Called from both the APScheduler job (_finish_recording) and the sweep
    path in api_list_recordings. Guards against double-execution via the
    status check — only acts when status is still 'recording'.
    """
    rec = db.get_recording(rec_id)
    if not rec or rec["status"] != "recording":
        return  # already handled (sweep ran before scheduler, or vice versa)

    q = rec.get("quality") or {}
    if q.get("transcode_after") and rec.get("output_file"):
        db.update_recording_status(rec_id, "transcoding")
        t = threading.Thread(target=_do_transcode, args=[rec_id], daemon=True,
                             name=f"transcode-{rec_id[:8]}")
        t.start()
    else:
        db.update_recording_status(rec_id, "completed")


def _finish_recording(rec_id: str):
    """APScheduler job: stop the watchdog and trigger completion logic.

    rec_id here is always the child occurrence record (never the recurring
    template), so there is nothing recurring-specific to handle — episode
    counters were already incremented when the occurrence was spawned.
    """
    recorder.stop_recording(rec_id)
    _on_recording_finished(rec_id)


def _do_transcode(rec_id: str):
    """Background: transcode a completed copy recording to the target codec."""
    rec = db.get_recording(rec_id)
    if not rec or not rec.get("output_file"):
        return

    src = rec["output_file"]
    for _ in range(60):
        if os.path.exists(src):
            break
        time.sleep(1)
    if not os.path.exists(src):
        logger.error(f"Transcode {rec_id}: source file not found after 60s: {src}")
        db.update_recording_status(rec_id, "completed")
        return

    q = rec.get("quality") or {}
    transcode_quality = {
        "codec":      q.get("transcode_codec", "hevc"),
        "resolution": q.get("transcode_resolution", "1920x1080"),
        "crf":        int(q.get("transcode_crf", 18)),
        "preset":     q.get("transcode_preset", "medium"),
        "audio_codec": "aac",
    }

    src_path = Path(src)
    tmp_path   = src_path.with_name(src_path.stem + ".transcoding.tmp.mkv")
    final_path = src_path.with_name(src_path.stem + " - transcoded.mkv")
    progress_file = os.path.join(tempfile.gettempdir(), f"iptv_tc_{rec_id[:8]}.txt")

    logger.info(f"Transcode {rec_id}: {src} -> {transcode_quality['codec'].upper()}")
    cmd = recorder._build_command(src, str(tmp_path), None, transcode_quality)
    # Insert -progress and -nostats before the output path (last element)
    cmd = cmd[:-1] + ["-progress", progress_file, "-nostats", cmd[-1]]

    new_output_file = None
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        with _transcodes_lock:
            _active_transcodes[rec_id] = {
                "title":         rec.get("show_name", "Recording"),
                "codec":         transcode_quality["codec"].upper(),
                "proc":          proc,
                "progress_file": progress_file,
                "status":        "transcoding",
            }

        proc.wait()

        if proc.returncode == 0 and tmp_path.exists():
            os.replace(str(tmp_path), str(final_path))
            new_output_file = str(final_path)
            logger.info(f"Transcode {rec_id}: completed -> {final_path.name}")
            try:
                Path(src).unlink(missing_ok=True)
            except Exception:
                pass
            with _transcodes_lock:
                if rec_id in _active_transcodes:
                    _active_transcodes[rec_id]["status"] = "done"
        else:
            tmp_path.unlink(missing_ok=True)
            with _transcodes_lock:
                if rec_id in _active_transcodes and _active_transcodes[rec_id]["status"] != "cancelled":
                    logger.error(f"Transcode {rec_id} failed (rc={proc.returncode})")
                    _active_transcodes[rec_id]["status"] = "error"
    except Exception as e:
        logger.error(f"Transcode {rec_id} exception: {e}")
        tmp_path.unlink(missing_ok=True)
        with _transcodes_lock:
            if rec_id in _active_transcodes:
                _active_transcodes[rec_id]["status"] = "error"
    finally:
        db.update_recording_status(rec_id, "completed", new_output_file)



def _schedule_recording(rec: dict):
    """Register a recording with APScheduler."""
    rec_id        = rec["id"]
    padding_start = int(rec.get("padding_start") or 0)
    rec_tz        = get_recording_tz()

    start_dt = dateutil_parser.parse(rec["start_time"])
    if start_dt.tzinfo is None:
        start_dt = rec_tz.localize(start_dt)

    # Fire the job early so the pre-roll padding is captured
    trigger_dt = start_dt - timedelta(minutes=padding_start)

    recurrence = rec.get("recurrence")

    if recurrence:
        # For recurring jobs the cron time already encodes the user's desired
        # start; shift it back by padding_start so FFmpeg rolls early.
        trigger = _build_cron_trigger(recurrence, offset_minutes=-padding_start)
        scheduler.add_job(
            _do_recording,
            trigger=trigger,
            args=[rec_id],
            id=f"rec_{rec_id}",
            replace_existing=True,
            misfire_grace_time=300,
        )
    else:
        # One-time recording
        if trigger_dt < datetime.now(UTC):
            logger.warning(f"Recording {rec_id} trigger time is in the past, skipping")
            return
        scheduler.add_job(
            _do_recording,
            trigger=DateTrigger(run_date=trigger_dt),
            args=[rec_id],
            id=f"rec_{rec_id}",
            replace_existing=True,
            misfire_grace_time=300,
        )


def _build_cron_trigger(recurrence: dict, offset_minutes: int = 0) -> CronTrigger:
    """Convert a recurrence dict to an APScheduler CronTrigger.
    offset_minutes shifts the fire time (negative = earlier).

    New format:  {days: [0,1,...], time_start: "HH:MM", time_end: "HH:MM"}
    Legacy format: {pattern: "daily|weekly|weekdays|weekends", time: "HH:MM", day_of_week: N}
    """
    rec_tz = get_recording_tz()

    # ── New format ────────────────────────────────────────────────────────────
    if "days" in recurrence:
        time_str = recurrence.get("time_start", "21:00")
        days     = recurrence.get("days", list(range(7)))
        total_minutes = sum(x * y for x, y in zip(map(int, time_str.split(":")), [60, 1]))
        total_minutes = (total_minutes + offset_minutes) % 1440
        hour, minute  = divmod(total_minutes, 60)
        dow_str = ",".join(str(d) for d in sorted(days))
        return CronTrigger(day_of_week=dow_str, hour=hour, minute=minute, timezone=rec_tz)

    # ── Legacy format ─────────────────────────────────────────────────────────
    pattern  = recurrence.get("pattern", "weekly")
    time_str = recurrence.get("time", "21:00")
    total_minutes = sum(x * y for x, y in zip(map(int, time_str.split(":")), [60, 1]))
    total_minutes = (total_minutes + offset_minutes) % 1440
    hour, minute  = divmod(total_minutes, 60)

    if pattern == "daily":
        return CronTrigger(hour=hour, minute=minute, timezone=rec_tz)
    elif pattern == "weekly":
        dow = recurrence.get("day_of_week", 0)  # 0=Mon … 6=Sun
        return CronTrigger(day_of_week=dow, hour=hour, minute=minute, timezone=rec_tz)
    elif pattern == "weekdays":
        return CronTrigger(day_of_week="mon-fri", hour=hour, minute=minute, timezone=rec_tz)
    elif pattern == "weekends":
        return CronTrigger(day_of_week="sat,sun", hour=hour, minute=minute, timezone=rec_tz)
    else:
        return CronTrigger(hour=hour, minute=minute, timezone=rec_tz)


# ─── API routes: settings ─────────────────────────────────────────────────────

@app.errorhandler(Exception)
def handle_exception(e):
    """Always return JSON errors so fetch() never receives unexpected HTML."""
    from werkzeug.exceptions import HTTPException
    if isinstance(e, HTTPException):
        return jsonify({"error": e.description}), e.code
    logger.exception("Unhandled exception in request handler")
    return jsonify({"error": str(e)}), 500


@app.route("/")
def index():
    return render_template("index.html", app_version=APP_VERSION)


@app.route("/api/settings", methods=["GET"])
def api_get_settings():
    settings = db.get_settings()
    # Don't send password in plaintext - just indicate it's set
    safe = dict(settings)
    safe["xtream_password_set"] = bool(safe.get("xtream_password"))
    safe.pop("xtream_password", None)
    return jsonify(safe)


@app.route("/api/settings", methods=["POST"])
def api_save_settings():
    data = request.get_json(force=True, silent=True) or {}
    allowed = {
        "xtream_host", "xtream_username", "xtream_password",
        "default_save_path", "default_quality", "setup_complete", "timezone",
        "epg_filter_channels",
    }
    updates = {k: v for k, v in data.items() if k in allowed}

    # Don't overwrite password if blank (frontend sends empty when unchanged)
    if "xtream_password" in updates and not updates["xtream_password"]:
        del updates["xtream_password"]

    db.save_settings(updates)
    refresh_xtream_client()
    return jsonify({"ok": True})


@app.route("/api/settings/test", methods=["POST"])
def api_test_connection():
    data = request.get_json(force=True, silent=True) or {}
    host = data.get("host", "").strip()
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()
    if not password:
        # Fall back to the stored password when the field was left blank
        password = db.get_settings().get("xtream_password", "")
    if not host or not username or not password:
        return jsonify({"ok": False, "detail": "Host, username and password are all required"}), 400
    client = XtreamClient(host, username, password)
    ok, result = client.test_connection()
    return jsonify({"ok": ok, "detail": result})


# ─── API routes: channels ─────────────────────────────────────────────────────

@app.route("/api/channels")
def api_channels():
    force = request.args.get("refresh") == "1"
    groups = get_channel_groups(force_refresh=force)
    return jsonify(groups)


@app.route("/api/channels/refresh", methods=["POST"])
def api_channels_refresh():
    groups = get_channel_groups(force_refresh=True)
    return jsonify({"ok": True, "count": len(groups)})


# ─── API routes: EPG ──────────────────────────────────────────────────────────

@app.route("/api/epg/<int:stream_id>")
def api_epg_single(stream_id: int):
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    limit = int(request.args.get("limit", 20))
    entries = client.get_epg_for_stream(stream_id, limit=limit)
    return jsonify(entries)


@app.route("/api/epg/bulk", methods=["POST"])
def api_epg_bulk():
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503

    data  = request.get_json(force=True, silent=True) or {}
    limit = int(data.get("limit", 10))

    # Accept either new format {channels:[{stream_id, epg_channel_id}]}
    # or legacy format {stream_ids:[...]}
    channels = data.get("channels", [])
    if not channels:
        for sid in data.get("stream_ids", []):
            channels.append({"stream_id": sid, "epg_channel_id": ""})
    if len(channels) > 100:
        channels = channels[:100]

    result: dict = {}
    need_json_api: list = []

    with _xmltv_cache_lock:
        xmltv = _xmltv_cache  # snapshot reference under lock

    for ch in channels:
        sid    = str(ch["stream_id"])
        epg_id = (ch.get("epg_channel_id") or "").strip()

        if epg_id and epg_id in xmltv:
            # Only return programmes within a useful window:
            # up to 2 hours in the past (so current programme is included even
            # if it started a while ago) and up to 48 hours ahead.
            now_dt   = datetime.now(UTC)
            cutoff   = (now_dt - timedelta(hours=2)).isoformat()
            horizon  = (now_dt + timedelta(hours=48)).isoformat()
            entries = sorted(
                (e for e in xmltv[epg_id]
                 if e.get("start") and e["start"] <= horizon
                 and (e.get("end") or e["start"]) >= cutoff),
                key=lambda x: x["start"],
            )
            result[sid] = entries[:limit]
        else:
            need_json_api.append(int(ch["stream_id"]))

    # Fall back to the JSON API for any channels not covered by XMLTV
    if need_json_api:
        try:
            json_result = client.get_epg_bulk(need_json_api, limit=limit)
            result.update(json_result)
        except Exception as e:
            logger.warning(f"JSON EPG fallback failed: {e}")

    return jsonify(result)


@app.route("/api/epg/xmltv/refresh", methods=["POST"])
def api_xmltv_refresh():
    global _xmltv_cache, _xmltv_last_fetch
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    try:
        data = client.fetch_epg_xmltv()
        with _xmltv_cache_lock:
            _xmltv_cache = data
            _xmltv_last_fetch = datetime.now(UTC)
        _persist_xmltv()
        return jsonify({"ok": True, "channels": len(data)})
    except Exception as e:
        logger.error(f"XMLTV refresh failed: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/epg/xmltv/channel-ids")
def api_xmltv_channel_ids():
    """Return epg_channel_id values that have at least one current or upcoming programme.
    Channels whose data is entirely in the past are excluded so the EPG filter
    doesn't show rows with nothing but 'No EPG data'."""
    now_dt  = datetime.now(UTC)
    cutoff  = (now_dt - timedelta(hours=2)).isoformat()
    horizon = (now_dt + timedelta(hours=48)).isoformat()
    with _xmltv_cache_lock:
        ids = [
            ch_id for ch_id, entries in _xmltv_cache.items()
            if any(
                e.get("start") and e["start"] <= horizon
                and (e.get("end") or e["start"]) >= cutoff
                for e in entries
            )
        ]
    return jsonify({"channel_ids": ids})


@app.route("/api/epg/search")
def api_epg_search():
    """Search all programs in the XMLTV cache by title (case-insensitive substring)."""
    q     = request.args.get("q", "").strip().lower()
    limit = min(int(request.args.get("limit", 100)), 500)
    if not q or len(q) < 2:
        return jsonify([])

    results = []
    now_iso = datetime.now(UTC).isoformat()

    with _xmltv_cache_lock:
        for epg_channel_id, entries in _xmltv_cache.items():
            for entry in entries:
                if q in (entry.get("title") or "").lower():
                    results.append({"epg_channel_id": epg_channel_id, **entry})

    # Future/current first (sorted ascending), then past (sorted descending)
    future = sorted(
        (r for r in results if (r.get("end") or "") >= now_iso),
        key=lambda x: x.get("start") or "",
    )
    past = sorted(
        (r for r in results if (r.get("end") or "") < now_iso),
        key=lambda x: x.get("start") or "",
        reverse=True,
    )
    return jsonify((future + past)[:limit])


@app.route("/api/epg/xmltv/status", methods=["GET"])
def api_xmltv_status():
    with _xmltv_cache_lock:
        loaded      = bool(_xmltv_cache)
        num_channels = len(_xmltv_cache)
        last_fetch  = _xmltv_last_fetch
    return jsonify({
        "loaded":    loaded,
        "channels":  num_channels,
        "last_fetch": last_fetch.isoformat() if last_fetch else None,
    })


# ─── API routes: live playback via mpv ───────────────────────────────────────

def _player_cmd(url: str, title: str, duration_seconds: int = None) -> list:
    """Build a player command, preferring mpv with fallback to ffplay."""
    mpv = shutil.which("mpv")
    if mpv:
        cmd = [mpv, url, f"--title={title}", "--geometry=1280x720", "--really-quiet"]
        if duration_seconds:
            cmd.append(f"--length={duration_seconds}")
        return cmd
    ffplay = shutil.which("ffplay") or "ffplay"
    cmd = [ffplay, "-window_title", title, "-x", "1280", "-y", "720"]
    if duration_seconds:
        cmd += ["-t", str(duration_seconds)]
    cmd.append(url)
    return cmd


def _has_player() -> bool:
    return bool(shutil.which("mpv") or shutil.which("ffplay"))


@app.route("/api/recordings/<rec_id>/play", methods=["POST"])
def api_play_recording(rec_id: str):
    """Launch mpv (or ffplay) to watch a completed local recording."""
    rec = db.get_recording(rec_id)
    if not rec or not rec.get("output_file"):
        return jsonify({"error": "Recording not found"}), 404
    if not os.path.exists(rec["output_file"]):
        return jsonify({"error": "File not found on disk"}), 404
    if not _has_player():
        return jsonify({"error": "No video player found - install mpv from https://mpv.io"}), 500
    try:
        subprocess.Popen(
            _player_cmd(rec["output_file"], rec.get("show_name", "Recording")),
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/play/<int:stream_id>", methods=["POST"])
def api_play_stream(stream_id: int):
    """Launch mpv to watch a live stream externally."""
    data = request.get_json(force=True, silent=True) or {}
    title = data.get("title", "IPTV Manager")

    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503

    if not _has_player():
        return jsonify({"error": "No video player found - install mpv from https://mpv.io"}), 500

    # Trial: enforce concurrent stream limit
    if _is_trial() and _trial_stream_count() >= _TRIAL_STREAM_LIMIT:
        return jsonify({
            "error":   "trial_limit_reached",
            "message": f"Trial is limited to {_TRIAL_STREAM_LIMIT} simultaneous live streams.",
            "buy_url": _TRIAL_BUY_URL,
        }), 402

    url = client.get_stream_url(stream_id, fmt="m3u8")
    duration = _TRIAL_STREAM_DURATION if _is_trial() else None
    try:
        proc = subprocess.Popen(
            _player_cmd(url, title, duration_seconds=duration),
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        if _is_trial():
            with _trial_streams_lock:
                _trial_streams[proc.pid] = proc
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─── API routes: sports favourites ───────────────────────────────────────────

@app.route("/api/sports/favourites", methods=["GET"])
def api_get_sports_favourites():
    s = db.get_settings()
    favs = s.get("sports_favourites", [])
    if not isinstance(favs, list):
        favs = []
    return jsonify({"favourites": favs})


@app.route("/api/sports/favourites", methods=["POST"])
def api_save_sports_favourites():
    data = request.get_json(force=True, silent=True) or {}
    favs = data.get("favourites", [])
    if not isinstance(favs, list):
        favs = []
    db.save_settings({"sports_favourites": favs})
    return jsonify({"ok": True, "favourites": favs})


# ─── Background: auto-refresh XMLTV EPG ──────────────────────────────────────

def _auto_refresh_xmltv():
    """Scheduled job: silently refresh XMLTV EPG data in the background."""
    client = get_xtream_client()
    if not client:
        return
    try:
        data = client.fetch_epg_xmltv()
        with _xmltv_cache_lock:
            global _xmltv_cache, _xmltv_last_fetch
            _xmltv_cache = data
            _xmltv_last_fetch = datetime.now(UTC)
        _persist_xmltv()
        logger.info(f"XMLTV auto-refresh complete: {len(data)} channels")
    except Exception as e:
        logger.warning(f"XMLTV auto-refresh failed: {e}")


# ─── API routes: watchlist ───────────────────────────────────────────────────

@app.route("/api/watchlist", methods=["GET"])
def api_get_watchlist():
    s = db.get_settings()
    return jsonify(s.get("watchlist", []))


@app.route("/api/watchlist", methods=["POST"])
def api_save_watchlist():
    data = request.get_json(force=True, silent=True) or {}
    watchlist = data.get("watchlist", [])
    if not isinstance(watchlist, list):
        watchlist = []
    db.save_settings({"watchlist": watchlist})
    return jsonify({"ok": True})


# ─── API routes: currently watching ─────────────────────────────────────────

@app.route("/api/currently-watching", methods=["GET"])
def api_get_currently_watching():
    s = db.get_settings()
    return jsonify(s.get("currently_watching", []))


@app.route("/api/currently-watching", methods=["POST"])
def api_save_currently_watching():
    data = request.get_json(force=True, silent=True) or {}
    items = data.get("currently_watching", [])
    if not isinstance(items, list):
        items = []
    db.save_settings({"currently_watching": items})
    return jsonify({"ok": True})


# ─── API routes: EPG live now ─────────────────────────────────────────────────

@app.route("/api/epg/live")
def api_epg_live():
    """Return up to 50 programmes currently airing across all EPG channels."""
    with _xmltv_cache_lock:
        cache = dict(_xmltv_cache)
    now = datetime.now(UTC)
    live = []
    for channel_id, entries in cache.items():
        for entry in entries:
            try:
                start = datetime.fromisoformat(entry["start"]) if entry.get("start") else None
                end   = datetime.fromisoformat(entry["end"])   if entry.get("end")   else None
                if start and end and start <= now <= end:
                    live.append({**entry, "epg_channel_id": channel_id})
                    break
            except Exception:
                pass
    return jsonify(live[:60])


# ─── API routes: VOD (movies) ─────────────────────────────────────────────────

@app.route("/api/vod/categories")
def api_vod_categories():
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    try:
        return jsonify(client.get_vod_categories())
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/vod/streams")
def api_vod_streams():
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    category_id = request.args.get("category_id") or None
    search = (request.args.get("search") or "").lower().strip()
    page = max(1, int(request.args.get("page", 1)))
    per_page = 48
    try:
        streams = client.get_vod_streams(category_id)
        if search:
            streams = [s for s in streams if search in (s.get("name") or "").lower()]
        total = len(streams)
        start = (page - 1) * per_page
        return jsonify({
            "streams": streams[start:start + per_page],
            "total": total,
            "page": page,
            "pages": max(1, (total + per_page - 1) // per_page),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/vod/info/<int:vod_id>")
def api_vod_info(vod_id: int):
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    try:
        return jsonify(client.get_vod_info(vod_id))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/vod/play/<int:stream_id>", methods=["POST"])
def api_vod_play(stream_id: int):
    """Launch mpv to watch a VOD movie externally."""
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    data = request.get_json(force=True, silent=True) or {}
    title = data.get("title", "IPTV Manager")
    ext = data.get("ext", "mp4")

    if not _has_player():
        return jsonify({"error": "No video player found - install mpv from https://mpv.io"}), 500

    url = client.get_vod_stream_url(stream_id, ext)
    try:
        subprocess.Popen(_player_cmd(url, title), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def _start_download(url: str, title: str) -> dict:
    """Common helper: start an ffmpeg download to ~/Downloads and track progress."""
    ffmpeg_path = shutil.which("ffmpeg")
    if not ffmpeg_path:
        return {"error": "ffmpeg not found - make sure FFmpeg is installed"}

    dl_id = uuid.uuid4().hex[:10]
    save_dir = str(Path.home() / "Downloads")
    safe_title = "".join(c for c in title if c.isalnum() or c in " _-()").strip() or "download"
    filepath = os.path.join(save_dir, f"{safe_title}.mkv")
    progress_file = os.path.join(tempfile.gettempdir(), f"iptv_dl_{dl_id}.txt")

    cmd = [
            ffmpeg_path, "-i", url,
            "-c", "copy",          # remux without re-encoding (fast)
            "-y",
            "-progress", progress_file,
            "-nostats",
            filepath,
        ]
    try:
        os.makedirs(save_dir, exist_ok=True)
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        with _downloads_lock:
            _active_downloads[dl_id] = {
                "title": title,
                "filepath": filepath,
                "proc": proc,
                "progress_file": progress_file,
                "status": "downloading",
            }
        return {"ok": True, "download_id": dl_id, "file": filepath}
    except Exception as e:
        return {"error": str(e)}


@app.route("/api/vod/download", methods=["POST"])
def api_vod_download():
    """Download a VOD movie to ~/Downloads."""
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    data = request.get_json(force=True, silent=True) or {}
    stream_id = data.get("stream_id")
    ext = data.get("ext", "mp4")
    title = data.get("title", "download")
    if not stream_id:
        return jsonify({"error": "stream_id required"}), 400
    url = client.get_vod_stream_url(int(stream_id), ext)
    result = _start_download(url, title)
    return jsonify(result), (500 if "error" in result else 200)


# ─── API routes: download management ─────────────────────────────────────────

@app.route("/api/downloads")
def api_downloads_list():
    """Return status of all active/recent downloads."""
    result = {}
    with _downloads_lock:
        for dl_id, info in list(_active_downloads.items()):
            proc = info["proc"]
            if proc.poll() is not None:
                info["status"] = "done" if proc.returncode == 0 else "error"

            # Parse ffmpeg -progress output
            out_time = ""
            speed = ""
            try:
                pf = info.get("progress_file", "")
                if pf and os.path.exists(pf):
                    kv = {}
                    for line in open(pf).read().strip().splitlines():
                        if "=" in line:
                            k, v = line.split("=", 1)
                            kv[k.strip()] = v.strip()
                    out_time = kv.get("out_time", "")
                    speed    = kv.get("speed", "")
                    if kv.get("progress") == "end":
                        info["status"] = "done"
            except Exception:
                pass

            result[dl_id] = {
                "title":    info["title"],
                "filepath": info["filepath"],
                "status":   info["status"],
                "out_time": out_time,
                "speed":    speed,
            }
    return jsonify(result)


@app.route("/api/transcodes")
def api_transcodes_list():
    """Return status of all active/recent transcodes."""
    result = {}
    with _transcodes_lock:
        for rec_id, info in list(_active_transcodes.items()):
            proc = info["proc"]
            if proc.poll() is not None and info["status"] == "transcoding":
                info["status"] = "done" if proc.returncode == 0 else "error"

            out_time = ""
            speed = ""
            try:
                pf = info.get("progress_file", "")
                if pf and os.path.exists(pf):
                    kv = {}
                    for line in open(pf).read().strip().splitlines():
                        if "=" in line:
                            k, v = line.split("=", 1)
                            kv[k.strip()] = v.strip()
                    out_time = kv.get("out_time", "")
                    speed    = kv.get("speed", "")
                    if kv.get("progress") == "end":
                        info["status"] = "done"
            except Exception:
                pass

            result[rec_id] = {
                "title":    info["title"],
                "codec":    info["codec"],
                "status":   info["status"],
                "out_time": out_time,
                "speed":    speed,
            }
    return jsonify(result)


@app.route("/api/transcodes/<rec_id>/cancel", methods=["POST"])
def api_transcode_cancel(rec_id: str):
    with _transcodes_lock:
        info = _active_transcodes.get(rec_id)
        if not info or info["status"] != "transcoding":
            return jsonify({"error": "No active transcode"}), 404
        info["proc"].terminate()
        info["status"] = "cancelled"
    return jsonify({"ok": True})


@app.route("/api/transcodes/<rec_id>/dismiss", methods=["DELETE"])
def api_transcode_dismiss(rec_id: str):
    with _transcodes_lock:
        info = _active_transcodes.get(rec_id)
        if not info:
            return jsonify({"error": "Not found"}), 404
        if info["status"] == "transcoding":
            return jsonify({"error": "Transcode still running"}), 409
        del _active_transcodes[rec_id]
    return jsonify({"ok": True})


@app.route("/api/downloads/<dl_id>", methods=["DELETE"])
def api_download_cancel(dl_id: str):
    with _downloads_lock:
        info = _active_downloads.get(dl_id)
        if not info:
            return jsonify({"error": "not found"}), 404
        try:
            info["proc"].terminate()
        except Exception:
            pass
        info["status"] = "cancelled"
    return jsonify({"ok": True})


@app.route("/api/downloads/files")
def api_downloads_files():
    """List video files in ~/Downloads sorted by modification time (newest first)."""
    downloads_dir = str(Path.home() / "Downloads")
    VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".wmv", ".flv", ".webm"}
    try:
        files = []
        for entry in os.scandir(downloads_dir):
            if not entry.is_file():
                continue
            ext = os.path.splitext(entry.name)[1].lower()
            if ext not in VIDEO_EXTS:
                continue
            stat = entry.stat()
            files.append({
                "name":     entry.name,
                "path":     entry.path,
                "size":     stat.st_size,
                "modified": stat.st_mtime,
            })
        files.sort(key=lambda f: f["modified"], reverse=True)
        return jsonify(files)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/downloads/files/delete", methods=["POST"])
def api_downloads_file_delete():
    """Delete a downloaded file (must be inside ~/Downloads)."""
    data = request.get_json(force=True, silent=True) or {}
    filepath = data.get("path", "")
    downloads_dir = str(Path.home() / "Downloads")
    real = os.path.realpath(filepath)
    allowed = os.path.realpath(downloads_dir)
    if not real.startswith(allowed + os.sep):
        return jsonify({"error": "Not allowed"}), 403
    try:
        os.remove(real)
        return jsonify({"ok": True})
    except FileNotFoundError:
        return jsonify({"error": "File not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/downloads/files/open", methods=["POST"])
def api_downloads_file_open():
    """Open a downloaded file with the default system player."""
    data = request.get_json(force=True, silent=True) or {}
    filepath = data.get("path", "")
    downloads_dir = str(Path.home() / "Downloads")
    real = os.path.realpath(filepath)
    allowed = os.path.realpath(downloads_dir)
    if not real.startswith(allowed + os.sep):
        return jsonify({"error": "Not allowed"}), 403
    if not os.path.exists(real):
        return jsonify({"error": "File not found"}), 404
    try:
        platform = sys.platform
        if platform == "win32":
            os.startfile(real)
        elif platform == "darwin":
            subprocess.Popen(["open", real])
        else:
            subprocess.Popen(["xdg-open", real])
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─── API routes: series (TV shows) ───────────────────────────────────────────

@app.route("/api/series/categories")
def api_series_categories():
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    try:
        return jsonify(client.get_series_categories())
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/series/streams")
def api_series_streams():
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    category_id = request.args.get("category_id") or None
    search = (request.args.get("search") or "").lower().strip()
    page = max(1, int(request.args.get("page", 1)))
    per_page = 48
    try:
        series = client.get_series(category_id)
        if search:
            series = [s for s in series if search in (s.get("name") or "").lower()]
        total = len(series)
        start = (page - 1) * per_page
        return jsonify({
            "series": series[start:start + per_page],
            "total": total,
            "page": page,
            "pages": max(1, (total + per_page - 1) // per_page),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/series/info/<int:series_id>")
def api_series_info(series_id: int):
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    try:
        return jsonify(client.get_series_info(series_id))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/series/play", methods=["POST"])
def api_series_play():
    """Launch mpv for a series episode."""
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    data = request.get_json(force=True, silent=True) or {}
    stream_id = data.get("stream_id")
    title = data.get("title", "IPTV Manager")
    ext = data.get("ext", "mp4")

    if not stream_id:
        return jsonify({"error": "stream_id required"}), 400

    if not _has_player():
        return jsonify({"error": "No video player found - install mpv from https://mpv.io"}), 500

    url = client.get_series_stream_url(int(stream_id), ext)
    try:
        subprocess.Popen(_player_cmd(url, title), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/series/download", methods=["POST"])
def api_series_download():
    """Download a series episode to ~/Downloads."""
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    data = request.get_json(force=True, silent=True) or {}
    stream_id = data.get("stream_id")
    ext = data.get("ext", "mp4")
    title = data.get("title", "download")
    if not stream_id:
        return jsonify({"error": "stream_id required"}), 400
    url = client.get_series_stream_url(int(stream_id), ext)
    result = _start_download(url, title)
    return jsonify(result), (500 if "error" in result else 200)


# ─── API routes: streaming ────────────────────────────────────────────────────

@app.route("/api/stream/url/<int:stream_id>")
def api_stream_url(stream_id: int):
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    url = client.get_stream_url(stream_id)
    return jsonify({"url": url, "stream_id": stream_id})


@app.route("/api/hls/<int:stream_id>.m3u8")
def api_hls_proxy(stream_id: int):
    """
    Proxy the HLS master playlist from the XTream server, rewriting all
    absolute segment/sub-playlist URLs to go through our local proxy.
    This avoids browser CORS issues.
    """
    client = get_xtream_client()
    if not client:
        return Response("Not configured", status=503)

    remote_url = client.get_stream_url(stream_id, fmt="m3u8")
    try:
        resp = requests.get(remote_url, timeout=10, headers={"User-Agent": "Mozilla/5.0"})
        resp.raise_for_status()
    except Exception as e:
        return Response(f"Error fetching stream: {e}", status=502)

    content = resp.text
    import re as _re
    content = _re.sub(
        r'(https?://[^\s\r\n]+)',
        lambda m: f"/api/hls/proxy/{stream_id}?url={requests.utils.quote(m.group(1))}",
        content
    )

    return Response(
        content,
        content_type="application/vnd.apple.mpegurl",
        headers={"Access-Control-Allow-Origin": "*"},
    )


@app.route("/api/hls/proxy/<int:stream_id>")
def api_hls_segment_proxy(stream_id: int):
    """Proxy an individual HLS segment or sub-playlist."""
    target_url = request.args.get("url")
    if not target_url:
        return Response("Missing url parameter", status=400)

    try:
        resp = requests.get(
            target_url,
            stream=True,
            timeout=10,
            headers={"User-Agent": "Mozilla/5.0"},
        )
        content_type = resp.headers.get("Content-Type", "video/MP2T")

        if "mpegurl" in content_type.lower() or target_url.endswith(".m3u8"):
            # Sub-playlist - rewrite URLs too
            content = resp.text
            import re as _re
            content = _re.sub(
                r'(https?://[^\s\r\n]+)',
                lambda m: f"/api/hls/proxy/{stream_id}?url={requests.utils.quote(m.group(1))}",
                content
            )
            return Response(content, content_type="application/vnd.apple.mpegurl",
                            headers={"Access-Control-Allow-Origin": "*"})

        return Response(
            resp.iter_content(chunk_size=65536),
            content_type=content_type,
            headers={"Access-Control-Allow-Origin": "*"},
        )
    except Exception as e:
        return Response(f"Proxy error: {e}", status=502)


# ─── API routes: recordings ───────────────────────────────────────────────────

@app.route("/api/recordings", methods=["GET"])
def api_list_recordings():
    recs = db.get_all_recordings()
    # Sweep completed processes
    finished = recorder.sweep_finished()
    for fid in finished:
        _on_recording_finished(fid)
    # Attach live status
    active = recorder.get_active_recordings()
    for rec in recs:
        if rec["id"] in active:
            rec["active"] = active[rec["id"]]
    return jsonify(recs)


@app.route("/api/trial/status")
def api_trial_status():
    trial = _is_trial()
    count = _trial_recording_count() if trial else 0
    return jsonify({
        "trial":     trial,
        "limit":     _TRIAL_LIMIT,
        "used":      count,
        "remaining": max(0, _TRIAL_LIMIT - count),
        "buy_url":   _TRIAL_BUY_URL,
    })


@app.route("/api/recordings", methods=["POST"])
def api_create_recording():
    data = request.get_json(force=True, silent=True) or {}

    # Trial mode: enforce recording limit
    if _is_trial() and _trial_recording_count() >= _TRIAL_LIMIT:
        return jsonify({
            "error":   "trial_limit_reached",
            "message": f"Trial limit of {_TRIAL_LIMIT} recordings reached.",
            "buy_url": _TRIAL_BUY_URL,
        }), 402

    # Validate required fields
    required = ["channel_id", "channel_name", "show_name", "save_path",
                "start_time", "end_time"]
    missing = [f for f in required if not data.get(f)]
    if missing:
        return jsonify({"error": f"Missing fields: {', '.join(missing)}"}), 400

    settings = db.get_settings()

    rec = {
        "id": str(uuid.uuid4()),
        "type": data.get("type", "once"),
        "channel_id": str(data["channel_id"]),
        "channel_name": data["channel_name"],
        "show_name": data["show_name"],
        "season": int(data.get("season", 1)),
        "episode": int(data.get("episode", 1)),
        "save_path": data.get("save_path") or settings.get("default_save_path", ""),
        "quality": data.get("quality") or settings.get("default_quality", {}),
        "start_time": data["start_time"],
        "end_time": data["end_time"],
        "status": "recurring" if data.get("recurrence") else "scheduled",
        "recurrence": data.get("recurrence"),
        "output_file": None,
        "created_at": datetime.now(UTC).isoformat(),
        "scheduler_id": None,
        "padding_start": int(data.get("padding_start") or 0),
        "padding_end":   int(data.get("padding_end")   or 0),
        "paused_until":  None,
        "parent_id":     None,
    }

    db.save_recording(rec)
    _schedule_recording(rec)
    if rec.get("recurrence"):
        _check_immediate_occurrence(rec)

    return jsonify(rec), 201


@app.route("/api/recordings/<rec_id>", methods=["GET"])
def api_get_recording(rec_id: str):
    rec = db.get_recording(rec_id)
    if not rec:
        return jsonify({"error": "Not found"}), 404
    return jsonify(rec)


@app.route("/api/recordings/<rec_id>", methods=["PUT"])
def api_update_recording(rec_id: str):
    rec = db.get_recording(rec_id)
    if not rec:
        return jsonify({"error": "Not found"}), 404

    data = request.get_json(force=True, silent=True) or {}
    updatable = ["show_name", "season", "episode", "save_path", "quality",
                 "start_time", "end_time", "recurrence", "type",
                 "padding_start", "padding_end", "paused_until"]
    for field in updatable:
        if field in data:
            rec[field] = data[field]

    # Coerce padding to int
    rec["padding_start"] = int(rec.get("padding_start") or 0)
    rec["padding_end"]   = int(rec.get("padding_end")   or 0)

    # Update status to match type
    if data.get("recurrence"):
        rec["status"] = "recurring"
    elif rec.get("status") in ("recurring",):
        rec["status"] = "scheduled"

    # Re-schedule if times changed
    try:
        scheduler.remove_job(f"rec_{rec_id}")
    except Exception:
        pass

    db.save_recording(rec)
    _schedule_recording(rec)
    if rec.get("recurrence"):
        _check_immediate_occurrence(rec)

    return jsonify(rec)


@app.route("/api/recordings/<rec_id>", methods=["DELETE"])
def api_delete_recording(rec_id: str):
    rec = db.get_recording(rec_id)
    if not rec:
        return jsonify({"error": "Not found"}), 404

    # Stop if active
    recorder.stop_recording(rec_id)

    # Remove scheduler job
    try:
        scheduler.remove_job(f"rec_{rec_id}")
    except Exception:
        pass

    db.delete_recording(rec_id)
    return jsonify({"ok": True})


@app.route("/api/recordings/<rec_id>/stop", methods=["POST"])
def api_stop_recording(rec_id: str):
    stopped = recorder.stop_recording(rec_id)
    if stopped:
        _on_recording_finished(rec_id)
    return jsonify({"ok": stopped})


@app.route("/api/recordings/<rec_id>/pause", methods=["POST"])
def api_pause_recording(rec_id: str):
    rec = db.get_recording(rec_id)
    if not rec:
        return jsonify({"error": "Not found"}), 404
    data = request.get_json(force=True, silent=True) or {}
    paused_until = data.get("paused_until")
    if not paused_until:
        return jsonify({"error": "paused_until (ISO date string) is required"}), 400
    rec["paused_until"] = paused_until
    db.save_recording(rec)
    return jsonify({"ok": True, "paused_until": paused_until})


@app.route("/api/recordings/<rec_id>/resume", methods=["POST"])
def api_resume_recording(rec_id: str):
    rec = db.get_recording(rec_id)
    if not rec:
        return jsonify({"error": "Not found"}), 404
    rec["paused_until"] = None
    db.save_recording(rec)
    return jsonify({"ok": True})


@app.route("/api/recordings/<rec_id>/stream")
def api_stream_recording(rec_id: str):
    """Stream a completed recording file to the browser (supports range requests for seeking)."""
    import mimetypes
    rec = db.get_recording(rec_id)
    if not rec:
        return jsonify({"error": "Not found"}), 404
    output_file = rec.get("output_file")
    if not output_file or not os.path.exists(output_file):
        return jsonify({"error": "File not found on disk"}), 404
    mime, _ = mimetypes.guess_type(output_file)
    return send_file(output_file, mimetype=mime or "video/mp4", conditional=True)


@app.route("/api/network/info")
def api_network_info():
    """Return the local LAN IP and port so the user can access from other devices."""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception:
        local_ip = "127.0.0.1"
    return jsonify({"local_ip": local_ip, "port": 5001})


@app.route("/api/launch-installer")
def api_launch_installer():
    """Open the installer script in Terminal, then shut down this process."""
    import subprocess, signal, os as _os
    installer = _os.path.join(_os.path.dirname(__file__), "Install IPTV Manager.command")
    if _os.path.exists(installer):
        subprocess.Popen(["open", installer])
    # Shut down: give the browser a moment to receive the redirect first
    def _shutdown():
        import time as _time
        _time.sleep(1.5)
        _os.kill(_os.getpid(), signal.SIGTERM)
    threading.Thread(target=_shutdown, daemon=True).start()
    return """<!doctype html><html><head>
      <meta http-equiv="refresh" content="2;url=http://localhost:5001">
      <style>body{font-family:sans-serif;background:#0d0d0f;color:#aaa;
        display:flex;align-items:center;justify-content:center;height:100vh;margin:0;}
      </style></head><body>
      <p>Launching installer… IPTV Manager will restart when installation is complete.</p>
      </body></html>"""


@app.route("/api/update/check")
def api_update_check():
    try:
        resp = requests.get(UPDATE_CSV_URL, timeout=10)
        resp.raise_for_status()
        lines = [l.strip() for l in resp.text.splitlines() if l.strip()]
        data_lines = [l for l in lines if l and l[0].isdigit()]
        if not data_lines:
            return jsonify({"update_available": False, "current_version": APP_VERSION})
        parts    = [p.strip() for p in data_lines[0].split(",")]
        latest   = parts[0] if len(parts) > 0 else ""
        filename = parts[3] if len(parts) > 3 else ""
        dl_url   = f"https://tobyjones.ca/software/downloads/{filename}" if filename else ""
        current_major = _parse_version(APP_VERSION)[0]
        latest_major  = _parse_version(latest)[0]
        return jsonify({
            "update_available": _parse_version(latest) > _parse_version(APP_VERSION),
            "current_version":  APP_VERSION,
            "latest_version":   latest,
            "download_url":     dl_url,
            "filename":         filename,
            "is_major_update":  latest_major > current_major,
        })
    except Exception as e:
        logger.warning(f"Update check failed: {e}")
        return jsonify({"update_available": False, "current_version": APP_VERSION})


@app.route("/api/update/download", methods=["POST"])
def api_update_download():
    data = request.get_json(force=True, silent=True) or {}
    download_url = data.get("download_url", "").strip()
    filename     = data.get("filename", "update.zip").strip()
    if not download_url:
        return jsonify({"error": "No download URL provided"}), 400
    try:
        resp = requests.get(download_url, timeout=120, stream=True)
        resp.raise_for_status()
        downloads_dir = os.path.expanduser("~/Downloads")
        dest = os.path.join(downloads_dir, filename)
        with open(dest, "wb") as f:
            for chunk in resp.iter_content(chunk_size=65536):
                f.write(chunk)
        return jsonify({"ok": True, "saved_to": dest})
    except Exception as e:
        logger.error(f"Update download failed: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/backup", methods=["GET"])
def api_backup():
    """Export all settings and scheduled/recurring recordings as a single JSON file."""
    settings = db.get_settings()
    recordings = [
        r for r in db.get_all_recordings()
        if r.get("status") in ("scheduled", "recurring")
    ]
    payload = {
        "iptv_manager_backup": True,
        "app_version": APP_VERSION,
        "exported_at": datetime.now(UTC).isoformat(),
        "settings": settings,
        "recordings": recordings,
    }
    from flask import Response as _Response
    import json as _json
    return _Response(
        _json.dumps(payload, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": 'attachment; filename="iptv-manager-backup.json"'},
    )


@app.route("/api/restore", methods=["POST"])
def api_restore():
    """Restore settings and recordings from a backup JSON."""
    data = request.get_json(force=True, silent=True) or {}
    if not data.get("iptv_manager_backup"):
        return jsonify({"error": "Not a valid IPTV Manager backup file"}), 400

    # ── Restore settings ──────────────────────────────────────────────────
    allowed = {
        "xtream_host", "xtream_username", "xtream_password",
        "default_save_path", "default_quality", "timezone",
        "epg_filter_channels",
    }
    settings_updates = {k: v for k, v in (data.get("settings") or {}).items()
                        if k in allowed and v not in (None, "")}
    if settings_updates:
        db.save_settings(settings_updates)
        refresh_xtream_client()

    # ── Restore recordings ────────────────────────────────────────────────
    imported = 0
    failed   = 0
    for r in (data.get("recordings") or []):
        try:
            rec = {
                "id":           str(uuid.uuid4()),
                "type":         r.get("type", "once"),
                "channel_id":   str(r.get("channel_id", "")),
                "channel_name": r.get("channel_name", ""),
                "show_name":    r.get("show_name", ""),
                "season":       int(r.get("season") or 1),
                "episode":      int(r.get("episode") or 1),
                "save_path":    r.get("save_path", ""),
                "quality":      r.get("quality") or {},
                "start_time":   r.get("start_time", ""),
                "end_time":     r.get("end_time", ""),
                "status":       "recurring" if r.get("recurrence") else "scheduled",
                "recurrence":   r.get("recurrence"),
                "output_file":  None,
                "created_at":   datetime.now(UTC).isoformat(),
                "scheduler_id": None,
                "padding_start": int(r.get("padding_start") or 0),
                "padding_end":   int(r.get("padding_end")   or 0),
                "paused_until":  r.get("paused_until"),
                "parent_id":     None,
            }
            if not rec["show_name"] or not rec["start_time"] or not rec["end_time"]:
                failed += 1
                continue
            db.save_recording(rec)
            _schedule_recording(rec)
            imported += 1
        except Exception as e:
            logger.warning(f"Restore: failed to import recording: {e}")
            failed += 1

    return jsonify({"ok": True, "imported": imported, "failed": failed})


@app.route("/api/factory-reset", methods=["POST"])
def api_factory_reset():
    global _xtream_client, _channel_groups_cache, _xmltv_cache, _xmltv_last_fetch

    # Stop every active recording gracefully
    for rec_id in list(recorder.get_active_recordings()):
        recorder.stop_recording(rec_id)

    # Cancel all scheduled jobs
    try:
        scheduler.remove_all_jobs()
    except Exception:
        pass

    # Wipe the database
    db.reset_db()

    # Clear all in-memory caches so they don't survive the reset
    with _xtream_lock:
        _xtream_client = None
    with _channel_groups_lock:
        _channel_groups_cache = None
    with _xmltv_cache_lock:
        _xmltv_cache = {}
        _xmltv_last_fetch = None

    # Delete the on-disk channel cache
    clear_channel_cache()

    logger.info("Factory reset complete")
    return jsonify({"ok": True})


@app.route("/api/recordings/active")
def api_active_recordings():
    active = recorder.get_active_recordings()
    return jsonify(active)


# ─── Startup ──────────────────────────────────────────────────────────────────

def restore_scheduled_recordings():
    """On startup, re-register any scheduled/recurring recordings in APScheduler."""
    now = datetime.now(UTC)

    for rec in db.get_recordings_by_status("scheduled"):
        # Child occurrence rows spawned by a recurring template but never
        # started (server crashed between spawn and FFmpeg launch) cannot be
        # meaningfully re-scheduled — mark them failed so they don't clog the
        # list as phantom "scheduled" entries.
        if rec.get("parent_id"):
            try:
                start_dt = dateutil_parser.parse(rec["start_time"])
                if start_dt.tzinfo is None:
                    start_dt = UTC.localize(start_dt)
                if start_dt < now:
                    db.update_recording_status(rec["id"], "failed")
                    logger.info(f"Marked stale occurrence {rec['id']} as failed (start was {rec['start_time']})")
                    continue
            except Exception:
                pass
        try:
            _schedule_recording(rec)
        except Exception as e:
            logger.warning(f"Could not restore schedule for {rec['id']}: {e}")

    for rec in db.get_recordings_by_status("recurring"):
        try:
            _schedule_recording(rec)
            _check_immediate_occurrence(rec)
        except Exception as e:
            logger.warning(f"Could not restore recurring for {rec['id']}: {e}")

    # Mark any recordings that were mid-flight when the app crashed
    for rec in db.get_recordings_by_status("recording"):
        db.update_recording_status(rec["id"], "failed")


def open_browser():
    import time
    time.sleep(1.5)
    webbrowser.open("http://localhost:5001")


if __name__ == "__main__":
    db.init_db()
    _restore_xmltv()
    scheduler.start()
    restore_scheduled_recordings()

    # Auto-refresh EPG immediately on start, then every hour
    scheduler.add_job(
        _auto_refresh_xmltv,
        IntervalTrigger(hours=1),
        id="xmltv_auto_refresh",
        replace_existing=True,
        next_run_time=datetime.now(UTC),   # fire immediately
    )

    # Pre-load channel cache from disk (non-blocking)
    cached = load_channel_cache()
    if cached:
        with _channel_groups_lock:
            _channel_groups_cache = cached
        logger.info(f"Loaded {len(cached)} channel groups from disk cache")

    # Open browser in background thread
    threading.Thread(target=open_browser, daemon=True).start()

    print("\n" + "═" * 50)
    print("  IPTV Manager")
    print("  http://localhost:5001")
    print("  Press Ctrl+C to stop")
    print("═" * 50 + "\n")

    app.run(host="0.0.0.0", port=5001, debug=False, use_reloader=False)
