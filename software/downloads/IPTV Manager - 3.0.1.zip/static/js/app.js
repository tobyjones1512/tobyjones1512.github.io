/* ─────────────────────────────────────────────────────────────────────────
   IPTV Manager - Frontend Application
   All times are displayed in UK time (Europe/London).
   ───────────────────────────────────────────────────────────────────────── */

const UK_LOCALE = 'en-GB';
let activeTZ    = 'Europe/London';   // updated from settings on load

// True when the browser is on the same machine as the server (localhost / loopback).
// Playback (Live TV, VOD, episodes) is restricted to local access only.
const IS_LOCAL = ['localhost', '127.0.0.1', '::1'].includes(window.location.hostname);

function applyActiveTZ(tz) {
  activeTZ = tz === 'local' ? Intl.DateTimeFormat().resolvedOptions().timeZone : tz;
  // Show a short human-readable label: last segment of the tz id, e.g. "London", "New_York"
  const label = activeTZ.split('/').pop().replace(/_/g, ' ');
  document.querySelectorAll('.tz-label').forEach(el => el.textContent = label);
}

// ── Utilities ────────────────────────────────────────────────────────────────

function fmtUK(isoStr, opts = {}) {
  if (!isoStr) return '';
  return new Date(isoStr).toLocaleString(UK_LOCALE, { timeZone: activeTZ, ...opts });
}

function fmtTimeUK(isoStr) {
  if (!isoStr) return '';
  return new Date(isoStr).toLocaleTimeString(UK_LOCALE, {
    timeZone: activeTZ, hour: '2-digit', minute: '2-digit'
  });
}

function fmtDateTimeUK(isoStr) {
  if (!isoStr) return '';
  return new Date(isoStr).toLocaleString(UK_LOCALE, {
    timeZone: activeTZ,
    weekday: 'short', day: 'numeric', month: 'short',
    hour: '2-digit', minute: '2-digit'
  });
}

function nowUK() {
  return new Date();
}

// Convert a datetime-local input value ("YYYY-MM-DDTHH:mm") to a UTC ISO
// string, treating the input as activeTZ (the configured recording timezone).
function localInputToISO(value) {
  if (!value) return null;
  const [datePart, timePart] = value.split('T');
  const [year, month, day]   = datePart.split('-').map(Number);
  const [hour, minute]        = (timePart || '00:00').split(':').map(Number);

  // Treat the typed value as UTC to get a reference Date object.
  const naiveUtc = new Date(Date.UTC(year, month - 1, day, hour, minute, 0));

  // Ask Intl what activeTZ reads at that UTC moment to determine the offset.
  const tzParts = new Intl.DateTimeFormat('en-GB', {
    timeZone: activeTZ,
    hour: 'numeric', minute: 'numeric', hour12: false
  }).formatToParts(naiveUtc);
  const p = Object.fromEntries(
    tzParts.map(({ type, value }) => [type, parseInt(value) || 0])
  );

  // diffMin > 0 means activeTZ is ahead of UTC.
  let diffMin = (p.hour * 60 + p.minute) - (hour * 60 + minute);
  if (diffMin >  720) diffMin -= 1440;
  if (diffMin < -720) diffMin += 1440;

  // Subtract the offset to arrive at the correct UTC instant.
  return new Date(naiveUtc.getTime() - diffMin * 60000).toISOString();
}

// Convert UK ISO back to datetime-local format
function isoToLocalInput(isoStr) {
  if (!isoStr) return '';
  const d = new Date(isoStr);
  // Format as YYYY-MM-DDTHH:mm in UK timezone
  const parts = new Intl.DateTimeFormat('sv-SE', {
    timeZone: activeTZ,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit'
  }).formatToParts(d);
  const p = Object.fromEntries(parts.map(x => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`;
}

function esc(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function toast(msg, type = 'info', duration = 3500) {
  const c = document.getElementById('toast-container');
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<span style="flex:1">${esc(msg)}</span>`;
  c.appendChild(t);
  setTimeout(() => t.remove(), duration);
}

async function api(method, path, body) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const r = await fetch(path, opts);
  if (!r.ok) {
    const e = await r.json().catch(() => ({ error: r.statusText }));
    const err = new Error(e.message || e.error || r.statusText);
    err.status = r.status;
    err.data   = e;
    throw err;
  }
  return r.json();
}

// ── EPG Grid ─────────────────────────────────────────────────────────────────

class EPGGrid {
  constructor() {
    this.PX_PER_MIN  = 6;      // pixels per minute
    this.ROW_H       = 60;     // px, must match CSS .epg-channel-row / .epg-prog-row
    this.HOURS       = 4;      // hours of window shown
    this.channelBatch = 30;    // channels loaded at a time
    this.channelOffset = 0;

    this.channels  = [];       // all channel groups
    this.epgData   = {};       // stream_id → [programs]
    this.windowStart = null;   // Date object, start of visible window
    this._scrollHandler = null;
  }

  goToNow() {
    const now = nowUK();
    const mins = now.getMinutes() >= 30 ? 30 : 0;
    this.windowStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(),
                                now.getHours(), mins, 0, 0);
    this._syncDayPicker();
    this._render();
  }

  shiftTime(minutes) {
    this.windowStart = new Date(this.windowStart.getTime() + minutes * 60000);
    this._syncDayPicker();
    this._render();
  }

  shiftDay(days) {
    const d = new Date(this.windowStart.getTime() + days * 86400000);
    this.windowStart = d;
    this._syncDayPicker();
    this._render();
  }

  goToDay(dateStr) {
    // dateStr is YYYY-MM-DD from the date input
    const [y, mo, day] = dateStr.split('-').map(Number);
    const ws = this.windowStart;
    this.windowStart = new Date(y, mo - 1, day, ws.getHours(), ws.getMinutes(), 0, 0);
    this._render();
  }

  _syncDayPicker() {
    const el = document.getElementById('epg-day-input');
    if (!el) return;
    const ws = this.windowStart;
    const pad = n => String(n).padStart(2, '0');
    el.value = `${ws.getFullYear()}-${pad(ws.getMonth() + 1)}-${pad(ws.getDate())}`;
  }

  async loadMore() {
    this.channelOffset += this.channelBatch;
    await this._fetchEPGBatch();
    this._render();
  }

  async init(channels) {
    this.channels = channels;
    this.channelOffset = 0;
    this.goToNow();
    await this._fetchEPGBatch();
    this._render();
  }

  async _fetchEPGBatch() {
    const visible = this.channels.slice(this.channelOffset,
                                        this.channelOffset + this.channelBatch);
    const missing = visible.filter(g => !this.epgData[g.primary_stream_id]);

    if (!missing.length) return;

    try {
      const data = await api('POST', '/api/epg/bulk', {
        channels: missing.map(g => ({
          stream_id:      g.primary_stream_id,
          epg_channel_id: g.epg_channel_id || '',
        })),
        limit: 60,
      });
      Object.assign(this.epgData, data);
    } catch (e) {
      console.warn('EPG fetch failed:', e);
    }
  }

  _render() {
    const ws = this.windowStart;
    const we = new Date(ws.getTime() + this.HOURS * 3600000);

    // Update range label
    document.getElementById('epg-time-range').textContent =
      `${fmtTimeUK(ws.toISOString())} – ${fmtTimeUK(we.toISOString())}`;

    const totalPx = this.HOURS * 60 * this.PX_PER_MIN;
    let visible = this.channels.slice(0, this.channelOffset + this.channelBatch);

    // Post-fetch filter: when EPG-only is on, drop any channel whose fetched data
    // returned 0 entries (only applies once data has actually been fetched).
    if (this.postFilter) visible = this.postFilter(visible, this.epgData);

    // Time header
    this._renderTimeHeader(totalPx, ws);

    // Channels & programs
    const channelInner   = document.getElementById('epg-channel-inner');
    const programsInner  = document.getElementById('epg-programs-inner');

    channelInner.innerHTML  = '';
    programsInner.innerHTML = '';
    programsInner.style.width  = totalPx + 'px';
    programsInner.style.height = (visible.length * this.ROW_H) + 'px';

    // Now-line
    const nowLine = document.createElement('div');
    nowLine.className = 'epg-now-line';
    const nowOffset = (nowUK() - ws) / 60000 * this.PX_PER_MIN;
    if (nowOffset > 0 && nowOffset < totalPx) {
      nowLine.style.left = nowOffset + 'px';
      nowLine.style.display = 'block';
    } else {
      nowLine.style.display = 'none';
    }
    programsInner.appendChild(nowLine);

    visible.forEach((group, rowIdx) => {
      this._renderChannelRow(group, rowIdx, channelInner, programsInner, ws, totalPx);
    });

    this._bindScroll();
  }

  _renderTimeHeader(totalPx, windowStart) {
    const inner = document.getElementById('epg-time-inner');
    inner.style.width = totalPx + 'px';
    inner.innerHTML = '';
    for (let m = 0; m <= this.HOURS * 60; m += 30) {
      const t = new Date(windowStart.getTime() + m * 60000);
      const mark = document.createElement('div');
      mark.className = 'epg-time-mark';
      mark.style.left = (m * this.PX_PER_MIN) + 'px';
      mark.textContent = fmtTimeUK(t.toISOString());
      inner.appendChild(mark);
    }
  }

  _renderChannelRow(group, rowIdx, channelContainer, programsContainer, windowStart, totalPx) {
    // Channel name cell
    const cell = document.createElement('div');
    cell.className = 'epg-channel-row';
    cell.innerHTML = `
      ${group.stream_icon
        ? `<img src="${esc(group.stream_icon)}" alt="" onerror="this.style.display='none'">`
        : ''}
      <span class="epg-channel-row-name" title="${esc(group.display_name)}">${esc(group.display_name)}</span>
    `;
    cell.addEventListener('click', () => app.watchChannel(group));
    channelContainer.appendChild(cell);

    // Programs row
    const row = document.createElement('div');
    row.className = 'epg-prog-row';
    row.style.top = (rowIdx * this.ROW_H) + 'px';
    row.style.position = 'absolute';
    row.style.width = totalPx + 'px';
    row.style.height = this.ROW_H + 'px';

    const programs = this.epgData[group.primary_stream_id] || [];
    const windowEnd = new Date(windowStart.getTime() + this.HOURS * 3600000);

    if (programs.length === 0) {
      const noData = document.createElement('div');
      noData.className = 'epg-no-data';
      noData.textContent = 'No EPG data';
      row.appendChild(noData);
    }

    const now = nowUK();
    programs.forEach(prog => {
      if (!prog.start || !prog.end) return;
      const ps = new Date(prog.start);
      const pe = new Date(prog.end);

      // Skip programs entirely outside the window
      if (pe <= windowStart || ps >= windowEnd) return;

      const startMin  = Math.max(0, (ps - windowStart) / 60000);
      const endMin    = Math.min(this.HOURS * 60, (pe - windowStart) / 60000);
      const durMin    = endMin - startMin;
      if (durMin <= 0) return;

      const left  = startMin * this.PX_PER_MIN;
      const width = durMin * this.PX_PER_MIN - 2;

      const el = document.createElement('div');
      el.className = 'epg-program';
      const isNow = ps <= now && pe > now;
      const isPast = pe <= now;
      if (isNow)  el.classList.add('now-on');
      if (isPast) el.classList.add('is-past');
      el.style.left  = left + 'px';
      el.style.width = Math.max(2, width) + 'px';
      el.dataset.prog = JSON.stringify({
        title: prog.title,
        description: prog.description || '',
        start: prog.start,
        end: prog.end,
        channelId: group.primary_stream_id,
        channelName: group.display_name,
        group: group,
      });

      const titleEl = document.createElement('span');
      titleEl.className = 'epg-program-title';
      titleEl.textContent = prog.title || 'Unknown';
      el.appendChild(titleEl);

      if (isNow) {
        const pct = Math.min(1, Math.max(0, (now - ps) / (pe - ps)));
        const bar = document.createElement('div');
        bar.className = 'epg-prog-progress';
        bar.style.width = (pct * 100) + '%';
        el.appendChild(bar);
      }

      el.addEventListener('click', () => app.showProgram(el.dataset.prog));
      row.appendChild(el);
    });

    programsContainer.appendChild(row);
  }

  _bindScroll() {
    const progArea   = document.getElementById('epg-programs-area');
    const timeHeader = document.getElementById('epg-time-header');
    const chanInner  = document.getElementById('epg-channel-inner');

    // Remove previous listener before adding a new one
    if (this._scrollHandler) {
      progArea.removeEventListener('scroll', this._scrollHandler);
    }
    this._scrollHandler = () => {
      timeHeader.scrollLeft = progArea.scrollLeft;
      chanInner.style.transform = `translateY(-${progArea.scrollTop}px)`;
    };
    progArea.addEventListener('scroll', this._scrollHandler);

    // Scroll to current time minus a little bit
    const nowOffset = (nowUK() - this.windowStart) / 60000 * this.PX_PER_MIN;
    setTimeout(() => {
      progArea.scrollLeft = Math.max(0, nowOffset - 80);
    }, 50);
  }
}

// ── Main App ─────────────────────────────────────────────────────────────────

const app = (() => {
  let channels     = [];    // raw grouped channels
  let filteredChs  = [];
  let settings     = {};
  let hls          = null;
  let currentGroup = null;  // currently open channel group
  let epg          = new EPGGrid();
  // After each EPG data fetch, hide channels with 0 programmes when filter is on
  epg.postFilter = function(visible, epgData) {
    if (!_epgFilterEnabled || _xmltvChannelIds.size === 0) return visible;
    return visible.filter(g => {
      const progs = epgData[g.primary_stream_id];
      // undefined = not yet fetched → keep; empty array = fetched, no data → hide
      return progs === undefined || progs.length > 0;
    });
  };

  let _editingRecId = null; // non-null when editing an existing recording

  // ── EPG filter / search state ───────────────────────────────────────────
  let _xmltvChannelIds  = new Set();   // epg_channel_id values in the XMLTV cache
  let _epgChannelMap    = {};          // epg_channel_id → channel group
  let _epgFilterEnabled = true;        // only show channels with EPG data
  let _epgChannelFilter = '';          // text filter on channel/category name
  let _epgShowSearch    = '';          // text search for show titles
  let _epgSearchTimer   = null;
  let _searchResults    = [];          // last show-search result set (indexed by position)

  // Expose epg for template calls
  const pub = { epg };

  // ── Navigation ─────────────────────────────────────────────────────────

  pub.navigateTo = function(viewName) {
    // Block Movies and TV Shows in trial mode
    if (_trialStatus?.trial && (viewName === 'movies' || viewName === 'tvshows')) {
      pub.showPaywall();
      return;
    }

    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

    const view = document.getElementById(`view-${viewName}`);
    if (view) view.classList.add('active');

    const navItem = document.querySelector(`[data-view="${viewName}"]`);
    if (navItem) navItem.classList.add('active');

    const titles = {
      'home':      'Home',
      'live-tv':   'Live TV',
      'epg':       'TV Guide',
      'recordings':'Recordings',
      'sports':    'Sports',
      'movies':    'Movies',
      'tvshows':   'TV Shows',
      'settings':  'Settings',
      'downloads': 'Tasks & Files',
      'help':      'Help',
    };
    document.getElementById('topbar-title').textContent = titles[viewName] || '';
    document.getElementById('search-box').style.display =
      (viewName === 'live-tv') ? '' : 'none';

    // Inject remote-device notice once per affected view
    if (!IS_LOCAL && ['live-tv', 'movies', 'tvshows'].includes(viewName)) {
      const noticeId = `remote-notice-${viewName}`;
      if (!document.getElementById(noticeId)) {
        const notice = document.createElement('div');
        notice.id = noticeId;
        notice.className = 'remote-notice';
        notice.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>` +
          `Playback is only available on the host device. You can still manage recordings and schedules.`;
        if (view) view.insertBefore(notice, view.firstChild);
      }
    }

    if (viewName === 'sports') pub.loadSports();
    if (viewName === 'movies')  pub.loadMovies();
    if (viewName === 'tvshows') pub.loadTVShows();
    if (viewName === 'home')    pub.loadDashboard();
    if (viewName === 'epg' && channels.length) {
      // Clear any lingering show search
      const showSearchInput = document.getElementById('epg-show-search');
      if (showSearchInput) showSearchInput.value = '';
      _epgShowSearch = '';
      _renderShowResults(null);
      _ensureXmltvLoaded();
      epg.init(_filteredEpgChannels());
    }
    if (viewName === 'recordings') {
      pub.loadRecordings();
    }
    if (viewName === 'settings') {
      pub.loadSettings();
      _loadNetworkInfo();
    }
    if (viewName === 'downloads') pub.loadDownloadsPage();
    // Close sidebar overlay on mobile after navigation
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebar-backdrop').classList.remove('visible');
  };

  // ── Channels ───────────────────────────────────────────────────────────

  async function loadChannels() {
    try {
      channels = await api('GET', '/api/channels');
      filteredChs = channels;
      _buildEpgChannelMap();
      renderChannelGrid(filteredChs);
    } catch (e) {
      toast('Failed to load channels: ' + e.message, 'error');
    }
  }

  // ── EPG channel map & filter helpers ────────────────────────────────────

  function _buildEpgChannelMap() {
    _epgChannelMap = {};
    channels.forEach(ch => {
      if (ch.epg_channel_id) _epgChannelMap[ch.epg_channel_id] = ch;
    });
  }

  function _filteredEpgChannels() {
    let result = channels;
    // Apply EPG-data filter only when XMLTV is loaded
    if (_epgFilterEnabled && _xmltvChannelIds.size > 0) {
      result = result.filter(ch =>
        ch.epg_channel_id && _xmltvChannelIds.has(ch.epg_channel_id)
      );
    }
    // Apply channel name / category text filter
    if (_epgChannelFilter) {
      const q = _epgChannelFilter.toLowerCase();
      result = result.filter(ch =>
        ch.display_name.toLowerCase().includes(q) ||
        (ch.group_title && ch.group_title.toLowerCase().includes(q))
      );
    }
    return result;
  }

  async function _loadXmltvChannelIds() {
    try {
      const data = await api('GET', '/api/epg/xmltv/channel-ids');
      _xmltvChannelIds = new Set(data.channel_ids || []);
    } catch (e) {
      // Non-critical
    }
  }

  function _reInitEpgIfActive() {
    const epgView = document.getElementById('view-epg');
    if (epgView && epgView.classList.contains('active') && channels.length) {
      epg.init(_filteredEpgChannels());
    }
  }

  // ── EPG channel filter ───────────────────────────────────────────────────

  pub.onEpgChannelSearch = function(query) {
    _epgChannelFilter = query.trim();
    _reInitEpgIfActive();
  };

  pub.onEpgFilterToggle = function(checked) {
    _epgFilterEnabled = checked;
    // Save preference immediately
    api('POST', '/api/settings', { epg_filter_channels: checked ? '1' : '0' }).catch(() => {});
    _reInitEpgIfActive();
  };

  // ── EPG show search ──────────────────────────────────────────────────────

  pub.onEpgShowSearch = function(query) {
    _epgShowSearch = query.trim();
    clearTimeout(_epgSearchTimer);
    if (!_epgShowSearch) {
      _renderShowResults(null);   // clear → restore grid
      return;
    }
    _epgSearchTimer = setTimeout(() => _doShowSearch(_epgShowSearch), 350);
  };

  async function _doShowSearch(query) {
    try {
      const results = await api('GET', `/api/epg/search?q=${encodeURIComponent(query)}&limit=150`);
      _renderShowResults(results);
    } catch (e) {
      _renderShowResults([]);
    }
  }

  function _renderShowResults(results) {
    const panel     = document.getElementById('epg-show-results');
    const inner     = document.getElementById('epg-show-results-inner');
    const container = document.getElementById('epg-container');

    if (!results) {
      // Clear / restore grid view
      _searchResults = [];
      panel.style.display     = 'none';
      container.style.display = '';
      return;
    }

    _searchResults = results;
    panel.style.display     = '';
    container.style.display = 'none';

    if (results.length === 0) {
      inner.innerHTML =
        '<div class="empty-state" style="height:200px"><p>No shows found. ' +
        'Make sure EPG data is loaded (↺ Refresh EPG) and try a different keyword.</p></div>';
      return;
    }

    const now = new Date();
    inner.innerHTML = results.map((r, i) => {
      const group  = _epgChannelMap[r.epg_channel_id];
      const isPast = r.end && new Date(r.end) < now;
      const chName = esc(group ? group.display_name : (r.epg_channel_id || 'Unknown channel'));

      return `
        <div class="epg-show-result${isPast ? ' is-past' : ''}">
          <div class="epg-show-result-ch">
            ${group && group.stream_icon
              ? `<img src="${esc(group.stream_icon)}" alt="" onerror="this.style.display='none'">`
              : '<div style="width:32px;height:32px;background:var(--bg-hover);border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:16px;">📺</div>'}
            <div class="epg-show-result-ch-name" title="${chName}">${chName}</div>
          </div>
          <div class="epg-show-result-info">
            <div class="epg-show-result-time">
              ${fmtDateTimeUK(r.start)}${r.end ? ' – ' + fmtTimeUK(r.end) : ''}${isPast ? ' · <em>past</em>' : ''}
            </div>
            <div class="epg-show-result-title">${esc(r.title)}</div>
            ${r.description ? `<div class="epg-show-result-desc">${esc(r.description)}</div>` : ''}
          </div>
          <div class="epg-show-result-actions">
            ${group ? `<button class="btn btn-ghost btn-sm" onclick="app.watchFromSearch(${i})">▶ Watch</button>` : ''}
            <button class="btn btn-danger btn-sm" onclick="app.recordFromSearch(${i})">⏺ Record</button>
            <button class="btn btn-ghost btn-sm" onclick="app.recordFromSearchRecurring(${i})">↻ Weekly</button>
          </div>
        </div>
      `;
    }).join('');
  }

  pub.watchFromSearch = function(idx) {
    const group = _epgChannelMap[_searchResults[idx]?.epg_channel_id];
    if (group) pub.watchChannel(group);
    else toast('Channel not available for live playback', 'info');
  };

  pub.recordFromSearch = function(idx) {
    const r     = _searchResults[idx];
    const group = _epgChannelMap[r.epg_channel_id] || null;
    pub.openScheduleModal(group, r);
  };

  pub.recordFromSearchRecurring = function(idx) {
    pub.recordFromSearch(idx);
    setTimeout(() => _applyWeeklyRecurrence(_searchResults[idx]?.start, _searchResults[idx]?.end), 50);
  };

  function _applyWeeklyRecurrence(startIso, endIso) {
    document.getElementById('rec-is-recurring').checked = true;
    pub.onRecurrenceChange();
    if (startIso) {
      // Pre-fill the recurrence time from the programme start
      const localVal = isoToLocalInput(startIso);
      const time = localVal.split('T')[1] || '21:00';
      document.getElementById('rec-rec-start').value = time;
      // day-of-week: JS getDay() is 0=Sun; our picker is 0=Mon
      const d   = new Date(startIso);
      const dow = (d.getDay() + 6) % 7;
      // Tick only the matching day
      document.querySelectorAll('input[name="rec-dow"]').forEach(cb => {
        cb.checked = parseInt(cb.value) === dow;
      });
    }
    if (endIso) {
      const localVal = isoToLocalInput(endIso);
      const time = localVal.split('T')[1] || '22:00';
      document.getElementById('rec-rec-end').value = time;
    }
  }

  pub.refreshChannels = async function() {
    toast('Refreshing channel list…', 'info');
    try {
      const result = await api('POST', '/api/channels/refresh');
      channels = await api('GET', '/api/channels');
      filteredChs = channels;
      renderChannelGrid(filteredChs);
      toast(`Loaded ${result.count} channel groups`, 'success');
    } catch (e) {
      toast('Refresh failed: ' + e.message, 'error');
    }
  };

  pub.onSearch = function(query) {
    const q = query.toLowerCase().trim();
    filteredChs = q
      ? channels.filter(g => g.display_name.toLowerCase().includes(q))
      : channels;
    renderChannelGrid(filteredChs);
  };

  function renderChannelGrid(groups) {
    const grid  = document.getElementById('channel-grid');
    const empty = document.getElementById('channel-empty');

    if (!groups || groups.length === 0) {
      grid.innerHTML  = '';
      empty.style.display = 'flex';
      return;
    }
    empty.style.display = 'none';

    grid.innerHTML = groups.map(g => `
      <div class="channel-card" onclick='app.watchChannel(${JSON.stringify(g)})'>
        ${g.stream_icon
          ? `<img class="logo" src="${esc(g.stream_icon)}" alt="" onerror="this.style.display='none'">`
          : `<div class="logo-placeholder">📺</div>`}
        <div class="channel-name">${esc(g.display_name)}</div>
        <div class="now-playing" id="now-${g.primary_stream_id}">Loading…</div>
        ${g.has_multiple ? `<span class="variant-badge">+${g.variants.length}</span>` : ''}
      </div>
    `).join('');

    // Lazy-load EPG for "now playing" labels in batches
    loadNowPlaying(groups.slice(0, 40));
  }

  async function loadNowPlaying(groups) {
    try {
      const data = await api('POST', '/api/epg/bulk', {
        channels: groups.map(g => ({
          stream_id:      g.primary_stream_id,
          epg_channel_id: g.epg_channel_id || '',
        })),
        limit: 5,
      });
      const now = nowUK();
      groups.forEach(g => {
        const el = document.getElementById(`now-${g.primary_stream_id}`);
        if (!el) return;
        const progs = data[g.primary_stream_id] || [];
        const current = progs.find(p => p.start && p.end &&
          new Date(p.start) <= now && new Date(p.end) > now);
        el.textContent = current ? current.title : '';
      });
    } catch (e) {
      // EPG optional - silently ignore
    }
  }

  // ── Player ─────────────────────────────────────────────────────────────

  pub.watchChannel = async function(group) {
    if (!IS_LOCAL) { toast('Live TV playback is only available on the host device.', 'info', 4000); return; }
    if (typeof group === 'string') group = JSON.parse(group);
    currentGroup = group;
    try {
      toast(`Opening ${group.display_name}…`, 'info', 2000);
      await api('POST', `/api/play/${group.primary_stream_id}`, { title: group.display_name });
    } catch (e) {
      toast('Could not open player: ' + e.message, 'error');
    }
  };

  pub.switchVariant = function(streamId) {
    document.getElementById('player-loading').style.display = 'flex';
    _loadStream(parseInt(streamId));
  };

  function _loadStream(streamId) {
    const video = document.getElementById('video-player');

    if (hls) {
      hls.destroy();
      hls = null;
    }

    const proxyUrl = `/api/hls/${streamId}.m3u8`;

    if (Hls.isSupported()) {
      hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
      });
      hls.loadSource(proxyUrl);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        document.getElementById('player-loading').style.display = 'none';
        document.getElementById('player-stream-type').textContent = 'HLS stream';
        video.play().catch(() => {});
      });
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) {
          document.getElementById('player-loading').innerHTML =
            `<span style="color:var(--rec)">Stream error - try a different quality variant</span>`;
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Safari native HLS
      video.src = proxyUrl;
      video.addEventListener('loadeddata', () => {
        document.getElementById('player-loading').style.display = 'none';
      }, { once: true });
      video.play().catch(() => {});
    } else {
      document.getElementById('player-loading').innerHTML =
        `<span>HLS not supported in this browser.</span>`;
    }
  }

  async function _loadNowPlayingForPlayer(streamId) {
    try {
      const progs = await api('GET', `/api/epg/${streamId}?limit=5`);
      const now = nowUK();
      const current = progs.find(p =>
        p.start && p.end && new Date(p.start) <= now && new Date(p.end) > now
      );
      if (current) {
        document.getElementById('player-now-playing').textContent =
          `${fmtTimeUK(current.start)}–${fmtTimeUK(current.end)}  ${current.title}`;
      }
    } catch (e) {}
  }

  pub.closePlayer = function() {
    document.getElementById('player-modal').classList.remove('open');
    const video = document.getElementById('video-player');
    video.pause();
    if (hls) { hls.destroy(); hls = null; }
    video.src = '';
    // Restore live-only controls
    document.getElementById('player-variant-select').style.display = '';
    const recBtn = document.querySelector('#player-header .btn-primary');
    if (recBtn) recBtn.style.display = '';
  };

  pub.recordFromPlayer = function() {
    if (!currentGroup) return;
    pub.closePlayer();
    pub.openScheduleModal(currentGroup);
  };

  pub.watchRecording = async function(recId, title) {
    try {
      toast(`Opening ${title || 'recording'} in player\u2026`, 'info', 2500);
      await api('POST', `/api/recordings/${recId}/play`);
    } catch (e) {
      toast('Could not open player: ' + e.message, 'error');
    }
  };

  // ── Sidebar toggle (mobile) ─────────────────────────────────────────────
  pub.toggleSidebar = function() {
    const sidebar  = document.getElementById('sidebar');
    const backdrop = document.getElementById('sidebar-backdrop');
    const isOpen   = sidebar.classList.toggle('open');
    backdrop.classList.toggle('visible', isOpen);
  };

  // ── EPG program detail ──────────────────────────────────────────────────

  let _currentProg = null;

  pub.showProgram = function(dataStr) {
    _currentProg = JSON.parse(dataStr);
    const { title, description, start, end } = _currentProg;

    document.getElementById('prog-time').textContent =
      `${fmtDateTimeUK(start)} – ${fmtTimeUK(end)}`;
    document.getElementById('prog-title').textContent  = title || '';
    document.getElementById('prog-desc').textContent   = description || 'No description available.';

    document.getElementById('prog-modal').classList.add('open');
  };

  pub.showProgramDetails = pub.showProgram; // alias for template

  pub.closeProgModal = function() {
    document.getElementById('prog-modal').classList.remove('open');
    _currentProg = null;
  };

  pub.watchFromEPG = function() {
    if (!_currentProg) return;
    pub.closeProgModal();
    const g = typeof _currentProg.group === 'string'
      ? JSON.parse(_currentProg.group) : _currentProg.group;
    pub.watchChannel(g || { primary_stream_id: _currentProg.channelId,
                             display_name: _currentProg.channelName,
                             variants: [], has_multiple: false });
  };

  pub.recordFromEPG = function() {
    if (!_currentProg) return;
    // Save references BEFORE closeProgModal clears _currentProg
    const prog = _currentProg;
    const g = typeof prog.group === 'string' ? JSON.parse(prog.group) : prog.group;
    pub.closeProgModal();
    pub.openScheduleModal(g, prog);
  };

  pub.recordFromEPGRecurring = function() {
    if (!_currentProg) return;
    const prog = _currentProg;
    const g = typeof prog.group === 'string' ? JSON.parse(prog.group) : prog.group;
    pub.closeProgModal();
    pub.openScheduleModal(g, prog);
    setTimeout(() => _applyWeeklyRecurrence(prog.start, prog.end), 50);
  };

  // ── Schedule recording modal ────────────────────────────────────────────

  let _recCategoryFilter = '';
  let _recSearchFilter   = '';

  function _getCategories() {
    return [...new Set(channels.map(g => g.group_title).filter(Boolean))].sort();
  }

  function _filteredChannels() {
    return channels.filter(g => {
      const catOk   = !_recCategoryFilter || g.group_title === _recCategoryFilter;
      const nameOk  = !_recSearchFilter   ||
                      g.display_name.toLowerCase().includes(_recSearchFilter.toLowerCase());
      return catOk && nameOk;
    });
  }

  function _renderRecChannelOptions(selectedId) {
    const sel = document.getElementById('rec-channel');
    const filtered = _filteredChannels();
    sel.innerHTML = '<option value="">- select channel -</option>' +
      filtered.map(g =>
        `<option value="${g.primary_stream_id}"` +
        (g.primary_stream_id == selectedId ? ' selected' : '') +
        ` data-group='${JSON.stringify(g).replace(/'/g, "&#39;")}'>${esc(g.display_name)}</option>`
      ).join('');
    if (selectedId) pub.onRecChannelChange();
  }

  pub.onRecCategoryChange = function() {
    _recCategoryFilter = document.getElementById('rec-category').value;
    _renderRecChannelOptions(null);
  };

  pub.onRecChannelSearch = function(query) {
    _recSearchFilter = query;
    _renderRecChannelOptions(null);
  };

  pub.openScheduleModal = function(group, prog) {
    // A null group means the channel wasn't matched in the channel list
    if (!group) group = { primary_stream_id: null, display_name: '', group_title: '', variants: [], has_multiple: false };

    // Reset edit state - this is a new recording
    _editingRecId = null;
    document.getElementById('schedule-modal-title').textContent = 'Schedule Recording';

    // Populate category dropdown
    const catSel = document.getElementById('rec-category');
    catSel.innerHTML = '<option value="">All categories</option>' +
      _getCategories().map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join('');

    // Reset filters, then optionally pre-select the category of the provided group
    _recSearchFilter = '';
    document.getElementById('rec-channel-search').value = '';
    _recCategoryFilter = (group && group.group_title) ? group.group_title : '';
    catSel.value = _recCategoryFilter;

    // Populate the channel list (pre-selecting the channel if a group was passed)
    _renderRecChannelOptions(group ? group.primary_stream_id : null);

    // Pre-fill from group if provided
    if (group) {
      pub.onRecChannelChange();
    }

    // Pre-fill times from program if provided
    if (prog) {
      if (prog.start) document.getElementById('rec-start').value = isoToLocalInput(prog.start);
      if (prog.end)   document.getElementById('rec-end').value   = isoToLocalInput(prog.end);
      if (prog.title) document.getElementById('rec-show-name').value = prog.title;
    } else {
      // Default: now + 1h
      const now = new Date();
      const end = new Date(now.getTime() + 3600000);
      document.getElementById('rec-start').value = isoToLocalInput(now.toISOString());
      document.getElementById('rec-end').value   = isoToLocalInput(end.toISOString());
    }

    // Default save path and clear numbering fields
    document.getElementById('rec-save-path').value  = settings.default_save_path || '';
    document.getElementById('rec-season').value     = '';
    document.getElementById('rec-episode').value    = '';
    document.getElementById('rec-pad-start').value  = 0;
    document.getElementById('rec-pad-end').value    = 0;

    // Reset quality fields, pre-filled from defaults so user sees what will apply
    const dq = settings.default_quality || {};
    document.getElementById('rec-codec').value                = '';  // "Use default"
    document.getElementById('rec-resolution').value           = '';
    document.getElementById('rec-transcode-after').checked    = !!dq.transcode_after;
    document.getElementById('rec-transcode-codec').value      = dq.transcode_codec || 'hevc';
    document.getElementById('rec-transcode-resolution').value = dq.transcode_resolution || '1920x1080';
    document.getElementById('rec-transcode-crf').value        = dq.transcode_crf ?? 18;
    document.getElementById('rec-transcode-preset').value     = dq.transcode_preset || 'medium';

    // Reset recurrence to one-time
    document.getElementById('rec-is-recurring').checked = false;
    document.querySelectorAll('input[name="rec-dow"]').forEach(cb => cb.checked = false);
    document.getElementById('rec-rec-start').value = '21:00';
    document.getElementById('rec-rec-end').value   = '22:00';
    pub.onRecurrenceChange();
    pub.onRecCodecChange();

    document.getElementById('schedule-modal').classList.add('open');
  };

  pub.closeScheduleModal = function() {
    document.getElementById('schedule-modal').classList.remove('open');
  };

  pub.onRecChannelChange = function() {
    const sel = document.getElementById('rec-channel');
    const opt = sel.selectedOptions[0];
    if (!opt || !opt.dataset.group) {
      document.getElementById('rec-variant-row').style.display = 'none';
      return;
    }
    const g = JSON.parse(opt.dataset.group.replace(/&#39;/g, "'"));
    const varSel = document.getElementById('rec-variant');
    if (g.variants && g.variants.length > 1) {
      varSel.innerHTML = g.variants.map(v =>
        `<option value="${v.stream_id}">${esc(v.name)} (${v.quality})</option>`
      ).join('');
      document.getElementById('rec-variant-row').style.display = '';
    } else {
      document.getElementById('rec-variant-row').style.display = 'none';
    }
  };

  pub.onRecurrenceChange = function() {
    const recurring = document.getElementById('rec-is-recurring').checked;
    document.getElementById('rec-onetime-times').style.display    = recurring ? 'none' : '';
    document.getElementById('rec-recurring-section').style.display = recurring ? '' : 'none';
  };

  pub.onRecCodecChange = function() {
    const val    = document.getElementById('rec-codec').value;
    const isCopy = val === 'copy' || val === '';  // '' = use default, which is copy
    document.getElementById('rec-transcode-section').style.display = isCopy ? '' : 'none';
    if (!isCopy) document.getElementById('rec-transcode-after').checked = false;
    // Update label to clarify when "Use default" is selected
    const lbl = document.querySelector('#rec-transcode-after + span, label[for="rec-transcode-after"]');
    const chk = document.getElementById('rec-transcode-after');
    if (chk && chk.parentElement) {
      const note = val === '' ? ' <span style="color:var(--text-dim);font-size:11px;">(from default settings)</span>' : '';
      chk.parentElement.querySelector('.tc-default-note')?.remove();
      if (note && val === '') {
        const span = document.createElement('span');
        span.className = 'tc-default-note';
        span.style.cssText = 'color:var(--text-dim);font-size:11px;margin-left:4px;';
        span.textContent = '(from default settings)';
        chk.parentElement.appendChild(span);
      }
    }
    pub.onRecTranscodeChange();
  };

  pub.onRecTranscodeChange = function() {
    const show = document.getElementById('rec-transcode-after').checked;
    document.getElementById('rec-transcode-target').style.display = show ? '' : 'none';
  };

  pub.onSettingsCodecChange = function() {
    const isCopy = document.getElementById('s-codec').value === 'copy';
    document.getElementById('s-transcode-section').style.display = isCopy ? '' : 'none';
    if (!isCopy) document.getElementById('s-transcode-after').checked = false;
    pub.onSettingsTranscodeChange();
  };

  pub.onSettingsTranscodeChange = function() {
    const show = document.getElementById('s-transcode-after').checked;
    document.getElementById('s-transcode-target').style.display = show ? '' : 'none';
  };

  pub.setDowPreset = function(preset) {
    const boxes = document.querySelectorAll('input[name="rec-dow"]');
    boxes.forEach(cb => {
      const v = parseInt(cb.value);
      if (preset === 'weekdays') cb.checked = v <= 4;
      else if (preset === 'weekends') cb.checked = v >= 5;
      else cb.checked = true; // every
    });
  };

  pub.submitRecording = async function() {
    const chanSel = document.getElementById('rec-channel');
    const varSel  = document.getElementById('rec-variant');

    // Use variant stream ID if visible, otherwise primary
    const varRow = document.getElementById('rec-variant-row');
    const channelId = (varRow.style.display !== 'none' && varSel.value)
      ? varSel.value
      : chanSel.value;

    const channelName = chanSel.selectedOptions[0]?.text || '';
    const showName    = document.getElementById('rec-show-name').value.trim();
    const savePath    = document.getElementById('rec-save-path').value.trim();
    const isRecurring = document.getElementById('rec-is-recurring').checked;

    if (!channelId)  { toast('Please select a channel', 'error'); return; }
    if (!showName)   { toast('Please enter a show name', 'error'); return; }
    if (!savePath)   { toast('Please enter a save path', 'error'); return; }

    // Quality overrides
    const codec      = document.getElementById('rec-codec').value;
    const resolution = document.getElementById('rec-resolution').value;
    const quality    = {};
    if (codec)      quality.codec      = codec;
    if (resolution) quality.resolution = resolution;

    // Transcode settings apply when codec is copy (explicit or via default)
    if (codec === 'copy' || codec === '') {
      const transcodeAfter = document.getElementById('rec-transcode-after').checked;
      quality.transcode_after = transcodeAfter;
      if (transcodeAfter) {
        quality.transcode_codec      = document.getElementById('rec-transcode-codec').value;
        quality.transcode_resolution = document.getElementById('rec-transcode-resolution').value || '1920x1080';
        quality.transcode_crf        = parseInt(document.getElementById('rec-transcode-crf').value) || 18;
        quality.transcode_preset     = document.getElementById('rec-transcode-preset').value;
        // If codec is "use default" but transcode is on, lock to copy so
        // the backend knows to capture as copy before transcoding
        if (!quality.codec) quality.codec = 'copy';
      }
    }

    const padStart = parseInt(document.getElementById('rec-pad-start').value) || 0;
    const padEnd   = parseInt(document.getElementById('rec-pad-end').value)   || 0;

    let body = {
      channel_id:    channelId,
      channel_name:  channelName.replace(/\s*\(.*\)$/, ''),
      show_name:     showName,
      season:        parseInt(document.getElementById('rec-season').value)  || 0,
      episode:       parseInt(document.getElementById('rec-episode').value) || 0,
      save_path:     savePath,
      quality:       Object.keys(quality).length ? quality : null,
      padding_start: padStart,
      padding_end:   padEnd,
    };

    if (isRecurring) {
      // Gather checked day-of-week values
      const days = [...document.querySelectorAll('input[name="rec-dow"]:checked')]
        .map(cb => parseInt(cb.value));
      if (days.length === 0) { toast('Please select at least one day', 'error'); return; }

      const timeStart = document.getElementById('rec-rec-start').value || '21:00';
      const timeEnd   = document.getElementById('rec-rec-end').value   || '22:00';

      // Compute start/end ISO strings using today's date + the given times
      const todayLocal = isoToLocalInput(new Date().toISOString()).split('T')[0];
      body.start_time  = localInputToISO(`${todayLocal}T${timeStart}`);
      body.end_time    = localInputToISO(`${todayLocal}T${timeEnd}`);
      body.type        = 'recurring';
      body.recurrence  = { days, time_start: timeStart, time_end: timeEnd };
    } else {
      const startVal = document.getElementById('rec-start').value;
      const endVal   = document.getElementById('rec-end').value;
      if (!startVal || !endVal) { toast('Please set start and end times', 'error'); return; }
      body.start_time = localInputToISO(startVal);
      body.end_time   = localInputToISO(endVal);
      body.type       = 'once';
    }

    try {
      if (_editingRecId) {
        await api('PUT', `/api/recordings/${_editingRecId}`, body);
        toast('Recording updated!', 'success');
      } else {
        await api('POST', '/api/recordings', body);
        toast('Recording scheduled!', 'success');
        _checkTrialStatus(); // refresh trial counter after scheduling
      }
      _editingRecId = null;
      pub.closeScheduleModal();
      pub.loadRecordings();
    } catch (e) {
      if (e.status === 402) {
        pub.closeScheduleModal();
        pub.showPaywall();
      } else {
        toast('Failed: ' + e.message, 'error');
      }
    }
  };

  // ── XMLTV EPG ──────────────────────────────────────────────────────────

  let _xmltvLoading    = false;
  let _xmltvLoadedOnce = false;
  let _xmltvPromise    = null;   // resolves when XMLTV is ready

  function _ensureXmltvLoaded() {
    if (_xmltvPromise) return _xmltvPromise;
    _xmltvPromise = _doEnsureXmltvLoaded();
    return _xmltvPromise;
  }

  async function _doEnsureXmltvLoaded() {
    if (_xmltvLoading) return;
    try {
      const status = await api('GET', '/api/epg/xmltv/status');
      _updateEpgStatus(status);
      if (status.loaded) {
        await _loadXmltvChannelIds();
        _reInitEpgIfActive();
        _xmltvLoadedOnce = true;
      } else {
        await pub.refreshXmltv();   // await the full refresh
      }
    } catch (e) {
      // Non-fatal - EPG will fall back to JSON API
    }
  }

  pub.refreshXmltv = async function() {
    if (_xmltvLoading) return;
    _xmltvLoading = true;
    const btn = document.getElementById('epg-refresh-btn');
    const lbl = document.getElementById('epg-status-label');
    if (btn) btn.disabled = true;
    if (lbl) lbl.textContent = 'Loading EPG data…';

    try {
      const result = await api('POST', '/api/epg/xmltv/refresh');
      if (lbl) lbl.textContent = `EPG loaded - ${result.channels} channels`;
      // Load channel ID list, then re-filter and re-render
      await _loadXmltvChannelIds();
      epg.epgData = {};
      epg.init(_filteredEpgChannels());
      // Sync the toggle state
      const toggle = document.getElementById('epg-only-toggle');
      if (toggle) toggle.checked = _epgFilterEnabled;
    } catch (e) {
      if (lbl) lbl.textContent = 'EPG load failed';
      toast('EPG refresh failed: ' + e.message, 'error');
    } finally {
      _xmltvLoading = false;
      if (btn) btn.disabled = false;
    }
  };

  function _updateEpgStatus(status) {
    const lbl = document.getElementById('epg-status-label');
    if (!lbl) return;
    if (status.loaded) {
      const when = status.last_fetch
        ? fmtUK(status.last_fetch, { hour: '2-digit', minute: '2-digit' })
        : '';
      lbl.textContent = `EPG loaded - ${status.channels} channels${when ? ' · ' + when : ''}`;
    } else {
      lbl.textContent = 'EPG not loaded';
    }
  }

  // ── Recordings list ─────────────────────────────────────────────────────

  let _recs = [];  // cache for export

  pub.loadRecordings = async function() {
    try {
      _recs = await api('GET', '/api/recordings');
      renderRecordings(_recs);
      // Start polling if any recording is currently transcoding
      if (_recs.some(r => r.status === 'transcoding')) _startDownloadPolling();
    } catch (e) {
      toast('Failed to load recordings: ' + e.message, 'error');
    }
  };

  function renderRecordings(recs) {
    const list  = document.getElementById('recordings-list');
    const empty = document.getElementById('recordings-empty');

    if (!recs || recs.length === 0) {
      list.innerHTML = '';
      empty.style.display = 'flex';
      return;
    }
    empty.style.display = 'none';

    // Group: active/recording first, then upcoming, then recurring, then done
    const order = { recording: 0, scheduled: 1, recurring: 2, completed: 3, failed: 4, cancelled: 5 };
    recs.sort((a, b) => (order[a.status] ?? 9) - (order[b.status] ?? 9) ||
                         new Date(a.start_time) - new Date(b.start_time));

    list.innerHTML = recs.map(r => {
      const s = parseInt(r.season)  || 0;
      const e = parseInt(r.episode) || 0;
      const epLabel = s && e ? `S${String(s).padStart(2,'0')}E${String(e).padStart(2,'0')}`
                    : e      ? `E${String(e).padStart(2,'0')}`
                    : '';
      const isPaused = r.status === 'recurring' && r.paused_until &&
                       new Date(r.paused_until) > new Date();
      const pausedLabel = isPaused
        ? ` <span class="badge-paused">Paused until ${fmtUK(r.paused_until, {day:'numeric',month:'short',year:'numeric'})}</span>`
        : '';
      const timeStr = r.status === 'recurring'
        ? _recurrenceLabel(r.recurrence)
        : `${fmtDateTimeUK(r.start_time)} → ${fmtTimeUK(r.end_time)}`;
      // Occurrence badge: shown on child rows spawned from a recurring template
      const occurrenceBadge = r.parent_id
        ? `&nbsp;·&nbsp; <span class="badge" style="background:rgba(10,132,255,0.12);color:var(--accent);border:1px solid rgba(10,132,255,0.22);" title="Generated from recurring schedule">↻ Recurring</span>`
        : '';

      const q = r.quality || {};
      const effectiveCodec = q.transcode_after ? (q.transcode_codec || 'hevc') : q.codec;
      const qualLabel = effectiveCodec ? `${effectiveCodec.toUpperCase()} ${q.resolution || ''}`.trim() : '';

      const ps = parseInt(r.padding_start) || 0;
      const pe = parseInt(r.padding_end)   || 0;
      const padLabel = (ps || pe)
        ? (ps && pe ? `+${ps}m / +${pe}m` : ps ? `+${ps}m early` : `+${pe}m late`)
        : '';

      return `
        <div class="recording-item">
          <div class="rec-status ${r.status}" title="${r.status}"></div>
          <div class="rec-info">
            <div class="rec-title">${esc(r.show_name)}${epLabel ? ` - ${epLabel}` : ''}</div>
            <div class="rec-meta">
              ${esc(r.channel_name)} &nbsp;·&nbsp; ${esc(timeStr)}
              ${qualLabel ? `&nbsp;·&nbsp; <span class="badge badge-hevc">${esc(qualLabel)}</span>` : ''}
              ${padLabel  ? `&nbsp;·&nbsp; <span class="badge" style="background:rgba(48,209,88,0.12);color:var(--success);border:1px solid rgba(48,209,88,0.22);" title="Padding: starts ${ps}m early, ends ${pe}m late">⏱ ${esc(padLabel)}</span>` : ''}
              ${occurrenceBadge}
              ${pausedLabel}
              ${r.output_file ? `<br><span style="color:var(--text-dim);font-size:10px;">${esc(r.output_file)}</span>` : ''}
            </div>
          </div>
          <div class="rec-actions">
            ${r.status === 'recording'
              ? `<button class="btn btn-danger btn-sm" onclick="app.stopRecording('${r.id}')">Stop</button>`
              : ''}
            ${r.status === 'transcoding'
              ? `<span class="badge" style="background:rgba(100,210,255,0.12);color:var(--cyan);border:1px solid rgba(100,210,255,0.22);">⚙ Transcoding…</span>`
              : ''}
            ${r.status === 'completed' && r.output_file
              ? `<button class="btn btn-primary btn-sm" onclick="app.watchRecording('${r.id}', ${JSON.stringify(r.show_name).replace(/"/g, '&quot;')})">▶ Watch</button>`
              : ''}
            ${r.status === 'recurring'
              ? (isPaused
                  ? `<button class="btn btn-ghost btn-sm" onclick="app.resumeRecording('${r.id}')">Resume</button>`
                  : `<button class="btn btn-ghost btn-sm" onclick="app.pauseRecording('${r.id}', ${JSON.stringify(r.show_name).replace(/"/g, '&quot;')})">Pause</button>`)
              : ''}
            ${(r.status === 'scheduled' || r.status === 'recurring') && !r.parent_id
              ? `<button class="btn btn-ghost btn-sm" onclick="app.editRecording('${r.id}')">Edit</button>`
              : ''}
            <button class="btn btn-ghost btn-sm" onclick="app.deleteRecording('${r.id}', ${JSON.stringify(r.show_name).replace(/"/g, '&quot;')})">Delete</button>
          </div>
        </div>
      `;
    }).join('');
  }

  function _recurrenceLabel(rec) {
    if (!rec) return '';
    const DOW_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
    // New format
    if (rec.days) {
      const dayNames = rec.days.map(d => DOW_NAMES[d] || '?').join(', ');
      return `${dayNames} at ${rec.time_start}–${rec.time_end}`;
    }
    // Legacy format
    const patterns = {
      daily: 'Every day',
      weekly: `Every ${DOW_NAMES[rec.day_of_week] || ''}`,
      weekdays: 'Weekdays',
      weekends: 'Weekends',
    };
    return `${patterns[rec.pattern] || rec.pattern} at ${rec.time}`;
  }

  pub.stopRecording = async function(id) {
    try {
      await api('POST', `/api/recordings/${id}/stop`);
      toast('Recording stopped', 'info');
      pub.loadRecordings();
    } catch (e) {
      toast('Error: ' + e.message, 'error');
    }
  };

  pub.deleteRecording = async function(id, name) {
    if (!confirm(`Delete recording "${name}"?`)) return;
    try {
      await api('DELETE', `/api/recordings/${id}`);
      toast('Recording deleted', 'info');
      pub.loadRecordings();
    } catch (e) {
      toast('Error: ' + e.message, 'error');
    }
  };

  // ── Pause / Resume recurring recordings ────────────────────────────────

  let _pausingRecId = null;

  pub.pauseRecording = function(id, name) {
    _pausingRecId = id;
    document.getElementById('pause-modal-info').textContent = `Pausing: ${name}`;
    // Default "pause until" to tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    document.getElementById('pause-until-date').value =
      tomorrow.toISOString().split('T')[0];
    document.getElementById('pause-duration').value = 1;
    document.getElementById('pause-unit').value = 'weeks';
    document.getElementById('pause-modal').classList.add('open');
  };

  pub.closePauseModal = function() {
    document.getElementById('pause-modal').classList.remove('open');
    _pausingRecId = null;
  };

  pub.applyPause = async function() {
    if (!_pausingRecId) return;

    const dateInput = document.getElementById('pause-until-date').value;
    const duration  = parseInt(document.getElementById('pause-duration').value) || 1;
    const unit      = document.getElementById('pause-unit').value;

    let pausedUntil;
    if (dateInput) {
      // Use the specific date (set to end-of-day UTC)
      pausedUntil = new Date(dateInput + 'T23:59:59Z').toISOString();
    } else {
      // Calculate from duration
      const d = new Date();
      if (unit === 'weeks') d.setDate(d.getDate() + duration * 7);
      else d.setDate(d.getDate() + duration);
      pausedUntil = d.toISOString();
    }

    try {
      await api('POST', `/api/recordings/${_pausingRecId}/pause`, { paused_until: pausedUntil });
      toast('Recording paused', 'success');
      pub.closePauseModal();
      pub.loadRecordings();
    } catch (e) {
      toast('Failed: ' + e.message, 'error');
    }
  };

  pub.resumeRecording = async function(id) {
    try {
      await api('POST', `/api/recordings/${id}/resume`);
      toast('Recording resumed', 'success');
      pub.loadRecordings();
    } catch (e) {
      toast('Failed: ' + e.message, 'error');
    }
  };

  // ── CSV Export / Import ───────────────────────────────────────────────────

  const CSV_HEADERS = [
    'show_name','channel_id','channel_name','type',
    'start_time','end_time',
    'season','episode','save_path',
    'quality_codec','quality_resolution','quality_crf','quality_preset',
    'padding_start','padding_end',
    'recurrence_days','recurrence_time_start','recurrence_time_end',
  ];

  function _csvEscape(v) {
    return `"${String(v == null ? '' : v).replace(/"/g, '""')}"`;
  }

  function _recToCsvRow(r) {
    const q = r.quality || {};
    let recDays = '', recStart = '', recEnd = '';
    if (r.recurrence) {
      const rec = r.recurrence;
      if (rec.days) {
        recDays  = rec.days.join(',');
        recStart = rec.time_start || '';
        recEnd   = rec.time_end   || '';
      } else {
        // Legacy format - normalise to days array
        const map = { daily:'0,1,2,3,4,5,6', weekdays:'0,1,2,3,4', weekends:'5,6' };
        recDays = map[rec.pattern] ?? String(rec.day_of_week ?? 0);
        recStart = rec.time || '';
        if (recStart && rec.duration) {
          const [h, m] = recStart.split(':').map(Number);
          const tot = h * 60 + m + (rec.duration || 0);
          recEnd = `${String(Math.floor(tot / 60) % 24).padStart(2,'0')}:${String(tot % 60).padStart(2,'0')}`;
        }
      }
    }
    return [
      r.show_name, r.channel_id, r.channel_name, r.type || 'once',
      r.recurrence ? '' : (r.start_time || ''),
      r.recurrence ? '' : (r.end_time   || ''),
      r.season || '', r.episode || '',
      r.save_path || '',
      q.codec || '', q.resolution || '', q.crf || '', q.preset || '',
      r.padding_start || 0, r.padding_end || 0,
      recDays, recStart, recEnd,
    ].map(_csvEscape).join(',');
  }

  pub.exportRecordingsCSV = function() {
    const exportable = _recs.filter(r =>
      r.status === 'recurring' || r.status === 'scheduled'
    );
    if (!exportable.length) {
      toast('No scheduled or recurring recordings to export', 'info');
      return;
    }
    const lines = [CSV_HEADERS.join(','), ...exportable.map(_recToCsvRow)];
    const blob = new Blob([lines.join('\r\n')], { type: 'text/csv' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url;
    a.download = `iptv-recordings-${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast(`Exported ${exportable.length} recording(s)`, 'success');
  };

  pub.triggerImportCSV = function() {
    document.getElementById('import-csv-input').click();
  };

  pub.importRecordingsCSV = async function(input) {
    const file = input.files[0];
    if (!file) return;
    input.value = '';  // reset so same file can be re-imported

    let text;
    try { text = await file.text(); } catch (e) {
      toast('Could not read file', 'error'); return;
    }

    const lines = text.trim().split(/\r?\n/);
    if (lines.length < 2) { toast('CSV file is empty or has no data rows', 'error'); return; }

    const headers = _parseCSVRow(lines[0]);
    const idx = {};
    headers.forEach((h, i) => { idx[h.trim()] = i; });

    const get = (row, col, def = '') => {
      const i = idx[col];
      return (i !== undefined && row[i] != null) ? row[i] : def;
    };

    let imported = 0, failed = 0, skipped = 0;
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) { skipped++; continue; }
      const row = _parseCSVRow(line);

      const showName = get(row, 'show_name');
      if (!showName) { skipped++; continue; }

      const recDaysStr = get(row, 'recurrence_days');
      const isRecurring = !!recDaysStr;

      const q = {};
      const codec = get(row, 'quality_codec');
      const res   = get(row, 'quality_resolution');
      const crf   = parseInt(get(row, 'quality_crf'));
      const prs   = get(row, 'quality_preset');
      if (codec) q.codec      = codec;
      if (res)   q.resolution = res;
      if (crf)   q.crf        = crf;
      if (prs)   q.preset     = prs;

      const body = {
        channel_id:    get(row, 'channel_id', '0'),
        channel_name:  get(row, 'channel_name'),
        show_name:     showName,
        season:        parseInt(get(row, 'season'))  || 0,
        episode:       parseInt(get(row, 'episode')) || 0,
        save_path:     get(row, 'save_path') || (settings.default_save_path || ''),
        quality:       Object.keys(q).length ? q : null,
        padding_start: parseInt(get(row, 'padding_start')) || 0,
        padding_end:   parseInt(get(row, 'padding_end'))   || 0,
        type:          isRecurring ? 'recurring' : 'once',
      };

      if (isRecurring) {
        const days = recDaysStr.split(',').map(Number)
          .filter(d => !isNaN(d) && d >= 0 && d <= 6);
        if (!days.length) { failed++; continue; }
        const timeStart = get(row, 'recurrence_time_start', '21:00');
        const timeEnd   = get(row, 'recurrence_time_end',   '22:00');
        const today = isoToLocalInput(new Date().toISOString()).split('T')[0];
        body.start_time  = localInputToISO(`${today}T${timeStart}`);
        body.end_time    = localInputToISO(`${today}T${timeEnd}`);
        body.recurrence  = { days, time_start: timeStart, time_end: timeEnd };
      } else {
        body.start_time = get(row, 'start_time');
        body.end_time   = get(row, 'end_time');
        if (!body.start_time || !body.end_time) { failed++; continue; }
      }

      try {
        await api('POST', '/api/recordings', body);
        imported++;
      } catch (e) {
        failed++;
      }
    }

    const msg = `Imported ${imported} recording(s)` +
                (failed  ? `, ${failed} failed`  : '') +
                (skipped ? `, ${skipped} skipped` : '');
    toast(msg, imported ? 'success' : 'error');
    if (imported) pub.loadRecordings();
  };

  function _parseCSVRow(line) {
    const result = [];
    let inQuote = false, val = '';
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"') {
        if (inQuote && line[i + 1] === '"') { val += '"'; i++; }
        else inQuote = !inQuote;
      } else if (c === ',' && !inQuote) {
        result.push(val);
        val = '';
      } else {
        val += c;
      }
    }
    result.push(val);
    return result;
  }

  pub.editRecording = async function(id) {
    let rec;
    try {
      rec = await api('GET', `/api/recordings/${id}`);
    } catch (e) {
      toast('Failed to load recording: ' + e.message, 'error');
      return;
    }

    // Find the channel group so we can pre-select its category
    const matchedGroup = channels.find(g =>
      g.primary_stream_id == rec.channel_id ||
      (g.variants && g.variants.some(v => v.stream_id == rec.channel_id))
    );

    // Populate category dropdown
    const catSel = document.getElementById('rec-category');
    catSel.innerHTML = '<option value="">All categories</option>' +
      _getCategories().map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join('');

    // Reset search, set category to matched group's category
    _recSearchFilter = '';
    document.getElementById('rec-channel-search').value = '';
    _recCategoryFilter = matchedGroup ? (matchedGroup.group_title || '') : '';
    catSel.value = _recCategoryFilter;

    // Populate channel list and pre-select the channel
    _renderRecChannelOptions(rec.channel_id);

    // Try to select the specific variant if different from primary
    const varSel = document.getElementById('rec-variant');
    const varRow = document.getElementById('rec-variant-row');
    if (varRow.style.display !== 'none' && varSel.querySelector(`option[value="${rec.channel_id}"]`)) {
      varSel.value = rec.channel_id;
    }

    // File naming fields
    document.getElementById('rec-show-name').value = rec.show_name || '';
    document.getElementById('rec-season').value    = rec.season  || '';
    document.getElementById('rec-episode').value   = rec.episode || '';
    document.getElementById('rec-save-path').value = rec.save_path || '';

    // Padding
    document.getElementById('rec-pad-start').value = rec.padding_start ?? 0;
    document.getElementById('rec-pad-end').value   = rec.padding_end   ?? 0;

    // Quality overrides - fall back to default_quality values for transcode fields
    const q  = rec.quality || {};
    const dq = settings.default_quality || {};
    document.getElementById('rec-codec').value      = q.codec      || '';
    document.getElementById('rec-resolution').value = q.resolution || '';
    document.getElementById('rec-transcode-after').checked    = q.transcode_after !== undefined ? !!q.transcode_after : !!dq.transcode_after;
    document.getElementById('rec-transcode-codec').value      = q.transcode_codec      || dq.transcode_codec      || 'hevc';
    document.getElementById('rec-transcode-resolution').value = q.transcode_resolution || dq.transcode_resolution || '1920x1080';
    document.getElementById('rec-transcode-crf').value        = q.transcode_crf        ?? dq.transcode_crf        ?? 18;
    document.getElementById('rec-transcode-preset').value     = q.transcode_preset     || dq.transcode_preset     || 'medium';
    pub.onRecCodecChange();

    // Recurrence
    const isRecEl = document.getElementById('rec-is-recurring');
    if (rec.recurrence) {
      isRecEl.checked = true;
      pub.onRecurrenceChange();

      const r = rec.recurrence;
      // New format: {days, time_start, time_end}
      if (r.days) {
        document.querySelectorAll('input[name="rec-dow"]').forEach(cb => {
          cb.checked = r.days.includes(parseInt(cb.value));
        });
        document.getElementById('rec-rec-start').value = r.time_start || '21:00';
        document.getElementById('rec-rec-end').value   = r.time_end   || '22:00';
      } else {
        // Legacy format: convert to new UI
        const time = r.time || '21:00';
        document.getElementById('rec-rec-start').value = time;
        document.getElementById('rec-rec-end').value   = '22:00';
        // Map legacy pattern to day checkboxes
        document.querySelectorAll('input[name="rec-dow"]').forEach(cb => {
          const v = parseInt(cb.value);
          if (r.pattern === 'daily') cb.checked = true;
          else if (r.pattern === 'weekdays') cb.checked = v <= 4;
          else if (r.pattern === 'weekends') cb.checked = v >= 5;
          else if (r.pattern === 'weekly') cb.checked = v === (r.day_of_week ?? 0);
          else cb.checked = false;
        });
      }
    } else {
      isRecEl.checked = false;
      pub.onRecurrenceChange();
      document.querySelectorAll('input[name="rec-dow"]').forEach(cb => cb.checked = false);
      document.getElementById('rec-start').value = isoToLocalInput(rec.start_time);
      document.getElementById('rec-end').value   = isoToLocalInput(rec.end_time);
    }

    // Switch modal to edit mode
    _editingRecId = id;
    document.getElementById('schedule-modal-title').textContent = 'Edit Recording';
    document.getElementById('schedule-modal').classList.add('open');
  };

  // ── Settings ───────────────────────────────────────────────────────────

  pub.loadSettings = async function() {
    try {
      settings = await api('GET', '/api/settings');
      document.getElementById('s-host').value      = settings.xtream_host || '';
      document.getElementById('s-username').value  = settings.xtream_username || '';
      document.getElementById('s-save-path').value = settings.default_save_path || '';
      const q = settings.default_quality || {};
      document.getElementById('s-codec').value      = q.codec || 'copy';
      document.getElementById('s-resolution').value = q.resolution || '1920x1080';
      document.getElementById('s-crf').value        = q.crf ?? 18;
      document.getElementById('s-preset').value     = q.preset || 'medium';
      document.getElementById('s-transcode-after').checked           = !!q.transcode_after;
      document.getElementById('s-transcode-codec').value             = q.transcode_codec || 'hevc';
      document.getElementById('s-transcode-resolution').value        = q.transcode_resolution || '1920x1080';
      document.getElementById('s-transcode-crf').value               = q.transcode_crf ?? 18;
      document.getElementById('s-transcode-preset').value            = q.transcode_preset || 'medium';
      app.onSettingsCodecChange();
      app.onSettingsTranscodeChange();

      const tz = settings.timezone || 'Europe/London';
      document.getElementById('s-timezone').value = tz;
      applyActiveTZ(tz);

      // Sync EPG filter toggle
      const epgFilter = settings.epg_filter_channels;
      _epgFilterEnabled = (epgFilter !== '0' && epgFilter !== false && epgFilter !== 0);
      const toggle = document.getElementById('epg-only-toggle');
      if (toggle) toggle.checked = _epgFilterEnabled;
    } catch (e) {
      toast('Failed to load settings', 'error');
    }
  };

  pub.saveSettings = async function() {
    const tz = document.getElementById('s-timezone').value;
    const body = {
      xtream_host:     document.getElementById('s-host').value.trim(),
      xtream_username: document.getElementById('s-username').value.trim(),
      default_save_path: document.getElementById('s-save-path').value.trim(),
      default_quality: {
        codec:               document.getElementById('s-codec').value,
        resolution:          document.getElementById('s-resolution').value,
        crf:                 parseInt(document.getElementById('s-crf').value) || 18,
        preset:              document.getElementById('s-preset').value,
        audio_codec:         'aac',
        transcode_after:     document.getElementById('s-transcode-after').checked,
        transcode_codec:     document.getElementById('s-transcode-codec').value,
        transcode_resolution:document.getElementById('s-transcode-resolution').value,
        transcode_crf:       parseInt(document.getElementById('s-transcode-crf').value) || 18,
        transcode_preset:    document.getElementById('s-transcode-preset').value,
      },
      timezone: tz,
    };
    applyActiveTZ(tz);
    const pwd = document.getElementById('s-password').value;
    if (pwd) body.xtream_password = pwd;

    try {
      await api('POST', '/api/settings', body);
      settings = { ...settings, ...body };
      toast('Settings saved', 'success');
      // Refresh channels with new credentials
      if (body.xtream_host) loadChannels();
    } catch (e) {
      toast('Failed to save: ' + e.message, 'error');
    }
  };

  async function _loadNetworkInfo() {
    try {
      const info = await api('GET', '/api/network/info');
      const url = `http://${info.local_ip}:${info.port}`;
      const urlEl = document.getElementById('network-local-url');
      const ipEl  = document.getElementById('network-local-ip');
      if (urlEl) urlEl.innerHTML =
        `<a href="${url}" target="_blank" style="color:var(--accent)">${url}</a>`;
      if (ipEl) ipEl.textContent = info.local_ip;
    } catch (e) {
      // Non-critical
    }
  }

  pub.factoryReset = async function() {
    if (!confirm(
      'Factory Reset will delete ALL settings, credentials, and scheduled recordings.\n\n' +
      'The installer will then re-open to set everything up from scratch.\n\n' +
      'This cannot be undone. Continue?'
    )) return;

    try {
      await api('POST', '/api/factory-reset');
      toast('Reset complete - launching installer…', 'info', 5000);

      // Clear all local state
      channels = []; filteredChs = []; settings = {};
      epg.epgData = {};

      // Brief pause, then open the installer via the backend
      setTimeout(() => {
        window.location.href = '/api/launch-installer';
      }, 1500);
    } catch (e) {
      toast('Reset failed: ' + e.message, 'error');
    }
  };

  pub.testConnection = async function() {
    const result = document.getElementById('connection-result');
    result.textContent = 'Testing…';
    result.style.color = 'var(--text-dim)';

    const body = {
      host:     document.getElementById('s-host').value.trim(),
      username: document.getElementById('s-username').value.trim(),
      password: document.getElementById('s-password').value,
    };

    try {
      const r = await api('POST', '/api/settings/test', body);
      if (r.ok) {
        result.style.color = 'var(--success)';
        const d = r.detail || {};
        result.textContent =
          `Connected! Status: ${d.status}, Expires: ${d.expiry || 'N/A'}, ` +
          `Connections: ${d.active_connections}/${d.max_connections}`;
      } else {
        result.style.color = 'var(--rec)';
        result.textContent = 'Failed: ' + (r.detail || 'Unknown error');
      }
    } catch (e) {
      result.style.color = 'var(--rec)';
      result.textContent = 'Error: ' + e.message;
    }
  };

  // ── Setup Wizard ─────────────────────────────────────────────────────────

  pub.wizard = {
    show() {
      document.getElementById('wizard-overlay').classList.remove('hidden');
      this.go(0);
    },

    hide() {
      document.getElementById('wizard-overlay').classList.add('hidden');
    },

    go(step) {
      document.querySelectorAll('.wz-dot').forEach((d, i) => {
        d.classList.toggle('active', i <= step);
      });
      document.querySelectorAll('.wz-panel').forEach((p, i) => {
        p.classList.toggle('active', parseInt(p.dataset.panel) === step);
      });
    },

    async testConnection() {
      const host = document.getElementById('wz-host').value.trim();
      const user = document.getElementById('wz-username').value.trim();
      const pass = document.getElementById('wz-password').value.trim();
      const el   = document.getElementById('wz-test-result');
      el.textContent = 'Testing…';
      el.style.color = 'var(--text-dim)';
      try {
        const res  = await fetch('/api/settings/test', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ host, username: user, password: pass }),
        });
        const data = await res.json();
        if (data.ok) {
          el.textContent = '✓ Connected - ' + (data.detail?.status || 'active');
          el.style.color = 'var(--success)';
        } else {
          el.textContent = '✗ ' + (data.detail || 'Connection failed');
          el.style.color = 'var(--accent2)';
        }
      } catch (e) {
        el.textContent = '✗ ' + e.message;
        el.style.color = 'var(--accent2)';
      }
    },

    async finish() {
      const host     = document.getElementById('wz-host').value.trim();
      const user     = document.getElementById('wz-username').value.trim();
      const pass     = document.getElementById('wz-password').value.trim();
      const savePath = document.getElementById('wz-save-path').value.trim();
      const codec    = document.getElementById('wz-codec').value;
      const res      = document.getElementById('wz-resolution').value;

      if (!host || !user || !pass) {
        toast('Please fill in your IPTV server details first.', 'error');
        this.go(1);
        return;
      }

      try {
        await api('POST', '/api/settings', {
          xtream_host:      host,
          xtream_username:  user,
          xtream_password:  pass,
          default_save_path: savePath,
          default_quality:  { codec, resolution: res, crf: 18, preset: 'medium', audio_codec: 'aac' },
          setup_complete:   '1',
        });
        settings.setup_complete = '1';
        this.go(3);
        loadChannels();
      } catch (e) {
        toast('Failed to save settings: ' + e.message, 'error');
      }
    },

    done() {
      this.hide();
      pub.loadSettings();
      const _initView = new URLSearchParams(window.location.search).get('view');
      if (_initView) pub.navigateTo(_initView);
    },

    triggerRestore() {
      document.getElementById('wz-restore-input').click();
    },

    async restoreFromFile(input) {
      const file = input.files[0];
      if (!file) return;
      input.value = '';
      await _doRestore(file, { fromWizard: true });
    },
  };

  // ── Backup & Restore ─────────────────────────────────────────────────────

  pub.exportBackup = function() {
    const a = document.createElement('a');
    a.href = '/api/backup';
    a.download = `iptv-manager-backup-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
  };

  pub.triggerRestoreBackup = function() {
    document.getElementById('restore-backup-input').click();
  };

  pub.restoreBackup = async function(input) {
    const file = input.files[0];
    if (!file) return;
    input.value = '';
    await _doRestore(file, { fromWizard: false });
  };

  async function _doRestore(file, { fromWizard }) {
    let data;
    try {
      data = JSON.parse(await file.text());
    } catch (e) {
      toast('Could not read backup file', 'error'); return;
    }
    if (!data.iptv_manager_backup) {
      toast('Not a valid IPTV Manager backup file', 'error'); return;
    }

    try {
      const result = await api('POST', '/api/restore', data);
      const recMsg = result.imported
        ? `${result.imported} recording${result.imported !== 1 ? 's' : ''} restored`
        : 'no recordings to restore';

      if (fromWizard) {
        document.getElementById('wz-done-title').textContent = 'Backup Restored!';
        document.getElementById('wz-done-desc').textContent =
          `Settings and ${recMsg}. Your channels are loading now.`;
        pub.wizard.go(3);
        loadChannels();
        pub.loadRecordings();
      } else {
        toast(`Backup restored - ${recMsg}`, 'success');
        pub.loadSettings();
        pub.loadRecordings();
      }
    } catch (e) {
      toast('Restore failed: ' + e.message, 'error');
    }
  }

  pub.loadChannels = loadChannels;

  // ── Sports ─────────────────────────────────────────────────────────────

  let _sportsFavourites = [];
  let _sportsResults    = {};   // keyword → [EPG result]
  let _activeSportsTab  = -1;   // -1 = manage/add panel; 0+ = favourite index

  pub.loadSports = async function() {
    try {
      // Ensure EPG channel map is ready (waits for XMLTV if needed)
      await _ensureXmltvLoaded();
      const data = await api('GET', '/api/sports/favourites');
      _sportsFavourites = data.favourites || [];
      _renderSportsTabs();
      if (_sportsFavourites.length === 0) {
        _showSportsManagePanel();
      } else {
        if (_activeSportsTab < 0 || _activeSportsTab >= _sportsFavourites.length) {
          _activeSportsTab = 0;
        }
        _showSportsTab(_activeSportsTab);
      }
    } catch (e) {
      toast('Failed to load sports: ' + e.message, 'error');
    }
  };

  function _renderSportsTabs() {
    const bar = document.getElementById('sports-tab-bar');
    if (!bar) return;
    const tabs = _sportsFavourites.map((fav, i) => `
      <button class="sports-tab${i === _activeSportsTab ? ' active' : ''}"
              onclick="app.selectSportsTab(${i})">
        ${esc(fav)}
        <span class="sports-tab-remove" onclick="event.stopPropagation();app.removeSportFavourite(${i})" title="Remove">×</span>
      </button>
    `).join('');
    const addActive = _activeSportsTab === -1 ? ' active' : '';
    const addLabel  = _sportsFavourites.length === 0 ? ' Add Sports' : '';
    bar.innerHTML = tabs + `
      <button class="sports-tab sports-tab-add${addActive}" onclick="app.selectSportsTab(-1)" title="Add sport or team">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="flex-shrink:0">
          <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
        </svg>${addLabel}
      </button>`;
  }

  pub.selectSportsTab = function(idx) {
    _activeSportsTab = idx;
    _renderSportsTabs();
    if (idx === -1) {
      _showSportsManagePanel();
    } else {
      _showSportsTab(idx);
    }
  };

  function _showSportsManagePanel() {
    const panel   = document.getElementById('sports-add-panel');
    const content = document.getElementById('sports-tab-content');
    if (panel)   panel.style.display   = '';
    if (content) content.style.display = 'none';
    _renderSportsFavourites();
  }

  function _showSportsTab(idx) {
    const panel   = document.getElementById('sports-add-panel');
    const content = document.getElementById('sports-tab-content');
    if (panel)   panel.style.display   = 'none';
    if (content) content.style.display = '';
    _renderActiveTab(idx);
  }

  function _renderActiveTab(idx) {
    const fav       = _sportsFavourites[idx];
    if (!fav) return;
    const container = document.getElementById('sports-matches');
    const empty     = document.getElementById('sports-empty');

    // Already cached - render immediately
    if (_sportsResults[fav] !== undefined) {
      _renderTabResults(fav, idx);
      return;
    }

    if (container) container.innerHTML = '<p class="sports-no-matches" style="padding:20px">Loading…</p>';
    if (empty)     empty.style.display = 'none';
    _loadSportSection(fav, idx);
  }

  function _renderTabResults(keyword, idx) {
    const container = document.getElementById('sports-matches');
    const empty     = document.getElementById('sports-empty');
    const results   = _sportsResults[keyword] || [];

    if (results.length === 0) {
      if (container) container.innerHTML = '';
      if (empty)     empty.style.display = 'flex';
      return;
    }
    if (empty) empty.style.display = 'none';

    const now = new Date();
    container.innerHTML = `<div class="sports-section-matches">${
      results.map((r, matchIdx) => _buildSportCard(r, idx, matchIdx, now)).join('')
    }</div>`;
  }

  function _buildSportCard(r, sectionIdx, matchIdx, now) {
    const group   = _epgChannelMap[r.epg_channel_id];
    const isLive  = r.start && r.end && new Date(r.start) <= now && new Date(r.end) > now;
    const chName  = group ? group.display_name : (r.epg_channel_id || 'Unknown channel');
    const startDate = r.start ? new Date(r.start) : null;
    const todayStr  = new Date().toDateString();
    const timeLabel = startDate
      ? (startDate.toDateString() === todayStr
          ? `Today · ${fmtTimeUK(r.start)}${r.end ? ' – ' + fmtTimeUK(r.end) : ''}`
          : `${fmtDateTimeUK(r.start)}${r.end ? ' – ' + fmtTimeUK(r.end) : ''}`)
      : '';
    return `
      <div class="sport-match-card${isLive ? ' is-live' : ''}">
        <div class="sport-card-top">
          <div class="sport-card-channel">
            ${group && group.stream_icon
              ? `<img src="${esc(group.stream_icon)}" alt="" onerror="this.style.display='none'">`
              : '<div class="sport-card-ch-icon">📺</div>'}
            <span class="sport-card-ch-name" title="${esc(chName)}">${esc(chName)}</span>
          </div>
          ${isLive ? '<span class="sport-live-badge">LIVE NOW</span>' : ''}
        </div>
        <div class="sport-card-matchup">${esc(r.title)}</div>
        <div class="sport-card-footer">
          <div class="sport-card-time">${esc(timeLabel)}</div>
          <div class="sport-card-actions">
            ${group
              ? `<button class="btn-sport-watch" onclick="app.watchSportMatch(${sectionIdx},${matchIdx})">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                  Watch Live
                </button>`
              : ''}
            <button class="btn-sport-record" onclick="app.recordSportMatch(${sectionIdx},${matchIdx})">
              <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/></svg>
              Record
            </button>
          </div>
        </div>
      </div>`;
  }

  async function _loadSportSection(keyword, sectionIdx) {
    try {
      const results = await api('GET', `/api/epg/search?q=${encodeURIComponent(keyword)}&limit=20`);
      const now     = new Date();
      const upcoming = (results || []).filter(r => !r.end || new Date(r.end) > now);
      _sportsResults[keyword] = upcoming;
      // Only render if this tab is still active
      if (_activeSportsTab === sectionIdx) {
        _renderTabResults(keyword, sectionIdx);
      }
    } catch (e) {
      if (_activeSportsTab === sectionIdx) {
        const el = document.getElementById('sports-matches');
        if (el) el.innerHTML = '<p class="sports-no-matches" style="padding:20px">Could not load EPG data.</p>';
      }
    }
  }

  function _renderSportsFavourites() {
    const row = document.getElementById('sports-favourites-row');
    if (!row) return;
    if (_sportsFavourites.length === 0) {
      row.innerHTML = '<span style="color:var(--text-dim);font-size:12px;">No favourites yet - type a sport or team above and click Add.</span>';
      return;
    }
    row.innerHTML = _sportsFavourites.map((fav, i) => `
      <span class="sport-chip">
        ${esc(fav)}
        <button class="sport-chip-remove" onclick="app.removeSportFavourite(${i})" title="Remove">×</button>
      </span>
    `).join('');
  }

  pub.addSportFavourite = async function() {
    const input   = document.getElementById('sports-search-input');
    const keyword = (input.value || '').trim();
    if (!keyword) { input.focus(); return; }
    if (_sportsFavourites.map(f => f.toLowerCase()).includes(keyword.toLowerCase())) {
      toast(`"${keyword}" is already in your favourites`, 'info');
      input.value = '';
      return;
    }
    _sportsFavourites.push(keyword);
    input.value = '';
    try {
      await api('POST', '/api/sports/favourites', { favourites: _sportsFavourites });
      // Switch to the newly added tab
      _activeSportsTab = _sportsFavourites.length - 1;
      _renderSportsTabs();
      _showSportsTab(_activeSportsTab);
    } catch (e) {
      toast('Failed to save: ' + e.message, 'error');
    }
  };

  pub.removeSportFavourite = async function(idx) {
    const removed = _sportsFavourites.splice(idx, 1)[0];
    delete _sportsResults[removed];
    try {
      await api('POST', '/api/sports/favourites', { favourites: _sportsFavourites });
      if (_sportsFavourites.length === 0) {
        _activeSportsTab = -1;
        _renderSportsTabs();
        _showSportsManagePanel();
      } else {
        _activeSportsTab = Math.min(idx, _sportsFavourites.length - 1);
        _renderSportsTabs();
        _showSportsTab(_activeSportsTab);
      }
    } catch (e) {
      toast('Failed to save: ' + e.message, 'error');
    }
  };

  pub.watchSportMatch = function(sectionIdx, matchIdx) {
    const fav   = _sportsFavourites[sectionIdx];
    const r     = (_sportsResults[fav] || [])[matchIdx];
    const group = r && _epgChannelMap[r.epg_channel_id];
    if (group) pub.watchChannel(group);
    else toast('Channel not available for live playback', 'info');
  };

  pub.recordSportMatch = function(sectionIdx, matchIdx) {
    const fav   = _sportsFavourites[sectionIdx];
    const r     = (_sportsResults[fav] || [])[matchIdx];
    if (!r) return;
    pub.openScheduleModal(_epgChannelMap[r.epg_channel_id] || null, r);
  };

  // ── Movies (VOD) ────────────────────────────────────────────────────────

  let _moviesCats        = [];
  let _moviesActiveCat   = '';
  let _moviesPage        = 1;
  let _moviesTotalPages  = 1;
  let _moviesSearch      = '';
  let _moviesLoaded      = false;   // categories loaded at least once

  pub.loadMovies = async function() {
    if (!_moviesLoaded) {
      _moviesLoaded = true;
      await _loadMovieCategories();
    }
    await _fetchMovies();
  };

  async function _loadMovieCategories() {
    try {
      const cats = await api('GET', '/api/vod/categories');
      _moviesCats = Array.isArray(cats) ? cats : [];
      _renderMovieCategoryBar();
    } catch (e) {
      // Non-critical
    }
  }

  function _renderMovieCategoryBar() {
    const bar = document.getElementById('movies-cat-bar');
    if (!bar) return;
    const allBtn = `<button class="vod-cat-btn${_moviesActiveCat === '' ? ' active' : ''}" onclick="app.selectMovieCategory('')">All</button>`;
    const catBtns = _moviesCats.map(c => `
      <button class="vod-cat-btn${_moviesActiveCat === String(c.category_id) ? ' active' : ''}"
              onclick="app.selectMovieCategory('${esc(String(c.category_id))}')">
        ${esc(c.category_name)}
      </button>`).join('');
    bar.innerHTML = allBtn + catBtns;
  }

  pub.selectMovieCategory = function(catId) {
    _moviesActiveCat = catId;
    _moviesPage = 1;
    _moviesSearch = '';
    const inp = document.getElementById('movies-search');
    if (inp) inp.value = '';
    _renderMovieCategoryBar();
    _fetchMovies();
  };

  let _moviesSearchTimer = null;
  pub.onMoviesSearch = function(val) {
    _moviesSearch = (val || '').trim();
    _moviesPage   = 1;
    clearTimeout(_moviesSearchTimer);
    _moviesSearchTimer = setTimeout(() => _fetchMovies(), 350);
  };

  pub.moviesChangePage = function(delta) {
    const next = _moviesPage + delta;
    if (next < 1 || next > _moviesTotalPages) return;
    _moviesPage = next;
    _fetchMovies();
  };

  async function _fetchMovies() {
    const grid  = document.getElementById('movies-grid');
    const empty = document.getElementById('movies-empty');
    const pgn   = document.getElementById('movies-pagination');
    if (!grid) return;
    grid.innerHTML = '<p class="vod-loading">Loading…</p>';
    if (empty) empty.style.display = 'none';
    if (pgn)   pgn.style.display   = 'none';

    let url = `/api/vod/streams?page=${_moviesPage}`;
    if (_moviesActiveCat) url += `&category_id=${encodeURIComponent(_moviesActiveCat)}`;
    if (_moviesSearch)    url += `&search=${encodeURIComponent(_moviesSearch)}`;

    try {
      const data = await api('GET', url);
      const streams = data.streams || [];
      _moviesTotalPages = data.pages || 1;

      if (streams.length === 0) {
        grid.innerHTML = '';
        if (empty) empty.style.display = 'flex';
        return;
      }

      grid.innerHTML = streams.map(s => _buildVodCard(s, 'movie')).join('');
      _updateMoviesPagination(data.page, data.pages, data.total);
    } catch (e) {
      grid.innerHTML = `<p class="vod-loading" style="color:var(--rec)">Error: ${esc(e.message)}</p>`;
    }
  }

  function _updateMoviesPagination(page, pages, total) {
    const pgn   = document.getElementById('movies-pagination');
    const label = document.getElementById('movies-page-label');
    const prev  = document.getElementById('movies-prev-btn');
    const next  = document.getElementById('movies-next-btn');
    if (!pgn) return;
    if (pages <= 1) { pgn.style.display = 'none'; return; }
    pgn.style.display = '';
    if (label) label.textContent = `Page ${page} of ${pages} (${total} total)`;
    if (prev)  prev.disabled  = (page <= 1);
    if (next)  next.disabled  = (page >= pages);
  }

  function _buildVodCard(s, type) {
    const id      = type === 'movie' ? s.stream_id : s.series_id;
    const cover   = s.stream_icon || s.cover || '';
    const name    = s.name || 'Unknown';
    const rating  = s.rating ? `★ ${parseFloat(s.rating).toFixed(1)}` : '';
    const onclick = type === 'movie'
      ? `app.openMovieDetail(${id})`
      : `app.openSeriesDetail(${id})`;
    return `
      <div class="vod-card" onclick="${onclick}" title="${esc(name)}">
        ${cover
          ? `<img class="vod-card-poster" src="${esc(cover)}" alt="" loading="lazy" onerror="this.parentElement.classList.add('vod-card-no-poster')">`
          : '<div class="vod-card-poster vod-card-poster-placeholder"></div>'}
        <div class="vod-card-info">
          <div class="vod-card-title">${esc(name)}</div>
          ${rating ? `<div class="vod-card-rating">${esc(rating)}</div>` : ''}
        </div>
      </div>`;
  }

  pub.openMovieDetail = async function(vodId) {
    const overlay = document.getElementById('vod-detail-overlay');
    const content = document.getElementById('vod-detail-content');
    if (!overlay || !content) return;
    overlay.classList.add('open');
    content.innerHTML = '<p class="vod-detail-loading">Loading…</p>';

    try {
      const data   = await api('GET', `/api/vod/info/${vodId}`);
      const info   = data.info || {};
      const stream = (data.movie_data || data) || {};
      const name   = info.name || stream.name || 'Unknown';
      const plot   = info.plot || info.description || '';
      const genre  = info.genre || '';
      const cast   = info.cast || '';
      const rating = info.rating || stream.rating || '';
      const year   = info.releasedate || info.year || '';
      const cover  = info.movie_image || info.cover_big || stream.stream_icon || '';
      const ext    = stream.container_extension || 'mp4';
      const sid    = stream.stream_id || vodId;

      const inWatchlist = _watchlist.some(w => w.id === `movie_${sid}`);
      content.innerHTML = `
        <div class="vod-detail-layout">
          ${cover ? `<img class="vod-detail-poster" src="${esc(cover)}" alt="">` : '<div class="vod-detail-poster vod-card-poster-placeholder"></div>'}
          <div class="vod-detail-info">
            <div class="vod-detail-title-row">
              <h2 class="vod-detail-title">${esc(name)}</h2>
              <button class="btn-watchlist${inWatchlist ? ' in-list' : ''}" id="wl-btn-movie-${sid}"
                      onclick="app.toggleWatchlist('movie',${sid},'${esc(ext)}','${esc(name)}','${esc(cover)}')"
                      title="${inWatchlist ? 'Remove from watchlist' : 'Add to watchlist'}">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="${inWatchlist ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
              </button>
            </div>
            <div class="vod-detail-meta">
              ${year   ? `<span>${esc(String(year))}</span>` : ''}
              ${genre  ? `<span>${esc(genre)}</span>` : ''}
              ${rating ? `<span>★ ${esc(String(rating))}</span>` : ''}
            </div>
            ${cast  ? `<p class="vod-detail-cast"><strong>Cast:</strong> ${esc(cast)}</p>` : ''}
            ${plot  ? `<p class="vod-detail-plot">${esc(plot)}</p>` : ''}
            <div class="vod-detail-actions">
              <button class="btn btn-primary" onclick="app.playVod(${sid},'${esc(ext)}','${esc(name)}','${esc(cover)}')">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" style="vertical-align:-2px;margin-right:5px"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                Watch
              </button>
              <button class="btn btn-ghost" onclick="app.downloadVod(${sid},'${esc(ext)}','${esc(name)}')">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align:-2px;margin-right:5px"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                Download
              </button>
            </div>
            <p class="vod-ffplay-hint">mpv controls: Space = pause · ← / → = ±5s · ↑ / ↓ = ±1min · f = fullscreen · q = quit · move mouse to show progress bar</p>
          </div>
        </div>`;
    } catch (e) {
      content.innerHTML = `<p class="vod-detail-loading" style="color:var(--rec)">Failed to load info: ${esc(e.message)}</p>`;
    }
  };

  pub.closeVodDetail = function() {
    const overlay = document.getElementById('vod-detail-overlay');
    if (overlay) overlay.classList.remove('open');
  };

  pub.playVod = async function(streamId, ext, title, cover) {
    if (!IS_LOCAL) { toast('Playback is only available on the host device.', 'info', 4000); return; }
    try {
      toast(`Opening ${title}…`, 'info', 2000);
      await api('POST', `/api/vod/play/${streamId}`, { ext, title });
      await _addToCurrentlyWatching('movie', streamId, ext, title, cover || '');
    } catch (e) {
      toast('Could not open player: ' + e.message, 'error');
    }
  };

  pub.downloadVod = async function(streamId, ext, title) {
    try {
      const result = await api('POST', '/api/vod/download', { stream_id: streamId, ext, title });
      _onDownloadStarted(result);
    } catch (e) {
      toast('Download failed: ' + e.message, 'error');
    }
  };

  // ── TV Shows (Series) ───────────────────────────────────────────────────

  let _tvshowsCats        = [];
  let _tvshowsActiveCat   = '';
  let _tvshowsPage        = 1;
  let _tvshowsTotalPages  = 1;
  let _tvshowsSearch      = '';
  let _tvshowsLoaded      = false;

  pub.loadTVShows = async function() {
    if (!_tvshowsLoaded) {
      _tvshowsLoaded = true;
      await _loadTVShowCategories();
    }
    await _fetchTVShows();
  };

  async function _loadTVShowCategories() {
    try {
      const cats = await api('GET', '/api/series/categories');
      _tvshowsCats = Array.isArray(cats) ? cats : [];
      _renderTVShowCategoryBar();
    } catch (e) {
      // Non-critical
    }
  }

  function _renderTVShowCategoryBar() {
    const bar = document.getElementById('tvshows-cat-bar');
    if (!bar) return;
    const allBtn = `<button class="vod-cat-btn${_tvshowsActiveCat === '' ? ' active' : ''}" onclick="app.selectTVShowCategory('')">All</button>`;
    const catBtns = _tvshowsCats.map(c => `
      <button class="vod-cat-btn${_tvshowsActiveCat === String(c.category_id) ? ' active' : ''}"
              onclick="app.selectTVShowCategory('${esc(String(c.category_id))}')">
        ${esc(c.category_name)}
      </button>`).join('');
    bar.innerHTML = allBtn + catBtns;
  }

  pub.selectTVShowCategory = function(catId) {
    _tvshowsActiveCat = catId;
    _tvshowsPage = 1;
    _tvshowsSearch = '';
    const inp = document.getElementById('tvshows-search');
    if (inp) inp.value = '';
    _renderTVShowCategoryBar();
    _fetchTVShows();
  };

  let _tvshowsSearchTimer = null;
  pub.onTVShowsSearch = function(val) {
    _tvshowsSearch = (val || '').trim();
    _tvshowsPage   = 1;
    clearTimeout(_tvshowsSearchTimer);
    _tvshowsSearchTimer = setTimeout(() => _fetchTVShows(), 350);
  };

  pub.tvshowsChangePage = function(delta) {
    const next = _tvshowsPage + delta;
    if (next < 1 || next > _tvshowsTotalPages) return;
    _tvshowsPage = next;
    _fetchTVShows();
  };

  async function _fetchTVShows() {
    const grid  = document.getElementById('tvshows-grid');
    const empty = document.getElementById('tvshows-empty');
    const pgn   = document.getElementById('tvshows-pagination');
    if (!grid) return;
    grid.innerHTML = '<p class="vod-loading">Loading…</p>';
    if (empty) empty.style.display = 'none';
    if (pgn)   pgn.style.display   = 'none';

    let url = `/api/series/streams?page=${_tvshowsPage}`;
    if (_tvshowsActiveCat) url += `&category_id=${encodeURIComponent(_tvshowsActiveCat)}`;
    if (_tvshowsSearch)    url += `&search=${encodeURIComponent(_tvshowsSearch)}`;

    try {
      const data   = await api('GET', url);
      const series = data.series || [];
      _tvshowsTotalPages = data.pages || 1;

      if (series.length === 0) {
        grid.innerHTML = '';
        if (empty) empty.style.display = 'flex';
        return;
      }

      grid.innerHTML = series.map(s => _buildVodCard(s, 'series')).join('');
      _updateTVShowsPagination(data.page, data.pages, data.total);
    } catch (e) {
      grid.innerHTML = `<p class="vod-loading" style="color:var(--rec)">Error: ${esc(e.message)}</p>`;
    }
  }

  function _updateTVShowsPagination(page, pages, total) {
    const pgn   = document.getElementById('tvshows-pagination');
    const label = document.getElementById('tvshows-page-label');
    const prev  = document.getElementById('tvshows-prev-btn');
    const next  = document.getElementById('tvshows-next-btn');
    if (!pgn) return;
    if (pages <= 1) { pgn.style.display = 'none'; return; }
    pgn.style.display = '';
    if (label) label.textContent = `Page ${page} of ${pages} (${total} total)`;
    if (prev)  prev.disabled  = (page <= 1);
    if (next)  next.disabled  = (page >= pages);
  }

  pub.openSeriesDetail = async function(seriesId) {
    const overlay = document.getElementById('vod-detail-overlay');
    const content = document.getElementById('vod-detail-content');
    if (!overlay || !content) return;
    overlay.classList.add('open');
    content.innerHTML = '<p class="vod-detail-loading">Loading…</p>';

    try {
      const data   = await api('GET', `/api/series/info/${seriesId}`);
      const info   = data.info || {};
      const name   = info.name || 'Unknown';
      const plot   = info.plot || info.description || '';
      const genre  = info.genre || '';
      const cast   = info.cast || '';
      const rating = info.rating || '';
      const year   = info.releaseDate || '';
      const cover  = info.cover || info.cover_big || '';
      const seasons = data.seasons || {};
      const episodes = data.episodes || {};

      const seasonNums = Object.keys(episodes).sort((a, b) => Number(a) - Number(b));
      // Store episodes for tab-switching
      _currentSeriesEpisodes = episodes;
      _currentSeriesName     = name;
      _currentSeriesSeason   = seasonNums[0] || null;
      _currentSeriesCover    = cover;

      const inWatchlist = _watchlist.some(w => w.id === `series_${seriesId}`);
      const seasonTabsHtml = seasonNums.length === 0
        ? ''
        : `<div class="vod-season-tabs" id="vod-season-tabs">
            ${seasonNums.map(sNum => `
              <button class="vod-season-tab${sNum === _currentSeriesSeason ? ' active' : ''}"
                      onclick="app.selectSeason('${esc(sNum)}')"
                      data-season="${esc(sNum)}">Season ${esc(sNum)}</button>
            `).join('')}
          </div>
          <div id="vod-episodes-container"></div>`;

      content.innerHTML = `
        <div class="vod-detail-layout">
          ${cover ? `<img class="vod-detail-poster" src="${esc(cover)}" alt="">` : '<div class="vod-detail-poster vod-card-poster-placeholder"></div>'}
          <div class="vod-detail-info">
            <div class="vod-detail-title-row">
              <h2 class="vod-detail-title">${esc(name)}</h2>
              <button class="btn-watchlist${inWatchlist ? ' in-list' : ''}" id="wl-btn-series-${seriesId}"
                      onclick="app.toggleWatchlist('series',${seriesId},'','${esc(name)}','${esc(cover)}')"
                      title="${inWatchlist ? 'Remove from watchlist' : 'Add to watchlist'}">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="${inWatchlist ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
              </button>
            </div>
            <div class="vod-detail-meta">
              ${year   ? `<span>${esc(String(year))}</span>` : ''}
              ${genre  ? `<span>${esc(genre)}</span>` : ''}
              ${rating ? `<span>★ ${esc(String(rating))}</span>` : ''}
            </div>
            ${cast ? `<p class="vod-detail-cast"><strong>Cast:</strong> ${esc(cast)}</p>` : ''}
            ${plot ? `<p class="vod-detail-plot">${esc(plot)}</p>` : ''}
            ${seasonNums.length === 0
              ? '<p style="color:var(--text-dim);font-size:13px;">No episodes available.</p>'
              : seasonTabsHtml}
          </div>
        </div>`;

      // Render first season's episodes
      if (_currentSeriesSeason) _renderSeasonEpisodes(_currentSeriesSeason);
    } catch (e) {
      content.innerHTML = `<p class="vod-detail-loading" style="color:var(--rec)">Failed to load: ${esc(e.message)}</p>`;
    }
  };

  pub.playEpisode = async function(streamId, ext, title) {
    if (!IS_LOCAL) { toast('Playback is only available on the host device.', 'info', 4000); return; }
    try {
      toast(`Opening ${title}…`, 'info', 2000);
      await api('POST', '/api/series/play', { stream_id: streamId, ext, title });
      await _addToCurrentlyWatching('series', streamId, ext, _currentSeriesName, _currentSeriesCover);
    } catch (e) {
      toast('Could not open player: ' + e.message, 'error');
    }
  };

  pub.downloadEpisode = async function(streamId, ext, title) {
    try {
      toast(`Starting download…`, 'info', 2000);
      const result = await api('POST', '/api/series/download', { stream_id: streamId, ext, title });
      _onDownloadStarted(result);
    } catch (e) {
      toast('Download failed: ' + e.message, 'error');
    }
  };

  // ── Season tabs ─────────────────────────────────────────────────────────

  let _currentSeriesEpisodes = {};
  let _currentSeriesName     = '';
  let _currentSeriesSeason   = null;
  let _currentSeriesCover    = '';

  pub.selectSeason = function(sNum) {
    _currentSeriesSeason = sNum;
    document.querySelectorAll('#vod-season-tabs .vod-season-tab').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.season === sNum);
    });
    _renderSeasonEpisodes(sNum);
  };

  function _renderSeasonEpisodes(sNum) {
    const container = document.getElementById('vod-episodes-container');
    if (!container) return;
    const eps = (_currentSeriesEpisodes[sNum] || []);
    if (eps.length === 0) {
      container.innerHTML = '<p style="color:var(--text-dim);font-size:13px;padding:10px 0">No episodes for this season.</p>';
      return;
    }
    container.innerHTML = `<div class="vod-episodes-grid">${eps.map(ep => {
      const epTitle = ep.title || `Episode ${ep.episode_num || '?'}`;
      const ext     = ep.container_extension || 'mp4';
      const sid     = ep.id;
      const label   = ep.episode_num ? `E${ep.episode_num} – ` : '';
      const fullTitle = `${_currentSeriesName} S${sNum}E${ep.episode_num || '?'}`;
      return `
        <div class="vod-episode-row">
          <span class="vod-ep-title" title="${esc(epTitle)}">${esc(label + epTitle)}</span>
          <div class="vod-ep-actions">
            <button class="btn btn-primary btn-sm" onclick="app.playEpisode(${sid},'${esc(ext)}','${esc(fullTitle)}')">
              <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
              Watch
            </button>
            <button class="btn btn-ghost btn-sm" onclick="app.downloadEpisode(${sid},'${esc(ext)}','${esc(fullTitle)}')">
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              Download
            </button>
          </div>
        </div>`;
    }).join('')}</div>`;
  }

  // ── Currently Watching ──────────────────────────────────────────────────

  let _currentlyWatching = [];

  async function _loadCurrentlyWatching() {
    try {
      _currentlyWatching = await api('GET', '/api/currently-watching') || [];
    } catch (e) {
      _currentlyWatching = [];
    }
  }

  async function _addToCurrentlyWatching(type, id, ext, name, cover) {
    const key = `${type}_${id}`;
    // Remove any existing entry for this item so it bubbles to front
    _currentlyWatching = _currentlyWatching.filter(w => w.id !== key);
    _currentlyWatching.unshift({ id: key, type, stream_id: id, ext, name, cover, watched_at: new Date().toISOString() });
    // Keep list to 20 items
    if (_currentlyWatching.length > 20) _currentlyWatching = _currentlyWatching.slice(0, 20);
    try {
      await api('POST', '/api/currently-watching', { currently_watching: _currentlyWatching });
    } catch (e) {
      // non-fatal
    }
  }

  pub.dismissCurrentlyWatching = async function(id) {
    _currentlyWatching = _currentlyWatching.filter(w => w.id !== id);
    try {
      await api('POST', '/api/currently-watching', { currently_watching: _currentlyWatching });
    } catch (e) { /* non-fatal */ }
    _renderDashCurrentlyWatching();
  };

  function _renderDashCurrentlyWatching() {
    const row   = document.getElementById('dash-currently-watching');
    const empty = document.getElementById('dash-currently-watching-empty');
    if (!row) return;
    if (_currentlyWatching.length === 0) {
      row.innerHTML = '';
      if (empty) empty.style.display = '';
      return;
    }
    if (empty) empty.style.display = 'none';
    row.innerHTML = _currentlyWatching.map(item => `
      <div class="dash-poster-card" onclick="${item.type === 'movie' ? `app.openMovieDetail(${item.stream_id})` : `app.openSeriesDetail(${item.stream_id})`}" title="${esc(item.name)}">
        ${item.cover
          ? `<img class="dash-poster-img" src="${esc(item.cover)}" alt="" loading="lazy">`
          : '<div class="dash-poster-img vod-card-poster-placeholder"></div>'}
        <div class="dash-poster-label">${esc(item.name)}</div>
        <button class="dash-poster-dismiss" onclick="event.stopPropagation();app.dismissCurrentlyWatching('${esc(item.id)}')" title="Remove">×</button>
      </div>`).join('');
  }

  // ── Watchlist ───────────────────────────────────────────────────────────

  let _watchlist = [];

  async function _loadWatchlist() {
    try {
      _watchlist = await api('GET', '/api/watchlist') || [];
    } catch (e) {
      _watchlist = [];
    }
  }

  pub.toggleWatchlist = async function(type, id, ext, name, cover) {
    const key = `${type}_${id}`;
    const idx = _watchlist.findIndex(w => w.id === key);
    if (idx >= 0) {
      _watchlist.splice(idx, 1);
    } else {
      _watchlist.push({ id: key, type, stream_id: id, ext, name, cover, added_at: new Date().toISOString() });
    }
    try {
      await api('POST', '/api/watchlist', { watchlist: _watchlist });
    } catch (e) {
      toast('Could not save watchlist', 'error');
      return;
    }
    // Update button appearance without re-opening the modal
    const inList = idx < 0;  // was just added
    const btn = document.getElementById(`wl-btn-${type}-${id}`);
    if (btn) {
      btn.classList.toggle('in-list', inList);
      btn.title = inList ? 'Remove from watchlist' : 'Add to watchlist';
      const svg = btn.querySelector('svg');
      if (svg) svg.setAttribute('fill', inList ? 'currentColor' : 'none');
    }
    toast(inList ? `Added to watchlist` : `Removed from watchlist`, 'success', 2000);
  };

  pub.dismissWatchlistItem = async function(id) {
    _watchlist = _watchlist.filter(w => w.id !== id);
    try {
      await api('POST', '/api/watchlist', { watchlist: _watchlist });
    } catch (e) { /* non-fatal */ }
    _renderDashWatchlist();
  };

  // ── Downloads + Transcodes panel ────────────────────────────────────────

  let _downloadsTimer   = null;
  let _downloadsData    = {};
  let _transcodesData   = {};

  function _onDownloadStarted(result) {
    if (result.error) { toast('Download failed: ' + result.error, 'error'); return; }
    toast('Download started - check the ↓ button for progress', 'success', 3000);
    const btn = document.getElementById('downloads-btn');
    if (btn) btn.style.display = '';
    _startDownloadPolling();
  }

  function _startDownloadPolling() {
    if (_downloadsTimer) return;
    _downloadsTimer = setInterval(_pollDownloads, 2000);
  }

  async function _pollDownloads() {
    try {
      const [dlData, tcData] = await Promise.all([
        api('GET', '/api/downloads'),
        api('GET', '/api/transcodes'),
      ]);
      _downloadsData  = dlData;
      _transcodesData = tcData;
      _renderDownloadsPanel(dlData);
      // Refresh Tasks & Files page if it's open
      if (document.getElementById('view-downloads')?.classList.contains('active')) {
        _renderDownloadsPageActive();
        _renderTranscodesPageSection();
      }
      // Stop polling when all downloads done AND all transcodes done
      const activeDl = Object.values(dlData).filter(d => d.status === 'downloading');
      const activeTc = Object.values(tcData).filter(d => d.status === 'transcoding');
      if (activeDl.length === 0 && activeTc.length === 0) {
        clearInterval(_downloadsTimer);
        _downloadsTimer = null;
      }
    } catch (e) {
      // non-fatal
    }
  }

  function _renderDownloadsPanel(data) {
    const list  = document.getElementById('downloads-list');
    const badge = document.getElementById('downloads-badge');
    const btn   = document.getElementById('downloads-btn');
    if (!list) return;

    const entries = Object.entries(data);
    if (entries.length === 0) {
      list.innerHTML = '<p class="downloads-empty">No active downloads.</p>';
      if (badge) badge.style.display = 'none';
      return;
    }

    const active = entries.filter(([, d]) => d.status === 'downloading').length;
    if (badge) {
      badge.style.display = active > 0 ? '' : 'none';
      badge.textContent   = active;
    }
    if (btn) btn.style.display = '';

    list.innerHTML = entries.map(([id, d]) => {
      const statusIcon = d.status === 'done' ? '✓' : d.status === 'error' ? '✗' : d.status === 'cancelled' ? '-' : '↓';
      const statusCls  = d.status === 'done' ? 'dl-done' : d.status === 'error' ? 'dl-error' : d.status === 'cancelled' ? 'dl-cancelled' : 'dl-active';
      const detail     = d.out_time ? `${d.out_time}${d.speed ? ' · ' + d.speed : ''}` : d.status;
      const cancelBtn  = d.status === 'downloading'
        ? `<button class="dl-cancel-btn" onclick="app.cancelDownload('${id}')" title="Cancel">✕</button>` : '';
      return `
        <div class="dl-item ${statusCls}">
          <span class="dl-status-icon">${statusIcon}</span>
          <div class="dl-item-info">
            <span class="dl-title">${esc(d.title)}</span>
            <span class="dl-detail">${esc(detail)}</span>
          </div>
          ${cancelBtn}
        </div>`;
    }).join('');
  }

  pub.toggleDownloadsPanel = function() {
    const panel = document.getElementById('downloads-panel');
    if (!panel) return;
    const isOpen = panel.style.display !== 'none';
    panel.style.display = isOpen ? 'none' : '';
    if (!isOpen) _pollDownloads();
  };

  pub.closeDownloadsPanel = function() {
    const panel = document.getElementById('downloads-panel');
    if (panel) panel.style.display = 'none';
  };

  pub.cancelDownload = async function(dlId) {
    try {
      await api('DELETE', `/api/downloads/${dlId}`);
      _pollDownloads();
    } catch (e) {
      toast('Could not cancel download', 'error');
    }
  };

  // ── Dashboard ───────────────────────────────────────────────────────────

  pub.loadDashboard = async function() {
    await Promise.all([_loadWatchlist(), _loadCurrentlyWatching()]);
    _renderDashCurrentlyWatching();
    _renderDashWatchlist();
    _loadDashLive();
    _loadDashRecordings();
  };

  function _renderDashWatchlist() {
    const row   = document.getElementById('dash-watchlist');
    const empty = document.getElementById('dash-watchlist-empty');
    if (!row) return;
    if (_watchlist.length === 0) {
      row.innerHTML = '';
      if (empty) empty.style.display = '';
      return;
    }
    if (empty) empty.style.display = 'none';
    row.innerHTML = _watchlist.map(item => `
      <div class="dash-poster-card" onclick="${item.type === 'movie' ? `app.openMovieDetail(${item.stream_id})` : `app.openSeriesDetail(${item.stream_id})`}" title="${esc(item.name)}">
        ${item.cover
          ? `<img class="dash-poster-img" src="${esc(item.cover)}" alt="" loading="lazy">`
          : '<div class="dash-poster-img vod-card-poster-placeholder"></div>'}
        <div class="dash-poster-label">${esc(item.name)}</div>
        <button class="dash-poster-dismiss" onclick="event.stopPropagation();app.dismissWatchlistItem('${esc(item.id)}')" title="Remove">×</button>
      </div>`).join('');
  }

  async function _loadDashLive() {
    const row   = document.getElementById('dash-live');
    const empty = document.getElementById('dash-live-empty');
    if (!row) return;
    try {
      const items = await api('GET', '/api/epg/live');
      if (!items || items.length === 0) {
        row.innerHTML = '';
        if (empty) empty.style.display = '';
        return;
      }
      if (empty) empty.style.display = 'none';
      const now = new Date();
      row.innerHTML = items.slice(0, 24).map(r => {
        const group  = _epgChannelMap[r.epg_channel_id];
        const chName = group ? group.display_name : (r.epg_channel_id || '');
        const logo   = group && group.stream_icon;
        return `
          <div class="dash-live-card${group ? '' : ' no-ch'}" ${group ? `onclick="app.watchChannel(app._getGroupJSON(${group.primary_stream_id}))"` : ''} title="${esc(r.title)}">
            <div class="dash-live-logo">
              ${logo ? `<img src="${esc(logo)}" alt="" onerror="this.style.display='none'">` : '<span>📺</span>'}
            </div>
            <div class="dash-live-info">
              <div class="dash-live-ch">${esc(chName)}</div>
              <div class="dash-live-show">${esc(r.title)}</div>
              <div class="dash-live-time">${fmtTimeUK(r.start)} – ${fmtTimeUK(r.end)}</div>
            </div>
          </div>`;
      }).join('');
    } catch (e) {
      // non-fatal
    }
  }

  // Helper so the dashboard can get group JSON for watchChannel
  pub._getGroupJSON = function(streamId) {
    return channels.find(c => c.primary_stream_id === streamId) || {};
  };

  async function _loadDashRecordings() {
    const container = document.getElementById('dash-recordings');
    const empty     = document.getElementById('dash-recordings-empty');
    if (!container) return;
    try {
      const recs = await api('GET', '/api/recordings');
      const recent = (recs || []).slice(0, 5);
      if (recent.length === 0) {
        container.innerHTML = '';
        if (empty) empty.style.display = '';
        return;
      }
      if (empty) empty.style.display = 'none';
      container.innerHTML = recent.map(r => `
        <div class="dash-rec-row">
          <span class="dash-rec-status dash-rec-${r.status}">${r.status}</span>
          <span class="dash-rec-name">${esc(r.show_name)}</span>
          <span class="dash-rec-time">${fmtUK(r.start_time, {weekday:'short', day:'numeric', month:'short', hour:'2-digit', minute:'2-digit'})}</span>
        </div>`).join('');
    } catch (e) {
      // non-fatal
    }
  }

  // ── Tasks & Files page ───────────────────────────────────────────────

  pub.loadDownloadsPage = async function() {
    _renderTranscodesPageSection();
    _renderDownloadsPageActive();
    _loadDownloadedFiles();
    _startDownloadPolling();

    const tcList = document.getElementById('tc-active-list');
    if (tcList && !tcList._cancelBound) {
      tcList._cancelBound = true;
      tcList.addEventListener('click', async (e) => {
        const cancelBtn = e.target.closest('.tc-cancel-btn');
        if (cancelBtn) {
          const id = cancelBtn.dataset.id;
          cancelBtn.disabled = true;
          cancelBtn.textContent = 'Cancelling…';
          try {
            await fetch(`/api/transcodes/${id}/cancel`, { method: 'POST' });
          } catch (_) {}
          return;
        }
        const dismissBtn = e.target.closest('.tc-dismiss-btn');
        if (dismissBtn) {
          const id = dismissBtn.dataset.id;
          dismissBtn.disabled = true;
          try {
            await fetch(`/api/transcodes/${id}/dismiss`, { method: 'DELETE' });
            delete _transcodesData[id];
            _renderTranscodesPageSection();
          } catch (_) {}
        }
      });
    }
  };

  function _renderTranscodesPageSection() {
    const list  = document.getElementById('tc-active-list');
    const empty = document.getElementById('tc-active-empty');
    if (!list) return;

    const entries = Object.entries(_transcodesData || {});
    const active  = entries.filter(([, d]) => d.status === 'transcoding');
    const recent  = entries.filter(([, d]) => d.status !== 'transcoding');

    if (entries.length === 0) {
      list.innerHTML = '';
      if (empty) empty.style.display = '';
      return;
    }
    if (empty) empty.style.display = 'none';

    list.innerHTML = [...active, ...recent].map(([id, d]) => {
      const isActive = d.status === 'transcoding';
      const elapsed  = d.out_time ? d.out_time.split('.')[0] : '';  // trim microseconds
      const speed    = d.speed || '';
      const meta     = isActive
        ? [elapsed && `Elapsed: ${elapsed}`, speed && `Speed: ${speed}`].filter(Boolean).join(' &nbsp;·&nbsp; ') || 'Processing...'
        : d.status === 'done' ? 'Completed' : d.status === 'cancelled' ? 'Cancelled' : 'Failed';
      const dotCls   = isActive ? 'tc-dot-active' : d.status === 'done' ? 'tc-dot-done' : 'tc-dot-error';
      return `
        <div class="dlp-row dlp-${d.status}">
          <div class="dlp-info">
            <div class="dlp-title">
              <span class="tc-dot ${dotCls}"></span>
              ${esc(d.title)}
              <span class="badge" style="background:rgba(100,210,255,0.12);color:var(--cyan);border:1px solid rgba(100,210,255,0.22);margin-left:6px;">${esc(d.codec)}</span>
            </div>
            <div class="dlp-meta">${meta}</div>
            ${isActive ? `<div class="dlp-bar-wrap"><div class="dlp-bar tc-bar"></div></div>` : ''}
          </div>
          <div class="dlp-actions">
        ${isActive
          ? `<button class="btn btn-sm btn-danger tc-cancel-btn" data-id="${id}" title="Cancel transcode">&#x2715; Cancel</button>`
          : `<button class="btn btn-sm btn-ghost tc-dismiss-btn" data-id="${id}" title="Remove from list">&#x2715; Dismiss</button>`}
      </div>
        </div>`;
    }).join('');
  }

  function _renderDownloadsPageActive() {
    const list  = document.getElementById('dl-active-list');
    const empty = document.getElementById('dl-active-empty');
    if (!list) return;

    // Collect active/recent from the shared _downloadsData
    const entries = Object.entries(_downloadsData || {});
    const active  = entries.filter(([, d]) => d.status === 'downloading');
    const recent  = entries.filter(([, d]) => d.status !== 'downloading');

    if (entries.length === 0) {
      list.innerHTML = '';
      if (empty) empty.style.display = '';
      return;
    }
    if (empty) empty.style.display = 'none';

    const rows = [...active, ...recent].map(([id, d]) => {
      const pct = _parseDownloadPct(d);
      const pctStr = pct !== null ? `${pct}%` : '';
      const statusLabel = d.status === 'downloading' ? (d.speed ? `${d.speed}` : 'Downloading...') : d.status;
      return `
        <div class="dlp-row dlp-${d.status}">
          <div class="dlp-info">
            <div class="dlp-title">${esc(d.title)}</div>
            <div class="dlp-meta">${esc(statusLabel)}${pctStr ? ' - ' + pctStr : ''}${d.out_time ? ' - ' + esc(d.out_time) : ''}</div>
            ${d.status === 'downloading' && pct !== null ? `<div class="dlp-bar-wrap"><div class="dlp-bar" style="width:${pct}%"></div></div>` : ''}
          </div>
          <div class="dlp-actions">
            ${d.status === 'downloading'
              ? `<button class="btn btn-ghost btn-sm" onclick="app.cancelDownloadPage('${esc(id)}')">Cancel</button>`
              : `<button class="btn btn-ghost btn-sm" onclick="app.clearDownloadEntry('${esc(id)}')">Clear</button>`}
          </div>
        </div>`;
    }).join('');
    list.innerHTML = rows;
  }

  function _parseDownloadPct(d) {
    // out_time is like "00:12:34.000000"; speed is like "1.2x"
    // We don't have total duration from the API, so just show time elapsed
    return null;
  }

  pub.cancelDownloadPage = async function(dlId) {
    try {
      await api('DELETE', `/api/downloads/${dlId}`);
    } catch (e) { /* ignore */ }
    _pollDownloads();
    setTimeout(_renderDownloadsPageActive, 400);
  };

  pub.clearDownloadEntry = function(dlId) {
    if (_downloadsData) delete _downloadsData[dlId];
    _renderDownloadsPageActive();
  };

  async function _loadDownloadedFiles() {
    const list  = document.getElementById('dl-files-list');
    const empty = document.getElementById('dl-files-empty');
    if (!list) return;
    list.innerHTML = '<p style="font-size:12px;color:var(--text-dim);padding:8px 0">Loading...</p>';
    try {
      const files = await api('GET', '/api/downloads/files');
      if (!files || files.length === 0) {
        list.innerHTML = '';
        if (empty) empty.style.display = '';
        return;
      }
      if (empty) empty.style.display = 'none';
      list.innerHTML = `<div class="dlp-files-grid">${files.map(f => {
        const size = _fmtBytes(f.size);
        const date = new Date(f.modified * 1000).toLocaleDateString('en-GB', {day:'numeric', month:'short', year:'numeric'});
        return `
          <div class="dlp-file-row">
            <svg class="dlp-file-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <rect x="2" y="7" width="20" height="15" rx="2"/><polyline points="17 2 12 7 7 2"/>
            </svg>
            <div class="dlp-file-info">
              <div class="dlp-file-name" title="${esc(f.name)}">${esc(f.name)}</div>
              <div class="dlp-file-meta">${esc(size)} - ${esc(date)}</div>
            </div>
            <div class="dlp-file-actions">
              <button class="btn btn-primary btn-sm" onclick="app.openDownloadedFile('${esc(f.path)}')" title="Open">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                Play
              </button>
              <button class="btn btn-ghost btn-sm" onclick="app.deleteDownloadedFile('${esc(f.path)}', '${esc(f.name)}')" title="Delete">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>
                Delete
              </button>
            </div>
          </div>`;
      }).join('')}</div>`;
    } catch (e) {
      list.innerHTML = `<p style="font-size:12px;color:var(--rec);padding:8px 0">Failed to load files: ${esc(e.message)}</p>`;
    }
  }

  function _fmtBytes(bytes) {
    if (bytes >= 1e9) return (bytes / 1e9).toFixed(2) + ' GB';
    if (bytes >= 1e6) return (bytes / 1e6).toFixed(1) + ' MB';
    if (bytes >= 1e3) return (bytes / 1e3).toFixed(0) + ' KB';
    return bytes + ' B';
  }

  pub.openDownloadedFile = async function(path) {
    try {
      await api('POST', '/api/downloads/files/open', { path });
    } catch (e) {
      toast('Could not open file: ' + e.message, 'error');
    }
  };

  pub.deleteDownloadedFile = async function(path, name) {
    if (!confirm(`Delete "${name}"? This cannot be undone.`)) return;
    try {
      await api('POST', '/api/downloads/files/delete', { path });
      toast('File deleted', 'success', 2000);
      _loadDownloadedFiles();
    } catch (e) {
      toast('Could not delete file: ' + e.message, 'error');
    }
  };

  // ── Update check ──────────────────────────────────────────────────────

  let _updateInfo = null;

  async function checkForUpdate() {
    try {
      const info = await api('GET', '/api/update/check');
      if (info.update_available) {
        _updateInfo = info;
        document.getElementById('update-banner-msg').textContent =
          `Current version: ${info.current_version} - Available version: ${info.latest_version}`;
        document.getElementById('update-banner').style.display = '';
        // Mark the topbar button so the user knows an update is ready
        const btn = document.getElementById('update-check-btn');
        if (btn) btn.classList.add('has-update');
      }
    } catch (e) {
      // Non-critical - fail silently
    }
  }

  pub.checkForUpdateManual = async function() {
    const btn = document.getElementById('update-check-btn');
    if (btn) btn.classList.add('spinning');
    try {
      await checkForUpdate();
      if (!_updateInfo?.update_available) toast('You\'re on the latest version', 'success');
    } finally {
      if (btn) btn.classList.remove('spinning');
    }
  };

  pub.downloadUpdate = async function() {
    if (!_updateInfo || !_updateInfo.download_url) return;
    const btn = document.getElementById('update-install-btn');
    btn.disabled = true;
    btn.textContent = 'Downloading…';
    try {
      const result = await api('POST', '/api/update/download', {
        download_url: _updateInfo.download_url,
        filename:     _updateInfo.filename,
      });
      btn.textContent = 'Downloaded';
      document.getElementById('update-banner-msg').textContent =
        `IPTV Manager ${_updateInfo.latest_version} has been saved to your Downloads folder. ` +
        `Extract the ZIP and drag the files into your current IPTV Manager folder to overwrite them ` +
        `(don\u2019t delete the existing folder first).`;
      document.getElementById('update-banner-actions').style.display = 'none';

      if (_updateInfo.is_major_update) {
        const title = document.getElementById('donate-modal-title');
        const msg   = document.getElementById('donate-modal-msg');
        title.textContent = `Thanks for upgrading to v${_updateInfo.latest_version}!`;
        msg.innerHTML =
          `This is a major new release. If IPTV Manager has been useful,<br>` +
          `a small donation helps fund continued development.`;
        document.getElementById('donate-modal').classList.add('open');
      }
    } catch (e) {
      btn.disabled = false;
      btn.textContent = 'Download Update';
      toast('Download failed: ' + e.message, 'error', 6000);
    }
  };

  // ── Donate ────────────────────────────────────────────────────────────

  pub.openDonate = function() {
    document.getElementById('donate-modal-title').textContent = 'Support IPTV Manager';
    document.getElementById('donate-modal-msg').innerHTML =
      'IPTV Manager is sold for a small one-off payment. If you find it useful,<br>a small donation helps keep it going.';
    document.getElementById('donate-modal').classList.add('open');
  };

  pub.closeDonate = function() {
    document.getElementById('donate-modal').classList.remove('open');
  };

  pub.submitDonate = function() {
    document.getElementById('donate-form').submit();
    pub.closeDonate();
  };

  // ── Trial ──────────────────────────────────────────────────────────────

  let _trialStatus = null;

  async function _checkTrialStatus() {
    try {
      _trialStatus = await api('GET', '/api/trial/status');
      if (!_trialStatus.trial) return;

      // Show banner
      const banner = document.getElementById('trial-banner');
      const rem    = document.getElementById('trial-remaining');
      if (banner) banner.style.display = '';
      if (rem) rem.textContent = _trialStatus.remaining;

      // Dim and lock Movies + TV Shows nav items
      ['movies', 'tvshows'].forEach(view => {
        const nav = document.querySelector(`[data-view="${view}"]`);
        if (!nav) return;
        nav.classList.add('nav-item-locked');
        // Append a lock badge if not already there
        if (!nav.querySelector('.nav-lock')) {
          const lock = document.createElement('span');
          lock.className = 'nav-lock';
          lock.textContent = '🔒';
          nav.appendChild(lock);
        }
      });
    } catch (e) { /* non-fatal */ }
  }

  pub.openBuyPage = function() {
    window.open('https://tobyjones.ca/software', '_blank');
  };

  pub.closePaywall = function() {
    const m = document.getElementById('trial-paywall-modal');
    if (m) m.classList.remove('open');
  };

  pub.showPaywall = function() {
    const m = document.getElementById('trial-paywall-modal');
    if (m) m.classList.add('open');
  };

  // ── Init ───────────────────────────────────────────────────────────────

  async function init() {
    // Close modals on backdrop click
    document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
      backdrop.addEventListener('click', e => {
        if (e.target === backdrop) {
          backdrop.classList.remove('open');
          if (backdrop.id === 'player-modal') pub.closePlayer();
          if (backdrop.id === 'donate-modal') pub.closeDonate();
        }
      });
    });

    // Nav click handlers
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', () => pub.navigateTo(item.dataset.view));
    });

    // Load settings first so we can check setup_complete
    await pub.loadSettings();

    // Show wizard if setup not complete and no existing credentials
    checkForUpdate();
    _checkTrialStatus();

    _loadWatchlist();   // pre-load watchlist for modals + dashboard

    if (!settings.setup_complete && !settings.xtream_host) {
      pub.wizard.show();
    } else {
      loadChannels();
      // Support ?view=settings (or other view) from menubar "Open Settings" link
      const _initView = new URLSearchParams(window.location.search).get('view');
      if (_initView) pub.navigateTo(_initView);
    }

    // Auto-refresh recordings status every 30s
    setInterval(() => {
      const recView = document.getElementById('view-recordings');
      if (recView && recView.classList.contains('active')) {
        pub.loadRecordings();
      }
    }, 30000);
  }

  // Expose EPG instance so HTML onclick handlers (app.epg.shiftTime etc.) work
  pub.epg = epg;

  init();
  return pub;
})();
