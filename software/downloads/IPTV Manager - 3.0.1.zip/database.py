"""
SQLite database layer for IPTV Manager.
All times stored as UTC ISO strings. UK timezone conversion happens in the API layer.
"""
import sqlite3
import json
from pathlib import Path

DB_PATH = Path(__file__).parent / "data" / "iptv_manager.db"


def get_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    with get_db() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS recordings (
                id            TEXT PRIMARY KEY,
                type          TEXT NOT NULL DEFAULT 'once',
                channel_id    TEXT,
                channel_name  TEXT,
                show_name     TEXT NOT NULL,
                season        INTEGER DEFAULT 1,
                episode       INTEGER DEFAULT 1,
                save_path     TEXT NOT NULL,
                quality       TEXT NOT NULL DEFAULT '{}',
                start_time    TEXT NOT NULL,
                end_time      TEXT NOT NULL,
                status        TEXT NOT NULL DEFAULT 'scheduled',
                recurrence    TEXT,
                output_file   TEXT,
                created_at    TEXT NOT NULL,
                scheduler_id  TEXT,
                padding_start INTEGER NOT NULL DEFAULT 0,
                padding_end   INTEGER NOT NULL DEFAULT 0,
                paused_until  TEXT,
                parent_id     TEXT
            );
        """)
        # Migrate existing databases that pre-date these columns
        for col, defn in [
            ("padding_start", "INTEGER NOT NULL DEFAULT 0"),
            ("padding_end",   "INTEGER NOT NULL DEFAULT 0"),
            ("paused_until",  "TEXT"),
            ("parent_id",     "TEXT"),
        ]:
            try:
                conn.execute(f"ALTER TABLE recordings ADD COLUMN {col} {defn}")
                conn.commit()
            except Exception:
                pass  # column already exists


# ─── Settings ────────────────────────────────────────────────────────────────

DEFAULT_SETTINGS = {
    "xtream_host": "",
    "xtream_username": "",
    "xtream_password": "",
    "default_save_path": str(Path.home() / "Movies" / "IPTV Recordings"),
    "default_quality": {
        "codec": "copy",
        "resolution": "1920x1080",
        "crf": 18,
        "preset": "medium",
        "audio_codec": "aac",
        "transcode_after": False,
        "transcode_codec": "hevc",
        "transcode_resolution": "1920x1080",
        "transcode_crf": 18,
        "transcode_preset": "medium",
    },
    "timezone": "local",
    "epg_filter_channels": "1",   # "1" = only show channels with EPG data in TV Guide
    "channels_last_updated": None,
    "sports_favourites": [],
    "watchlist": [],
    "currently_watching": [],
}


def get_settings():
    with get_db() as conn:
        rows = conn.execute("SELECT key, value FROM settings").fetchall()
        data = dict(DEFAULT_SETTINGS)
        for row in rows:
            try:
                data[row["key"]] = json.loads(row["value"])
            except (json.JSONDecodeError, TypeError):
                data[row["key"]] = row["value"]
        return data


def save_settings(updates: dict):
    with get_db() as conn:
        for key, value in updates.items():
            conn.execute(
                "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                (key, json.dumps(value))
            )
        conn.commit()


# ─── Recordings ──────────────────────────────────────────────────────────────

def get_all_recordings():
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM recordings ORDER BY start_time DESC"
        ).fetchall()
        return [_row_to_recording(r) for r in rows]


def get_recording(rec_id: str):
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM recordings WHERE id=?", (rec_id,)
        ).fetchone()
        return _row_to_recording(row) if row else None


def get_recordings_by_status(status: str):
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM recordings WHERE status=? ORDER BY start_time",
            (status,)
        ).fetchall()
        return [_row_to_recording(r) for r in rows]


def save_recording(rec: dict):
    with get_db() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO recordings
            (id, type, channel_id, channel_name, show_name, season, episode,
             save_path, quality, start_time, end_time, status, recurrence,
             output_file, created_at, scheduler_id, padding_start, padding_end,
             paused_until, parent_id)
            VALUES (:id, :type, :channel_id, :channel_name, :show_name,
                    :season, :episode, :save_path, :quality, :start_time,
                    :end_time, :status, :recurrence, :output_file,
                    :created_at, :scheduler_id, :padding_start, :padding_end,
                    :paused_until, :parent_id)
        """, {
            **rec,
            "quality": json.dumps(rec.get("quality", {})),
            "recurrence": json.dumps(rec.get("recurrence")) if rec.get("recurrence") else None,
            "paused_until": rec.get("paused_until"),
            "parent_id": rec.get("parent_id"),
        })
        conn.commit()


def update_recording_status(rec_id: str, status: str, output_file: str = None):
    with get_db() as conn:
        if output_file:
            conn.execute(
                "UPDATE recordings SET status=?, output_file=? WHERE id=?",
                (status, output_file, rec_id)
            )
        else:
            conn.execute(
                "UPDATE recordings SET status=? WHERE id=?",
                (status, rec_id)
            )
        conn.commit()


def update_recording_episode(rec_id: str, new_episode: int):
    with get_db() as conn:
        conn.execute(
            "UPDATE recordings SET episode=? WHERE id=?",
            (new_episode, rec_id)
        )
        conn.commit()


def reset_db():
    """Drop all settings and recordings, then recreate the schema from scratch."""
    with get_db() as conn:
        conn.executescript("""
            DROP TABLE IF EXISTS settings;
            DROP TABLE IF EXISTS recordings;
        """)
        conn.commit()
    init_db()


def delete_recording(rec_id: str):
    with get_db() as conn:
        conn.execute("DELETE FROM recordings WHERE id=?", (rec_id,))
        conn.commit()


def _row_to_recording(row) -> dict:
    if row is None:
        return None
    d = dict(row)
    try:
        d["quality"] = json.loads(d.get("quality") or "{}")
    except (json.JSONDecodeError, TypeError):
        d["quality"] = {}
    try:
        d["recurrence"] = json.loads(d.get("recurrence") or "null")
    except (json.JSONDecodeError, TypeError):
        d["recurrence"] = None
    d.setdefault("parent_id", None)
    return d
