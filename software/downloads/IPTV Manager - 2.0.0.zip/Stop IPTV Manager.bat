@echo off
setlocal enabledelayedexpansion

set "FOUND=0"

REM Find the PID listening on port 5001 and stop it
for /f "tokens=5" %%P in ('netstat -ano 2^>nul ^| findstr /R "[ :]5001 " ^| findstr "LISTENING"') do (
    if not "%%P" == "" (
        taskkill /F /PID %%P >nul 2>&1
        if not errorlevel 1 (
            set "FOUND=1"
        )
    )
)

if "!FOUND!" == "1" (
    echo IPTV Manager stopped.
) else (
    echo IPTV Manager is not running.
)

timeout /t 2 /nobreak >nul
