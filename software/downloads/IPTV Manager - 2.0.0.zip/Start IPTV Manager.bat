@echo off
setlocal enabledelayedexpansion

set "DIR=%~dp0"
set "DIR=%DIR:~0,-1%"

if not exist "%DIR%\data" mkdir "%DIR%\data"

REM ── Already running? (check if port 5001 is listening) ───────────────────────
netstat -ano 2>nul | findstr /R "[ :]5001 " | findstr "LISTENING" >nul 2>&1
if not errorlevel 1 (
    echo IPTV Manager is already running.
    echo Opening the web UI...
    start "" "http://localhost:5001"
    timeout /t 3 /nobreak >nul
    exit /b 0
)

REM ── Find Python ──────────────────────────────────────────────────────────────
set "VENV_PYW=%DIR%\.venv\Scripts\pythonw.exe"
set "VENV_PY=%DIR%\.venv\Scripts\python.exe"
set "PY="

if exist "%VENV_PYW%" (
    set "PY=%VENV_PYW%"
) else if exist "%VENV_PY%" (
    set "PY=%VENV_PY%"
) else (
    echo.
    echo ERROR: No virtual environment found.
    echo Please run "Install IPTV Manager.bat" first.
    echo.
    pause
    exit /b 1
)

REM ── Launch (detached, no console window) ─────────────────────────────────────
cd /d "%DIR%"
start "" "%PY%" "%DIR%\menubar.py"

echo.
echo IPTV Manager is starting...
echo The TV icon will appear in your system tray in a moment.
echo.
timeout /t 5 /nobreak >nul
start "" "http://localhost:5001"
