#!/usr/bin/env python3
"""
IPTV Manager — Cross-Platform Tray/Menubar App

Runs the Flask web server in a background thread and places a TV icon in
the macOS menu bar (rumps) or Windows system tray (pystray).
The web UI stays accessible at http://localhost:5001 while the app runs
silently in the background.

Launch via:  python3 menubar.py
  macOS:     Double-click "Start IPTV Manager.command"
  Windows:   Double-click "Start IPTV Manager.bat"
"""
import os
import sys
import threading
import webbrowser

# Make sure the project root is importable regardless of cwd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import database as db
import recorder
from xtream import load_channel_cache, clear_channel_cache
import app as _app_module   # the Flask module (not the Flask instance)

PORT = 5001


# ─────────────────────────────────────────────────────────────────────────────
# macOS — rumps menubar app
# ─────────────────────────────────────────────────────────────────────────────

if sys.platform == "darwin":
    import rumps
    from AppKit import NSApplication

    class IPTVManagerApp(rumps.App):

        def __init__(self):
            super().__init__("📺", quit_button=None)

            # Hide from Dock and ⌘-Tab app switcher — menubar-only app
            NSApplication.sharedApplication().setActivationPolicy_(1)

            self._status_item = rumps.MenuItem("Starting…")
            self._rec_item    = rumps.MenuItem("No active recordings")

            self.menu = [
                rumps.MenuItem("Open IPTV Manager",       callback=self.open_ui),
                rumps.MenuItem("Open Settings",           callback=self.open_settings),
                rumps.MenuItem("Open Recordings Folder",  callback=self.open_recordings_folder),
                None,
                self._status_item,
                self._rec_item,
                None,
                rumps.MenuItem("Factory Reset…",          callback=self.factory_reset),
                rumps.MenuItem("Quit IPTV Manager",       callback=self.quit_app),
            ]

            threading.Thread(
                target=self._run_server, daemon=True, name="iptv-flask"
            ).start()

            rumps.Timer(self._refresh_status, 15).start()

        def _run_server(self):
            try:
                db.init_db()
                _app_module.scheduler.start()
                _app_module.restore_scheduled_recordings()

                cached = load_channel_cache()
                if cached:
                    with _app_module._channel_groups_lock:
                        _app_module._channel_groups_cache = cached

                self._status_item.title = "Server running · localhost:5001"

                threading.Timer(
                    1.5, lambda: webbrowser.open(f"http://localhost:{PORT}")
                ).start()

                _app_module.app.run(
                    host="0.0.0.0",
                    port=PORT,
                    debug=False,
                    use_reloader=False,
                    threaded=True,
                )
            except Exception as e:
                self._status_item.title = f"Error: {e}"

        def open_ui(self, _):
            webbrowser.open(f"http://localhost:{PORT}")

        def open_settings(self, _):
            webbrowser.open(f"http://localhost:{PORT}/?view=settings")

        def open_recordings_folder(self, _):
            settings = db.get_settings()
            path = settings.get("default_save_path", "").strip()
            if not path:
                rumps.alert(
                    title="Recordings Folder",
                    message="No recordings folder is set.\nOpen Settings to configure one.",
                    ok="OK",
                )
                return
            os.makedirs(path, exist_ok=True)
            os.system(f"open {repr(path)}")

        def _refresh_status(self, _):
            active  = recorder.get_active_recordings()
            running = [v for v in active.values() if v.get("running")]
            n = len(running)
            self._rec_item.title = (
                f"● {n} recording{'s' if n > 1 else ''} active"
                if n else "No active recordings"
            )

        def factory_reset(self, _):
            confirmed = rumps.alert(
                title="Factory Reset",
                message=(
                    "This will delete all settings, credentials, and scheduled recordings.\n\n"
                    "The installer will open to set everything up from scratch.\n\n"
                    "Any active recordings will be stopped. This cannot be undone."
                ),
                ok="Reset & Reinstall",
                cancel="Cancel",
            )
            if not confirmed:
                return

            for rec_id in list(recorder.get_active_recordings()):
                recorder.stop_recording(rec_id)

            db.reset_db()
            clear_channel_cache()

            installer = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "Install IPTV Manager.command",
            )
            if os.path.exists(installer):
                import subprocess
                subprocess.Popen(["open", installer])

            rumps.quit_application()

        def quit_app(self, _):
            active  = recorder.get_active_recordings()
            running = {k: v for k, v in active.items() if v.get("running")}

            if running:
                n = len(running)
                confirmed = rumps.alert(
                    title="Active Recordings",
                    message=(
                        f"{'1 recording is' if n == 1 else f'{n} recordings are'} still "
                        f"in progress.\n"
                        f"Stop {'it' if n == 1 else 'them'} and quit?"
                    ),
                    ok="Stop & Quit",
                    cancel="Cancel",
                )
                if not confirmed:
                    return
                for rec_id in list(running):
                    recorder.stop_recording(rec_id)

            try:
                _app_module.scheduler.shutdown(wait=False)
            except Exception:
                pass

            rumps.quit_application()


# ─────────────────────────────────────────────────────────────────────────────
# Windows — pystray system tray app
# ─────────────────────────────────────────────────────────────────────────────

elif sys.platform == "win32":
    import time
    import ctypes
    import subprocess
    import pystray
    from PIL import Image, ImageDraw

    # Windows MessageBox constants
    _MB_OK            = 0x00
    _MB_OKCANCEL      = 0x01
    _MB_YESNO         = 0x04
    _MB_ICONINFO      = 0x40
    _MB_ICONWARNING   = 0x30
    _MB_ICONQUESTION  = 0x20
    _IDOK   = 1
    _IDYES  = 6

    def _msgbox(title: str, message: str, style: int = _MB_OK) -> int:
        """Thread-safe Windows MessageBox. Returns button ID."""
        return ctypes.windll.user32.MessageBoxW(0, message, title, style)

    def _make_tray_icon() -> Image.Image:
        """Generate a simple purple TV icon for the system tray."""
        size = 64
        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        purple = "#7c3aed"
        dark   = "#1e1b4b"
        # TV body
        d.rounded_rectangle([2, 4, 62, 46], radius=6, fill=purple)
        # Screen
        d.rounded_rectangle([8, 10, 56, 40], radius=3, fill=dark)
        # Stand
        d.rectangle([26, 46, 38, 54], fill=purple)
        # Base
        d.rectangle([18, 54, 46, 58], fill=purple)
        return img

    class WindowsTrayApp:

        def __init__(self):
            self._status     = "Starting…"
            self._rec_status = "No active recordings"
            self._icon       = None

        def _build_menu(self):
            return pystray.Menu(
                pystray.MenuItem("Open IPTV Manager",
                                 self.open_ui, default=True),
                pystray.MenuItem("Open Settings",
                                 self.open_settings),
                pystray.MenuItem("Open Recordings Folder",
                                 self.open_recordings_folder),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem(lambda item: self._status,
                                 None, enabled=False),
                pystray.MenuItem(lambda item: self._rec_status,
                                 None, enabled=False),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Factory Reset…", self.factory_reset),
                pystray.MenuItem("Quit IPTV Manager", self.quit_app),
            )

        # ── Server startup ────────────────────────────────────────────────

        def _run_server(self):
            try:
                db.init_db()
                _app_module.scheduler.start()
                _app_module.restore_scheduled_recordings()

                cached = load_channel_cache()
                if cached:
                    with _app_module._channel_groups_lock:
                        _app_module._channel_groups_cache = cached

                self._status = "Server running · localhost:5001"
                if self._icon:
                    self._icon.update_menu()

                threading.Timer(
                    1.5, lambda: webbrowser.open(f"http://localhost:{PORT}")
                ).start()

                _app_module.app.run(
                    host="0.0.0.0",
                    port=PORT,
                    debug=False,
                    use_reloader=False,
                    threaded=True,
                )
            except Exception as e:
                self._status = f"Error: {e}"
                if self._icon:
                    self._icon.update_menu()

        def _poll_status(self):
            """Background thread — refreshes recording count every 15 s."""
            while True:
                try:
                    active  = recorder.get_active_recordings()
                    running = [v for v in active.values() if v.get("running")]
                    n = len(running)
                    self._rec_status = (
                        f"● {n} recording{'s' if n > 1 else ''} active"
                        if n else "No active recordings"
                    )
                    if self._icon:
                        self._icon.update_menu()
                except Exception:
                    pass
                time.sleep(15)

        # ── Menu callbacks ────────────────────────────────────────────────

        def open_ui(self, icon=None, item=None):
            webbrowser.open(f"http://localhost:{PORT}")

        def open_settings(self, icon=None, item=None):
            webbrowser.open(f"http://localhost:{PORT}/?view=settings")

        def open_recordings_folder(self, icon=None, item=None):
            settings = db.get_settings()
            path = settings.get("default_save_path", "").strip()
            if not path:
                _msgbox(
                    "Recordings Folder",
                    "No recordings folder is set.\nOpen Settings to configure one.",
                    _MB_ICONINFO,
                )
                return
            os.makedirs(path, exist_ok=True)
            os.startfile(path)

        def factory_reset(self, icon=None, item=None):
            result = _msgbox(
                "Factory Reset",
                (
                    "This will delete all settings, credentials, and scheduled "
                    "recordings.\n\n"
                    "The installer will open to set everything up from scratch.\n\n"
                    "Any active recordings will be stopped. This cannot be undone.\n\n"
                    "Are you sure?"
                ),
                _MB_ICONWARNING | _MB_YESNO,
            )
            if result != _IDYES:
                return

            for rec_id in list(recorder.get_active_recordings()):
                recorder.stop_recording(rec_id)

            db.reset_db()
            clear_channel_cache()

            installer = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "Install IPTV Manager.bat",
            )
            if os.path.exists(installer):
                subprocess.Popen(
                    ["cmd", "/c", installer],
                    creationflags=subprocess.CREATE_NEW_CONSOLE,
                )

            if self._icon:
                self._icon.stop()

        def quit_app(self, icon=None, item=None):
            active  = recorder.get_active_recordings()
            running = {k: v for k, v in active.items() if v.get("running")}

            if running:
                n = len(running)
                result = _msgbox(
                    "Active Recordings",
                    (
                        f"{'1 recording is' if n == 1 else f'{n} recordings are'} "
                        f"still in progress.\n"
                        f"Stop {'it' if n == 1 else 'them'} and quit?"
                    ),
                    _MB_ICONQUESTION | _MB_YESNO,
                )
                if result != _IDYES:
                    return
                for rec_id in list(running):
                    recorder.stop_recording(rec_id)

            try:
                _app_module.scheduler.shutdown(wait=False)
            except Exception:
                pass

            if self._icon:
                self._icon.stop()

        # ── Entry point ───────────────────────────────────────────────────

        def run(self):
            threading.Thread(
                target=self._run_server, daemon=True, name="iptv-flask"
            ).start()
            threading.Thread(
                target=self._poll_status, daemon=True, name="iptv-status"
            ).start()

            self._icon = pystray.Icon(
                "IPTV Manager",
                _make_tray_icon(),
                "IPTV Manager",
                self._build_menu(),
            )
            self._icon.run()


# ─────────────────────────────────────────────────────────────────────────────
# Linux / other — headless server only (no tray)
# ─────────────────────────────────────────────────────────────────────────────

else:
    class _HeadlessApp:
        def run(self):
            print(f"IPTV Manager running at http://localhost:{PORT}")
            print("No tray support on this platform — running as a plain server.")
            db.init_db()
            _app_module.scheduler.start()
            _app_module.restore_scheduled_recordings()
            cached = load_channel_cache()
            if cached:
                with _app_module._channel_groups_lock:
                    _app_module._channel_groups_cache = cached
            _app_module.app.run(
                host="0.0.0.0",
                port=PORT,
                debug=False,
                use_reloader=False,
                threaded=True,
            )


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if sys.platform == "darwin":
        IPTVManagerApp().run()
    elif sys.platform == "win32":
        WindowsTrayApp().run()
    else:
        _HeadlessApp().run()
