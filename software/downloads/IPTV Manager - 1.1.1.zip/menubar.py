#!/usr/bin/env python3
"""
IPTV Manager — macOS Menubar App

Runs the Flask web server in a background thread and places a 📺 icon in
the macOS menu bar.  The web UI stays accessible at http://localhost:5001
while the app runs silently in the background.

Launch via:  python3 menubar.py
Or double-click:  "Start IPTV Manager.command"
"""
import os
import sys
import threading
import webbrowser

# Make sure the project root is importable regardless of cwd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import rumps
from AppKit import NSApplication

import database as db
import recorder
from xtream import load_channel_cache, clear_channel_cache
import app as _app_module   # the Flask module (not the Flask instance)

PORT = 5001


class IPTVManagerApp(rumps.App):

    def __init__(self):
        super().__init__("📺", quit_button=None)

        # Hide from Dock and ⌘-Tab app switcher — menubar-only app
        # Must call sharedApplication() explicitly; the NSApp proxy is None
        # until after the Cocoa event loop initialises.
        NSApplication.sharedApplication().setActivationPolicy_(1)

        # Dynamic menu items we update later
        self._status_item  = rumps.MenuItem("Starting…")
        self._rec_item     = rumps.MenuItem("No active recordings")

        self.menu = [
            rumps.MenuItem("Open IPTV Manager", callback=self.open_ui),
            rumps.MenuItem("Open Settings",     callback=self.open_settings),
            rumps.MenuItem("Open Recordings Folder", callback=self.open_recordings_folder),
            None,                   # ── separator ──
            self._status_item,
            self._rec_item,
            None,                   # ── separator ──
            rumps.MenuItem("Factory Reset…",    callback=self.factory_reset),
            rumps.MenuItem("Quit IPTV Manager", callback=self.quit_app),
        ]

        # Boot the Flask server in a background daemon thread
        threading.Thread(
            target=self._run_server, daemon=True, name="iptv-flask"
        ).start()

        # Refresh the recording-count badge every 15 s
        rumps.Timer(self._refresh_status, 15).start()

    # ── Server startup ────────────────────────────────────────────────────

    def _run_server(self):
        try:
            db.init_db()
            _app_module.scheduler.start()
            _app_module.restore_scheduled_recordings()

            cached = load_channel_cache()
            if cached:
                with _app_module._channel_groups_lock:
                    _app_module._channel_groups_cache = cached

            self._status_item.title = "Server running · localhost:5001"

            # Open the browser automatically once Flask is ready
            threading.Timer(
                1.5, lambda: webbrowser.open(f"http://localhost:{PORT}")
            ).start()

            # Blocks this thread — Flask runs here
            _app_module.app.run(
                host="0.0.0.0",
                port=PORT,
                debug=False,
                use_reloader=False,
                threaded=True,
            )
        except Exception as e:
            self._status_item.title = f"Error: {e}"

    # ── Menu callbacks ────────────────────────────────────────────────────

    def open_ui(self, _):
        webbrowser.open(f"http://localhost:{PORT}")

    def open_settings(self, _):
        webbrowser.open(f"http://localhost:{PORT}/?view=settings")

    def open_recordings_folder(self, _):
        settings = db.get_settings()
        path = settings.get("default_save_path", "").strip()
        if not path:
            rumps.alert(
                title="Recordings Folder",
                message="No recordings folder is set.\nOpen Settings to configure one.",
                ok="OK",
            )
            return
        os.makedirs(path, exist_ok=True)
        os.system(f'open {repr(path)}')

    def _refresh_status(self, _):
        active  = recorder.get_active_recordings()
        running = [v for v in active.values() if v.get("running")]
        n = len(running)
        if n:
            self._rec_item.title = f"● {n} recording{'s' if n > 1 else ''} active"
        else:
            self._rec_item.title = "No active recordings"

    def factory_reset(self, _):
        confirmed = rumps.alert(
            title="Factory Reset",
            message=(
                "This will delete all settings, credentials, and scheduled recordings.\n\n"
                "The installer will open to set everything up from scratch.\n\n"
                "Any active recordings will be stopped. This cannot be undone."
            ),
            ok="Reset & Reinstall",
            cancel="Cancel",
        )
        if not confirmed:
            return

        # Stop active recordings
        for rec_id in list(recorder.get_active_recordings()):
            recorder.stop_recording(rec_id)

        # Wipe the database and clear disk caches
        db.reset_db()
        clear_channel_cache()

        # Open the installer in Terminal
        installer = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "Install IPTV Manager.command")
        if os.path.exists(installer):
            import subprocess
            subprocess.Popen(["open", installer])

        rumps.quit_application()

    def quit_app(self, _):
        active  = recorder.get_active_recordings()
        running = {k: v for k, v in active.items() if v.get("running")}

        if running:
            n = len(running)
            confirmed = rumps.alert(
                title="Active Recordings",
                message=(
                    f"{'1 recording is' if n == 1 else f'{n} recordings are'} still "
                    f"in progress.\n"
                    f"Stop {'it' if n == 1 else 'them'} and quit?"
                ),
                ok="Stop & Quit",
                cancel="Cancel",
            )
            if not confirmed:
                return

            for rec_id in list(running):
                recorder.stop_recording(rec_id)

        try:
            _app_module.scheduler.shutdown(wait=False)
        except Exception:
            pass

        rumps.quit_application()


if __name__ == "__main__":
    IPTVManagerApp().run()
