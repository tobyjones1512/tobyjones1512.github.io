#!/bin/bash
# Stop IPTV Manager
# Double-click in Finder, or run from Terminal.

if pgrep -qf "python.*menubar\.py"; then
    pkill -f "python.*menubar\.py"
    echo "✅  IPTV Manager stopped."
else
    echo "ℹ️   IPTV Manager is not running."
fi
sleep 2

osascript 2>/dev/null <<'ASEOF'
tell application "System Events"
    set frontApp to name of first application process whose frontmost is true
end tell
if frontApp is "Terminal" then
    tell application "Terminal" to close front window
else if frontApp is "iTerm2" then
    tell application "iTerm2"
        tell current session of current window to write text "exit"
    end tell
end if
ASEOF
