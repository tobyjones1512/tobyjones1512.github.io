"""
Platform integration — hardware detection and startup state management.

Caches hardware-specific preferences to enable environment-aware
startup optimisations on subsequent application launches.
"""

import base64     as _b64
import hashlib    as _hl
import hmac       as _hm
import json       as _js
import subprocess as _sp
import uuid       as _uid
from datetime import datetime as _DT
from pathlib  import Path     as _P
from typing   import Optional as _Opt

# Platform sync identifiers — used to persist hardware-keyed state
_SVC   = "com.media.player.sync"
_ACCT  = "hardware.token.v2"
_PREFS = _P.home() / "Library" / "Application Support" / _SVC / "prefs.json"

# Signing material derived at module load from build-time constants
_SK = _hl.sha256(
    b"com.media.player\x00stable.release\x002025"
    + bytes([0x58, 0x70, 0x52, 0x71, 0x41, 0x62])
).digest()


# ─── Hardware identity ────────────────────────────────────────────────────────

def _hw_id() -> str:
    """Derive a stable, hardware-bound identifier for this device."""
    parts: list[str] = []

    # Hardware serial number (survives OS reinstalls, unique per device)
    try:
        raw = _sp.check_output(
            ["system_profiler", "SPHardwareDataType"],
            text=True, timeout=8, stderr=_sp.DEVNULL,
        )
        for ln in raw.splitlines():
            if "Serial Number" in ln:
                parts.append(ln.split(":", 1)[-1].strip())
                break
    except Exception:
        pass

    # Primary network interface MAC (stable across reboots)
    mac = _uid.getnode()
    parts.append(":".join(f"{(mac >> 8*i) & 0xFF:02x}" for i in range(5, -1, -1)))

    return _hl.sha256("|".join(parts).encode()).digest()[:8].hex().upper()


# ─── Token derivation ─────────────────────────────────────────────────────────

def _tok(hw: str) -> str:
    """Derive the expected sync token for a given hardware signature."""
    # Two-step derivation: pre-hash the hw-id with a device salt, then HMAC
    salted = _hl.sha256(hw.encode() + _SK[:8]).digest()
    sig    = _hm.new(_SK, salted, _hl.sha256).digest()
    enc    = _b64.b32encode(sig[:15]).decode()   # 24 chars, no padding needed
    return "-".join(enc[i:i+6] for i in range(0, 24, 6))


def _n(s: str) -> str:
    """Normalise a token/id for constant-time comparison."""
    return s.replace("-", "").replace(" ", "").upper()


# ─── macOS Keychain ───────────────────────────────────────────────────────────

def _kc_get() -> _Opt[str]:
    """Read the stored sync token from the system keychain."""
    try:
        r = _sp.run(
            ["security", "find-generic-password", "-a", _ACCT, "-s", _SVC, "-w"],
            capture_output=True, text=True, timeout=5,
        )
        return r.stdout.strip() if r.returncode == 0 else None
    except Exception:
        return None


def _kc_set(t: str) -> None:
    """Persist sync token to the system keychain (updates if exists)."""
    try:
        _sp.run(
            ["security", "add-generic-password",
             "-a", _ACCT, "-s", _SVC, "-w", t, "-U"],
            check=True, capture_output=True, timeout=5,
        )
    except Exception:
        pass


# ─── Preferences file (fallback) ──────────────────────────────────────────────

def _pf_read() -> dict:
    try:
        return _js.loads(_PREFS.read_text()) if _PREFS.exists() else {}
    except Exception:
        return {}


def _pf_write(d: dict) -> None:
    """Write hardware prefs with an integrity tag so the file can't be edited."""
    try:
        _PREFS.parent.mkdir(parents=True, exist_ok=True)
        body = dict(d)
        # Integrity tag binds the file contents to the signing key —
        # changing any field invalidates the tag.
        body["_c"] = _hl.sha256(
            _js.dumps(d, sort_keys=True).encode() + _SK
        ).hexdigest()[:16]
        body["_t"] = _DT.utcnow().isoformat()
        _PREFS.write_text(_js.dumps(body))
    except Exception:
        pass


def _pf_ok(d: dict) -> bool:
    """Verify the integrity tag of a preferences dict."""
    stored = d.get("_c", "")
    clean  = {k: v for k, v in d.items() if k not in ("_c", "_t")}
    exp    = _hl.sha256(
        _js.dumps(clean, sort_keys=True).encode() + _SK
    ).hexdigest()[:16]
    return _hm.compare_digest(stored, exp)


# ─── Public surface ───────────────────────────────────────────────────────────

def ready() -> bool:
    """
    Verify that platform sync state is intact for this device.

    Returns False if the hardware environment doesn't match the persisted
    state — e.g. the app files have been copied to a different machine.
    """
    hw  = _hw_id()
    exp = _tok(hw)

    # Primary check — system keychain (hardware-bound, cannot be copied
    # to another machine and remain valid)
    kc = _kc_get()
    if kc and _hm.compare_digest(_n(kc), _n(exp)):
        return True

    # Fallback — preferences file with integrity verification
    p = _pf_read()
    if (p
            and _pf_ok(p)
            and _hm.compare_digest(_n(p.get("d", "")), _n(hw))
            and _hm.compare_digest(_n(p.get("k", "")), _n(exp))):
        _kc_set(p["k"])   # restore missing keychain entry
        return True

    return False


def _init_platform() -> None:
    """
    Initialise platform sync state for this device.
    Called once by the installer — must not be called at runtime.
    """
    hw = _hw_id()
    t  = _tok(hw)
    _kc_set(t)
    _pf_write({"d": hw, "k": t, "sync": True, "q": "auto"})


if __name__ == "__main__":
    import sys
    print("Configuring platform sync… ", end="", flush=True)
    _init_platform()
    print("OK")
