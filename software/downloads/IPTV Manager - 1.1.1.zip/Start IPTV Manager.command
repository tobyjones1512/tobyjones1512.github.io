#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# Start IPTV Manager
# Double-click this file in Finder, or run it from Terminal.
# The app will appear as 📺 in your menu bar; this window will close itself.
# ─────────────────────────────────────────────────────────────────────────────

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG="$DIR/data/iptv_manager.log"
mkdir -p "$DIR/data"

# ── Already running? ──────────────────────────────────────────────────────────
if pgrep -qf "python.*menubar\.py"; then
    echo "✅  IPTV Manager is already running."
    echo "    Look for 📺 in your menu bar."
    echo "    Opening the web UI…"
    open "http://localhost:5001"
    sleep 3
    osascript 2>/dev/null <<'ASEOF'
tell application "System Events"
    set frontApp to name of first application process whose frontmost is true
end tell
if frontApp is "Terminal" then
    tell application "Terminal" to close front window
else if frontApp is "iTerm2" then
    tell application "iTerm2"
        tell current session of current window to write text "exit"
    end tell
end if
ASEOF
    exit 0
fi

# ── Choose Python ─────────────────────────────────────────────────────────────
# Prefer the installer's virtual environment; fall back to system Python.
VENV_PY="$DIR/.venv/bin/python3"

if [ -f "$VENV_PY" ]; then
    PY="$VENV_PY"
else
    # No venv — guide the user to run the installer first
    echo ""
    echo "⚠️  No virtual environment found."
    echo "   Please double-click 'Install IPTV Manager.command' first."
    echo ""
    echo "   Falling back to system Python (some features may not work)…"
    echo ""

    # Add Homebrew Python to PATH
    export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

    if command -v pythonw &>/dev/null; then
        PY=pythonw
    elif command -v python3 &>/dev/null; then
        PY=python3
    else
        echo "❌  Python 3 not found."
        echo "    Please run 'Install IPTV Manager.command' to set everything up."
        sleep 8
        exit 1
    fi

    # Quick dependency check / install
    "$PY" -c "import rumps" 2>/dev/null || {
        echo "Installing dependencies…"
        "$PY" -m pip install -r "$DIR/requirements.txt" -q
    }
fi

# ── Launch detached from this terminal session ────────────────────────────────
cd "$DIR"
nohup "$PY" "$DIR/menubar.py" >> "$LOG" 2>&1 &
BGPID=$!
disown $BGPID

echo ""
echo "✅  IPTV Manager is starting…"
echo "    📺 The TV icon will appear in your menu bar in a moment."
echo "    Logs: $LOG"
echo ""
sleep 3

# ── Close this terminal window ────────────────────────────────────────────────
osascript 2>/dev/null <<'ASEOF'
tell application "System Events"
    set frontApp to name of first application process whose frontmost is true
end tell
if frontApp is "Terminal" then
    tell application "Terminal" to close front window
else if frontApp is "iTerm2" then
    tell application "iTerm2"
        tell current session of current window to write text "exit"
    end tell
end if
ASEOF
