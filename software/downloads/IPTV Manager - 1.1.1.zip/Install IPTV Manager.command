#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# IPTV Manager — Installer
# Double-click this file in Finder to install everything needed.
# ─────────────────────────────────────────────────────────────────────────────

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="$DIR/.venv"
LOG="$DIR/data/install.log"
mkdir -p "$DIR/data"

# ── Colour helpers ────────────────────────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'
BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'

step() { echo -e "\n${BLUE}${BOLD}▶  $1${NC}"; }
ok()   { echo -e "   ${GREEN}✓  $1${NC}"; }
warn() { echo -e "   ${YELLOW}!  $1${NC}"; }
fail() {
    echo -e "   ${RED}✗  $1${NC}"
    echo -e "\n   ${RED}Installation failed. Check the log for details:${NC}"
    echo "   $LOG"
    echo ""
    read -r -p "   Press Enter to close…" _
    exit 1
}

ERRORS=0
note_error() { ERRORS=$((ERRORS + 1)); warn "$1"; }

# ── Header ────────────────────────────────────────────────────────────────────
clear
echo ""
echo -e "${BOLD}  ══════════════════════════════════════════${NC}"
echo -e "${BOLD}     📺  IPTV Manager — Installer${NC}"
echo -e "${BOLD}  ══════════════════════════════════════════${NC}"
echo ""
echo "  This installer will set up everything needed to run IPTV Manager."
echo "  You may be asked for your Mac password to install software."
echo ""
echo "  Log file: $LOG"
echo "" > "$LOG"

# ── 1. Homebrew ───────────────────────────────────────────────────────────────
step "Checking Homebrew (macOS package manager)"

# Add Homebrew to PATH for both Apple Silicon and Intel Macs
eval "$(/opt/homebrew/bin/brew shellenv 2>/dev/null)" 2>/dev/null || true
eval "$(/usr/local/bin/brew shellenv 2>/dev/null)" 2>/dev/null || true
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

if command -v brew &>/dev/null; then
    ok "Homebrew already installed ($(brew --version | head -1))"
else
    warn "Homebrew not found — installing now (this may take a few minutes)…"
    echo ""
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" \
        2>&1 | tee -a "$LOG"
    eval "$(/opt/homebrew/bin/brew shellenv 2>/dev/null)" 2>/dev/null || true
    eval "$(/usr/local/bin/brew shellenv 2>/dev/null)" 2>/dev/null || true
    if command -v brew &>/dev/null; then
        ok "Homebrew installed successfully"
    else
        fail "Homebrew installation failed. Visit https://brew.sh to install manually."
    fi
fi

# ── 2. Python 3.9+ ────────────────────────────────────────────────────────────
step "Checking Python 3.9+"

PY=""
for candidate in \
    "$(brew --prefix python@3.12 2>/dev/null)/bin/python3.12" \
    "$(brew --prefix python@3.11 2>/dev/null)/bin/python3.11" \
    "$(brew --prefix python@3.10 2>/dev/null)/bin/python3.10" \
    "$(brew --prefix python@3.9  2>/dev/null)/bin/python3.9"  \
    python3.12 python3.11 python3.10 python3.9 python3
do
    if command -v "$candidate" &>/dev/null 2>&1; then
        VER=$("$candidate" -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>/dev/null)
        MAJOR=$(echo "$VER" | cut -d. -f1)
        MINOR=$(echo "$VER" | cut -d. -f2)
        if [ "${MAJOR:-0}" -ge 3 ] && [ "${MINOR:-0}" -ge 9 ]; then
            PY="$candidate"
            break
        fi
    fi
done

if [ -z "$PY" ]; then
    warn "Python 3.9+ not found — installing Python 3.11 via Homebrew…"
    brew install python@3.11 2>&1 | tee -a "$LOG"
    PY="$(brew --prefix python@3.11)/bin/python3.11"
    if ! command -v "$PY" &>/dev/null; then
        fail "Python installation failed."
    fi
    ok "Python 3.11 installed"
else
    ok "Python found: $PY ($("$PY" --version 2>&1))"
fi

# ── 3. FFmpeg (required — used for all recording and ad detection) ─────────────
step "Checking FFmpeg + ffprobe"

if command -v ffmpeg &>/dev/null; then
    ok "FFmpeg already installed: $(ffmpeg -version 2>&1 | head -1 | cut -c1-60)"
else
    warn "FFmpeg not found — installing via Homebrew (this may take a few minutes)…"
    brew install ffmpeg 2>&1 | tee -a "$LOG"
    if command -v ffmpeg &>/dev/null; then
        ok "FFmpeg installed: $(ffmpeg -version 2>&1 | head -1 | cut -c1-60)"
    else
        fail "FFmpeg installation failed."
    fi
fi

if command -v ffprobe &>/dev/null; then
    ok "ffprobe found (needed for ad detection duration analysis)"
else
    note_error "ffprobe not found — ad detection will not work correctly"
fi

# ── 4. Python virtual environment ──────────────────────────────────────────────
step "Creating Python virtual environment"

if [ -d "$VENV" ]; then
    warn "Existing virtual environment found — recreating to ensure clean state…"
    rm -rf "$VENV"
fi

"$PY" -m venv "$VENV" >> "$LOG" 2>&1
if [ $? -ne 0 ] || [ ! -f "$VENV/bin/python3" ]; then
    fail "Failed to create virtual environment."
fi
ok "Virtual environment created at .venv/"

VENV_PY="$VENV/bin/python3"
VENV_PIP="$VENV/bin/pip"

# ── 6. Python dependencies ────────────────────────────────────────────────────
step "Installing Python dependencies"

"$VENV_PIP" install --upgrade pip setuptools wheel -q >> "$LOG" 2>&1

echo "   Installing: flask, requests, APScheduler, pytz, python-dateutil, rumps…"
"$VENV_PIP" install -r "$DIR/requirements.txt" >> "$LOG" 2>&1
if [ $? -ne 0 ]; then
    fail "Failed to install Python dependencies. Check $LOG for details."
fi
ok "All packages installed"

# Verify every required package imports correctly
ALL_OK=1
for pkg in flask requests apscheduler pytz dateutil rumps; do
    if "$VENV_PY" -c "import $pkg" 2>/dev/null; then
        ok "  $pkg ✓"
    else
        note_error "Package '$pkg' failed to import — check $LOG"
        ALL_OK=0
    fi
done

# Verify stdlib modules used by detect_ads.py
for pkg in xml.etree.ElementTree subprocess tempfile pathlib; do
    if "$VENV_PY" -c "import $pkg" 2>/dev/null; then
        ok "  $pkg (stdlib) ✓"
    else
        note_error "stdlib module '$pkg' missing — unexpected Python installation issue"
        ALL_OK=0
    fi
done

# ── 7. macOS AppKit / PyObjC ──────────────────────────────────────────────────
step "Checking macOS AppKit / PyObjC (menu bar support)"

if "$VENV_PY" -c "from AppKit import NSApplication" 2>/dev/null; then
    ok "AppKit (PyObjC) is available — menu bar app will work"
else
    warn "AppKit not available — menu bar icon will not appear"
    warn "The web UI will still work at http://localhost:5001"
fi

# ── 8. Initialise database ────────────────────────────────────────────────────
step "Initialising database"

export IPTV_DIR="$DIR"
"$VENV_PY" - >> "$LOG" 2>&1 <<PYEOF
import sys, os
sys.path.insert(0, '$DIR')
os.chdir('$DIR')
import database
database.init_db()
print("Database OK")
PYEOF

if [ $? -eq 0 ] || [ -f "$DIR/data/iptv_manager.db" ]; then
    ok "Database initialised at data/iptv_manager.db"
else
    note_error "Database initialisation may have failed — check $LOG"
fi

# ── 9. Smoke-test: verify the web server starts ───────────────────────────────
step "Testing app launch (Flask web server)"

lsof -ti:5001 | xargs kill -9 2>/dev/null || true
sleep 1

cd "$DIR"
"$VENV_PY" "$DIR/app.py" >> "$LOG" 2>&1 &
APP_PID=$!
echo "   Waiting for server to start…"

STARTED=0
for i in 1 2 3 4 5 6 7 8; do
    sleep 1
    if curl -s --max-time 2 http://localhost:5001/ -o /dev/null 2>/dev/null; then
        STARTED=1
        break
    fi
done

if [ "$STARTED" -eq 1 ]; then
    ok "Web server responded on http://localhost:5001/ ✓"
else
    note_error "Web server did not respond on port 5001 — check $LOG"
fi

kill "$APP_PID" 2>/dev/null
wait "$APP_PID" 2>/dev/null
sleep 1

# ── 10. File permissions ──────────────────────────────────────────────────────
step "Setting file permissions"

chmod +x "$DIR/Start IPTV Manager.command"   2>/dev/null && ok "'Start IPTV Manager.command' is executable"
chmod +x "$DIR/Stop IPTV Manager.command"    2>/dev/null || true
chmod +x "$DIR/Install IPTV Manager.command" 2>/dev/null || true

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}  ══════════════════════════════════════════${NC}"
if [ "$ERRORS" -eq 0 ]; then
    echo -e "${BOLD}     ${GREEN}✅  Installation complete!${NC}"
else
    echo -e "${BOLD}     ${YELLOW}⚠️   Installation finished with $ERRORS warning(s)${NC}"
fi
echo -e "${BOLD}  ══════════════════════════════════════════${NC}"
echo ""
echo "   To launch IPTV Manager:"
echo "   → Double-click  'Start IPTV Manager.command'"
echo "   → Then look for 📺 in your menu bar"
echo "   → Or open http://localhost:5001 in your browser"
echo ""
if [ "$ERRORS" -gt 0 ]; then
    echo -e "   ${YELLOW}Check the install log for details:${NC}"
    echo "   $LOG"
    echo ""
fi

read -r -p "   Press Enter to close…" _
