/* ─────────────────────────────────────────────────────────────────────────
   IPTV Manager — Frontend Application
   All times are displayed in UK time (Europe/London).
   ───────────────────────────────────────────────────────────────────────── */

const UK_LOCALE = 'en-GB';
let activeTZ    = 'Europe/London';   // updated from settings on load

function applyActiveTZ(tz) {
  activeTZ = tz === 'local' ? Intl.DateTimeFormat().resolvedOptions().timeZone : tz;
  // Show a short human-readable label: last segment of the tz id, e.g. "London", "New_York"
  const label = activeTZ.split('/').pop().replace(/_/g, ' ');
  document.querySelectorAll('.tz-label').forEach(el => el.textContent = label);
}

// ── Utilities ────────────────────────────────────────────────────────────────

function fmtUK(isoStr, opts = {}) {
  if (!isoStr) return '';
  return new Date(isoStr).toLocaleString(UK_LOCALE, { timeZone: activeTZ, ...opts });
}

function fmtTimeUK(isoStr) {
  if (!isoStr) return '';
  return new Date(isoStr).toLocaleTimeString(UK_LOCALE, {
    timeZone: activeTZ, hour: '2-digit', minute: '2-digit'
  });
}

function fmtDateTimeUK(isoStr) {
  if (!isoStr) return '';
  return new Date(isoStr).toLocaleString(UK_LOCALE, {
    timeZone: activeTZ,
    weekday: 'short', day: 'numeric', month: 'short',
    hour: '2-digit', minute: '2-digit'
  });
}

function nowUK() {
  return new Date();
}

// Convert a datetime-local input value ("YYYY-MM-DDTHH:mm") to a UTC ISO
// string, treating the input as UK time (Europe/London) regardless of the
// Mac's own timezone setting.
function localInputToISO(value) {
  if (!value) return null;
  const [datePart, timePart] = value.split('T');
  const [year, month, day]   = datePart.split('-').map(Number);
  const [hour, minute]        = (timePart || '00:00').split(':').map(Number);

  // Treat the typed value as UTC to get a reference Date object.
  const naiveUtc = new Date(Date.UTC(year, month - 1, day, hour, minute, 0));

  // Ask Intl what the UK clock reads at that UTC moment.
  // During GMT: UK shows the same time → offset = 0.
  // During BST: UK shows +1h            → offset = +60 min.
  const ukParts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/London',
    hour: 'numeric', minute: 'numeric', hour12: false
  }).formatToParts(naiveUtc);
  const p = Object.fromEntries(
    ukParts.map(({ type, value }) => [type, parseInt(value) || 0])
  );

  // diffMin > 0 means UK is ahead of UTC (e.g. +60 during BST).
  let diffMin = (p.hour * 60 + p.minute) - (hour * 60 + minute);
  if (diffMin >  720) diffMin -= 1440;
  if (diffMin < -720) diffMin += 1440;

  // Subtract the UK offset to arrive at the correct UTC instant.
  return new Date(naiveUtc.getTime() - diffMin * 60000).toISOString();
}

// Convert UK ISO back to datetime-local format
function isoToLocalInput(isoStr) {
  if (!isoStr) return '';
  const d = new Date(isoStr);
  // Format as YYYY-MM-DDTHH:mm in UK timezone
  const parts = new Intl.DateTimeFormat('sv-SE', {
    timeZone: activeTZ,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit'
  }).formatToParts(d);
  const p = Object.fromEntries(parts.map(x => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`;
}

function esc(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function toast(msg, type = 'info', duration = 3500) {
  const c = document.getElementById('toast-container');
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<span style="flex:1">${esc(msg)}</span>`;
  c.appendChild(t);
  setTimeout(() => t.remove(), duration);
}

async function api(method, path, body) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const r = await fetch(path, opts);
  if (!r.ok) {
    const e = await r.json().catch(() => ({ error: r.statusText }));
    throw new Error(e.error || r.statusText);
  }
  return r.json();
}

// ── EPG Grid ─────────────────────────────────────────────────────────────────

class EPGGrid {
  constructor() {
    this.PX_PER_MIN  = 5;      // pixels per minute
    this.ROW_H       = 52;     // px, must match CSS
    this.HOURS       = 4;      // hours of window shown
    this.channelBatch = 30;    // channels loaded at a time
    this.channelOffset = 0;

    this.channels  = [];       // all channel groups
    this.epgData   = {};       // stream_id → [programs]
    this.windowStart = null;   // Date object, start of visible window
    this._scrollHandler = null;
  }

  goToNow() {
    const now = nowUK();
    // Round down to nearest 30-min
    const mins = now.getMinutes() >= 30 ? 30 : 0;
    this.windowStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(),
                                now.getHours(), mins, 0, 0);
    this._render();
  }

  shiftTime(minutes) {
    this.windowStart = new Date(this.windowStart.getTime() + minutes * 60000);
    this._render();
  }

  async loadMore() {
    this.channelOffset += this.channelBatch;
    await this._fetchEPGBatch();
    this._render();
  }

  async init(channels) {
    this.channels = channels;
    this.channelOffset = 0;
    this.goToNow();
    await this._fetchEPGBatch();
    this._render();
  }

  async _fetchEPGBatch() {
    const visible = this.channels.slice(this.channelOffset,
                                        this.channelOffset + this.channelBatch);
    const missing = visible.filter(g => !this.epgData[g.primary_stream_id]);

    if (!missing.length) return;

    try {
      const data = await api('POST', '/api/epg/bulk', {
        channels: missing.map(g => ({
          stream_id:      g.primary_stream_id,
          epg_channel_id: g.epg_channel_id || '',
        })),
        limit: 20,
      });
      Object.assign(this.epgData, data);
    } catch (e) {
      console.warn('EPG fetch failed:', e);
    }
  }

  _render() {
    const ws = this.windowStart;
    const we = new Date(ws.getTime() + this.HOURS * 3600000);

    // Update range label
    document.getElementById('epg-time-range').textContent =
      `${fmtTimeUK(ws.toISOString())} – ${fmtTimeUK(we.toISOString())}`;

    const totalPx = this.HOURS * 60 * this.PX_PER_MIN;
    const visible = this.channels.slice(0, this.channelOffset + this.channelBatch);

    // Time header
    this._renderTimeHeader(totalPx, ws);

    // Channels & programs
    const channelInner   = document.getElementById('epg-channel-inner');
    const programsInner  = document.getElementById('epg-programs-inner');

    channelInner.innerHTML  = '';
    programsInner.innerHTML = '';
    programsInner.style.width  = totalPx + 'px';
    programsInner.style.height = (visible.length * this.ROW_H) + 'px';

    // Now-line
    const nowLine = document.createElement('div');
    nowLine.className = 'epg-now-line';
    const nowOffset = (nowUK() - ws) / 60000 * this.PX_PER_MIN;
    if (nowOffset > 0 && nowOffset < totalPx) {
      nowLine.style.left = nowOffset + 'px';
      nowLine.style.display = 'block';
    } else {
      nowLine.style.display = 'none';
    }
    programsInner.appendChild(nowLine);

    visible.forEach((group, rowIdx) => {
      this._renderChannelRow(group, rowIdx, channelInner, programsInner, ws, totalPx);
    });

    this._bindScroll();
  }

  _renderTimeHeader(totalPx, windowStart) {
    const inner = document.getElementById('epg-time-inner');
    inner.style.width = totalPx + 'px';
    inner.innerHTML = '';
    for (let m = 0; m <= this.HOURS * 60; m += 30) {
      const t = new Date(windowStart.getTime() + m * 60000);
      const mark = document.createElement('div');
      mark.className = 'epg-time-mark';
      mark.style.left = (m * this.PX_PER_MIN) + 'px';
      mark.textContent = fmtTimeUK(t.toISOString());
      inner.appendChild(mark);
    }
  }

  _renderChannelRow(group, rowIdx, channelContainer, programsContainer, windowStart, totalPx) {
    // Channel name cell
    const cell = document.createElement('div');
    cell.className = 'epg-channel-row';
    cell.innerHTML = `
      ${group.stream_icon
        ? `<img src="${esc(group.stream_icon)}" alt="" onerror="this.style.display='none'">`
        : ''}
      <span class="epg-channel-row-name" title="${esc(group.display_name)}">${esc(group.display_name)}</span>
    `;
    cell.addEventListener('click', () => app.watchChannel(group));
    channelContainer.appendChild(cell);

    // Programs row
    const row = document.createElement('div');
    row.className = 'epg-prog-row';
    row.style.top = (rowIdx * this.ROW_H) + 'px';
    row.style.position = 'absolute';
    row.style.width = totalPx + 'px';
    row.style.height = this.ROW_H + 'px';

    const programs = this.epgData[group.primary_stream_id] || [];
    const windowEnd = new Date(windowStart.getTime() + this.HOURS * 3600000);

    if (programs.length === 0) {
      const noData = document.createElement('div');
      noData.className = 'epg-no-data';
      noData.textContent = 'No EPG data';
      row.appendChild(noData);
    }

    const now = nowUK();
    programs.forEach(prog => {
      if (!prog.start || !prog.end) return;
      const ps = new Date(prog.start);
      const pe = new Date(prog.end);

      // Skip programs entirely outside the window
      if (pe <= windowStart || ps >= windowEnd) return;

      const startMin  = Math.max(0, (ps - windowStart) / 60000);
      const endMin    = Math.min(this.HOURS * 60, (pe - windowStart) / 60000);
      const durMin    = endMin - startMin;
      if (durMin <= 0) return;

      const left  = startMin * this.PX_PER_MIN;
      const width = durMin * this.PX_PER_MIN - 2;

      const el = document.createElement('div');
      el.className = 'epg-program';
      if (ps <= now && pe > now) el.classList.add('now-on');
      el.style.left  = left + 'px';
      el.style.width = Math.max(2, width) + 'px';
      el.dataset.prog = JSON.stringify({
        title: prog.title,
        description: prog.description || '',
        start: prog.start,
        end: prog.end,
        channelId: group.primary_stream_id,
        channelName: group.display_name,
        group: group,
      });

      const titleEl = document.createElement('span');
      titleEl.className = 'epg-program-title';
      titleEl.textContent = prog.title || 'Unknown';
      el.appendChild(titleEl);

      el.addEventListener('click', () => app.showProgram(el.dataset.prog));
      row.appendChild(el);
    });

    programsContainer.appendChild(row);
  }

  _bindScroll() {
    const progArea   = document.getElementById('epg-programs-area');
    const timeHeader = document.getElementById('epg-time-header');
    const chanInner  = document.getElementById('epg-channel-inner');

    // Remove previous listener before adding a new one
    if (this._scrollHandler) {
      progArea.removeEventListener('scroll', this._scrollHandler);
    }
    this._scrollHandler = () => {
      timeHeader.scrollLeft = progArea.scrollLeft;
      chanInner.style.transform = `translateY(-${progArea.scrollTop}px)`;
    };
    progArea.addEventListener('scroll', this._scrollHandler);

    // Scroll to current time minus a little bit
    const nowOffset = (nowUK() - this.windowStart) / 60000 * this.PX_PER_MIN;
    setTimeout(() => {
      progArea.scrollLeft = Math.max(0, nowOffset - 80);
    }, 50);
  }
}

// ── Main App ─────────────────────────────────────────────────────────────────

const app = (() => {
  let channels     = [];    // raw grouped channels
  let filteredChs  = [];
  let settings     = {};
  let hls          = null;
  let currentGroup = null;  // currently open channel group
  let epg          = new EPGGrid();
  let _editingRecId = null; // non-null when editing an existing recording

  // Expose epg for template calls
  const pub = { epg };

  // ── Navigation ─────────────────────────────────────────────────────────

  pub.navigateTo = function(viewName) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

    const view = document.getElementById(`view-${viewName}`);
    if (view) view.classList.add('active');

    const navItem = document.querySelector(`[data-view="${viewName}"]`);
    if (navItem) navItem.classList.add('active');

    const titles = {
      'live-tv': 'Live TV',
      'epg': 'TV Guide',
      'recordings': 'Recordings',
      'settings': 'Settings',
    };
    document.getElementById('topbar-title').textContent = titles[viewName] || '';
    document.getElementById('search-box').style.display =
      (viewName === 'live-tv') ? '' : 'none';

    if (viewName === 'epg' && channels.length) {
      _ensureXmltvLoaded();
      epg.init(channels);
    }
    if (viewName === 'recordings') {
      pub.loadRecordings();
    }
    if (viewName === 'settings') {
      pub.loadSettings();
    }
  };

  // ── Channels ───────────────────────────────────────────────────────────

  async function loadChannels() {
    try {
      channels = await api('GET', '/api/channels');
      filteredChs = channels;
      renderChannelGrid(filteredChs);
    } catch (e) {
      toast('Failed to load channels: ' + e.message, 'error');
    }
  }

  pub.refreshChannels = async function() {
    toast('Refreshing channel list…', 'info');
    try {
      const result = await api('POST', '/api/channels/refresh');
      channels = await api('GET', '/api/channels');
      filteredChs = channels;
      renderChannelGrid(filteredChs);
      toast(`Loaded ${result.count} channel groups`, 'success');
    } catch (e) {
      toast('Refresh failed: ' + e.message, 'error');
    }
  };

  pub.onSearch = function(query) {
    const q = query.toLowerCase().trim();
    filteredChs = q
      ? channels.filter(g => g.display_name.toLowerCase().includes(q))
      : channels;
    renderChannelGrid(filteredChs);
  };

  function renderChannelGrid(groups) {
    const grid  = document.getElementById('channel-grid');
    const empty = document.getElementById('channel-empty');

    if (!groups || groups.length === 0) {
      grid.innerHTML  = '';
      empty.style.display = 'flex';
      return;
    }
    empty.style.display = 'none';

    grid.innerHTML = groups.map(g => `
      <div class="channel-card" onclick='app.watchChannel(${JSON.stringify(g)})'>
        ${g.stream_icon
          ? `<img class="logo" src="${esc(g.stream_icon)}" alt="" onerror="this.style.display='none'">`
          : `<div class="logo-placeholder">📺</div>`}
        <div class="channel-name">${esc(g.display_name)}</div>
        <div class="now-playing" id="now-${g.primary_stream_id}">Loading…</div>
        ${g.has_multiple ? `<span class="variant-badge">+${g.variants.length}</span>` : ''}
      </div>
    `).join('');

    // Lazy-load EPG for "now playing" labels in batches
    loadNowPlaying(groups.slice(0, 40));
  }

  async function loadNowPlaying(groups) {
    try {
      const data = await api('POST', '/api/epg/bulk', {
        channels: groups.map(g => ({
          stream_id:      g.primary_stream_id,
          epg_channel_id: g.epg_channel_id || '',
        })),
        limit: 5,
      });
      const now = nowUK();
      groups.forEach(g => {
        const el = document.getElementById(`now-${g.primary_stream_id}`);
        if (!el) return;
        const progs = data[g.primary_stream_id] || [];
        const current = progs.find(p => p.start && p.end &&
          new Date(p.start) <= now && new Date(p.end) > now);
        el.textContent = current ? current.title : '';
      });
    } catch (e) {
      // EPG optional — silently ignore
    }
  }

  // ── Player ─────────────────────────────────────────────────────────────

  pub.watchChannel = function(group) {
    if (typeof group === 'string') group = JSON.parse(group);
    currentGroup = group;

    document.getElementById('player-channel-name').textContent = group.display_name;
    document.getElementById('player-now-playing').textContent = '';

    // Variant dropdown
    const sel = document.getElementById('player-variant-select');
    if (group.variants && group.variants.length > 1) {
      sel.innerHTML = group.variants.map(v =>
        `<option value="${v.stream_id}">${esc(v.name)} (${v.quality})</option>`
      ).join('');
      sel.style.display = '';
    } else {
      sel.style.display = 'none';
    }

    document.getElementById('player-modal').classList.add('open');
    document.getElementById('player-loading').style.display = 'flex';

    _loadStream(group.primary_stream_id);
    _loadNowPlayingForPlayer(group.primary_stream_id);
  };

  pub.switchVariant = function(streamId) {
    document.getElementById('player-loading').style.display = 'flex';
    _loadStream(parseInt(streamId));
  };

  function _loadStream(streamId) {
    const video = document.getElementById('video-player');

    if (hls) {
      hls.destroy();
      hls = null;
    }

    const proxyUrl = `/api/hls/${streamId}.m3u8`;

    if (Hls.isSupported()) {
      hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
      });
      hls.loadSource(proxyUrl);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        document.getElementById('player-loading').style.display = 'none';
        document.getElementById('player-stream-type').textContent = 'HLS stream';
        video.play().catch(() => {});
      });
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) {
          document.getElementById('player-loading').innerHTML =
            `<span style="color:var(--rec)">Stream error — try a different quality variant</span>`;
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Safari native HLS
      video.src = proxyUrl;
      video.addEventListener('loadeddata', () => {
        document.getElementById('player-loading').style.display = 'none';
      }, { once: true });
      video.play().catch(() => {});
    } else {
      document.getElementById('player-loading').innerHTML =
        `<span>HLS not supported in this browser.</span>`;
    }
  }

  async function _loadNowPlayingForPlayer(streamId) {
    try {
      const progs = await api('GET', `/api/epg/${streamId}?limit=5`);
      const now = nowUK();
      const current = progs.find(p =>
        p.start && p.end && new Date(p.start) <= now && new Date(p.end) > now
      );
      if (current) {
        document.getElementById('player-now-playing').textContent =
          `${fmtTimeUK(current.start)}–${fmtTimeUK(current.end)}  ${current.title}`;
      }
    } catch (e) {}
  }

  pub.closePlayer = function() {
    document.getElementById('player-modal').classList.remove('open');
    const video = document.getElementById('video-player');
    video.pause();
    if (hls) { hls.destroy(); hls = null; }
    video.src = '';
  };

  pub.recordFromPlayer = function() {
    if (!currentGroup) return;
    pub.closePlayer();
    pub.openScheduleModal(currentGroup);
  };

  // ── EPG program detail ──────────────────────────────────────────────────

  let _currentProg = null;

  pub.showProgram = function(dataStr) {
    _currentProg = JSON.parse(dataStr);
    const { title, description, start, end } = _currentProg;

    document.getElementById('prog-time').textContent =
      `${fmtDateTimeUK(start)} – ${fmtTimeUK(end)}`;
    document.getElementById('prog-title').textContent  = title || '';
    document.getElementById('prog-desc').textContent   = description || 'No description available.';

    document.getElementById('prog-modal').classList.add('open');
  };

  pub.showProgramDetails = pub.showProgram; // alias for template

  pub.closeProgModal = function() {
    document.getElementById('prog-modal').classList.remove('open');
    _currentProg = null;
  };

  pub.watchFromEPG = function() {
    if (!_currentProg) return;
    pub.closeProgModal();
    const g = typeof _currentProg.group === 'string'
      ? JSON.parse(_currentProg.group) : _currentProg.group;
    pub.watchChannel(g || { primary_stream_id: _currentProg.channelId,
                             display_name: _currentProg.channelName,
                             variants: [], has_multiple: false });
  };

  pub.recordFromEPG = function() {
    if (!_currentProg) return;
    const g = typeof _currentProg.group === 'string'
      ? JSON.parse(_currentProg.group) : _currentProg.group;
    pub.closeProgModal();
    pub.openScheduleModal(g, _currentProg);
  };

  // ── Schedule recording modal ────────────────────────────────────────────

  let _recCategoryFilter = '';
  let _recSearchFilter   = '';

  function _getCategories() {
    return [...new Set(channels.map(g => g.group_title).filter(Boolean))].sort();
  }

  function _filteredChannels() {
    return channels.filter(g => {
      const catOk   = !_recCategoryFilter || g.group_title === _recCategoryFilter;
      const nameOk  = !_recSearchFilter   ||
                      g.display_name.toLowerCase().includes(_recSearchFilter.toLowerCase());
      return catOk && nameOk;
    });
  }

  function _renderRecChannelOptions(selectedId) {
    const sel = document.getElementById('rec-channel');
    const filtered = _filteredChannels();
    sel.innerHTML = '<option value="">— select channel —</option>' +
      filtered.map(g =>
        `<option value="${g.primary_stream_id}"` +
        (g.primary_stream_id == selectedId ? ' selected' : '') +
        ` data-group='${JSON.stringify(g).replace(/'/g, "&#39;")}'>${esc(g.display_name)}</option>`
      ).join('');
    if (selectedId) pub.onRecChannelChange();
  }

  pub.onRecCategoryChange = function() {
    _recCategoryFilter = document.getElementById('rec-category').value;
    _renderRecChannelOptions(null);
  };

  pub.onRecChannelSearch = function(query) {
    _recSearchFilter = query;
    _renderRecChannelOptions(null);
  };

  pub.openScheduleModal = function(group, prog) {
    // Reset edit state — this is a new recording
    _editingRecId = null;
    document.getElementById('schedule-modal-title').textContent = 'Schedule Recording';

    // Populate category dropdown
    const catSel = document.getElementById('rec-category');
    catSel.innerHTML = '<option value="">All categories</option>' +
      _getCategories().map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join('');

    // Reset filters, then optionally pre-select the category of the provided group
    _recSearchFilter = '';
    document.getElementById('rec-channel-search').value = '';
    _recCategoryFilter = (group && group.group_title) ? group.group_title : '';
    catSel.value = _recCategoryFilter;

    // Populate the channel list (pre-selecting the channel if a group was passed)
    _renderRecChannelOptions(group ? group.primary_stream_id : null);

    // Pre-fill from group if provided
    if (group) {
      pub.onRecChannelChange();
    }

    // Pre-fill times from program if provided
    if (prog) {
      if (prog.start) document.getElementById('rec-start').value = isoToLocalInput(prog.start);
      if (prog.end)   document.getElementById('rec-end').value   = isoToLocalInput(prog.end);
      if (prog.title) document.getElementById('rec-show-name').value = prog.title;
    } else {
      // Default: now + 1h
      const now = new Date();
      const end = new Date(now.getTime() + 3600000);
      document.getElementById('rec-start').value = isoToLocalInput(now.toISOString());
      document.getElementById('rec-end').value   = isoToLocalInput(end.toISOString());
    }

    // Default save path and clear numbering fields
    document.getElementById('rec-save-path').value  = settings.default_save_path || '';
    document.getElementById('rec-season').value     = '';
    document.getElementById('rec-episode').value    = '';
    document.getElementById('rec-pad-start').value  = 0;
    document.getElementById('rec-pad-end').value    = 0;

    document.getElementById('schedule-modal').classList.add('open');
  };

  pub.closeScheduleModal = function() {
    document.getElementById('schedule-modal').classList.remove('open');
  };

  pub.onRecChannelChange = function() {
    const sel = document.getElementById('rec-channel');
    const opt = sel.selectedOptions[0];
    if (!opt || !opt.dataset.group) {
      document.getElementById('rec-variant-row').style.display = 'none';
      return;
    }
    const g = JSON.parse(opt.dataset.group.replace(/&#39;/g, "'"));
    const varSel = document.getElementById('rec-variant');
    if (g.variants && g.variants.length > 1) {
      varSel.innerHTML = g.variants.map(v =>
        `<option value="${v.stream_id}">${esc(v.name)} (${v.quality})</option>`
      ).join('');
      document.getElementById('rec-variant-row').style.display = '';
    } else {
      document.getElementById('rec-variant-row').style.display = 'none';
    }
  };

  pub.onRecurrenceChange = function() {
    const v = document.getElementById('rec-recurrence').value;
    document.getElementById('rec-recurrence-detail').style.display = v ? '' : 'none';
  };

  pub.submitRecording = async function() {
    const chanSel = document.getElementById('rec-channel');
    const varSel  = document.getElementById('rec-variant');

    // Use variant stream ID if visible, otherwise primary
    const varRow = document.getElementById('rec-variant-row');
    const channelId = (varRow.style.display !== 'none' && varSel.value)
      ? varSel.value
      : chanSel.value;

    const channelName = chanSel.selectedOptions[0]?.text || '';
    const showName    = document.getElementById('rec-show-name').value.trim();
    const savePath    = document.getElementById('rec-save-path').value.trim();
    const recurrence  = document.getElementById('rec-recurrence').value;

    if (!channelId)  { toast('Please select a channel', 'error'); return; }
    if (!showName)   { toast('Please enter a show name', 'error'); return; }
    if (!savePath)   { toast('Please enter a save path', 'error'); return; }

    // Quality overrides
    const codec      = document.getElementById('rec-codec').value;
    const resolution = document.getElementById('rec-resolution').value;
    const quality    = {};
    if (codec)      quality.codec      = codec;
    if (resolution) quality.resolution = resolution;

    const padStart = parseInt(document.getElementById('rec-pad-start').value) || 0;
    const padEnd   = parseInt(document.getElementById('rec-pad-end').value)   || 0;

    let body = {
      channel_id:    channelId,
      channel_name:  channelName.replace(/\s*\(.*\)$/, ''),
      show_name:     showName,
      season:        parseInt(document.getElementById('rec-season').value)  || 0,
      episode:       parseInt(document.getElementById('rec-episode').value) || 0,
      save_path:     savePath,
      quality:       Object.keys(quality).length ? quality : null,
      padding_start: padStart,
      padding_end:   padEnd,
    };

    if (recurrence) {
      // Recurring recording
      const time = document.getElementById('rec-recurrence-time').value;
      const dow  = parseInt(document.getElementById('rec-dow').value);
      const dur  = parseInt(document.getElementById('rec-duration').value) || 60;

      // Compute start/end based on today at the given time (used as template)
      const now = new Date();
      const startISO = isoToLocalInput(now.toISOString()).split('T')[0] + 'T' + time;
      const startDt  = new Date(startISO);
      const endDt    = new Date(startDt.getTime() + dur * 60000);

      body.start_time  = startDt.toISOString();
      body.end_time    = endDt.toISOString();
      body.type        = 'recurring';
      body.recurrence  = {
        pattern:     recurrence,
        day_of_week: dow,
        time:        time,
        duration:    dur,
      };
    } else {
      const startVal = document.getElementById('rec-start').value;
      const endVal   = document.getElementById('rec-end').value;
      if (!startVal || !endVal) { toast('Please set start and end times', 'error'); return; }
      body.start_time = localInputToISO(startVal);
      body.end_time   = localInputToISO(endVal);
      body.type       = 'once';
    }

    try {
      if (_editingRecId) {
        await api('PUT', `/api/recordings/${_editingRecId}`, body);
        toast('Recording updated!', 'success');
      } else {
        await api('POST', '/api/recordings', body);
        toast('Recording scheduled!', 'success');
      }
      _editingRecId = null;
      pub.closeScheduleModal();
      pub.loadRecordings();
    } catch (e) {
      toast('Failed: ' + e.message, 'error');
    }
  };

  // ── XMLTV EPG ──────────────────────────────────────────────────────────

  let _xmltvLoading = false;

  async function _ensureXmltvLoaded() {
    if (_xmltvLoading) return;
    try {
      const status = await api('GET', '/api/epg/xmltv/status');
      _updateEpgStatus(status);
      if (!status.loaded) {
        pub.refreshXmltv();
      }
    } catch (e) {
      // Non-fatal — EPG will fall back to JSON API
    }
  }

  pub.refreshXmltv = async function() {
    if (_xmltvLoading) return;
    _xmltvLoading = true;
    const btn = document.getElementById('epg-refresh-btn');
    const lbl = document.getElementById('epg-status-label');
    if (btn) btn.disabled = true;
    if (lbl) lbl.textContent = 'Loading EPG data…';

    try {
      const result = await api('POST', '/api/epg/xmltv/refresh');
      if (lbl) lbl.textContent = `EPG loaded — ${result.channels} channels`;
      // Clear cached EPG so the grid re-fetches with XMLTV data
      epg.epgData = {};
      epg._render();
    } catch (e) {
      if (lbl) lbl.textContent = 'EPG load failed';
      toast('EPG refresh failed: ' + e.message, 'error');
    } finally {
      _xmltvLoading = false;
      if (btn) btn.disabled = false;
    }
  };

  function _updateEpgStatus(status) {
    const lbl = document.getElementById('epg-status-label');
    if (!lbl) return;
    if (status.loaded) {
      const when = status.last_fetch
        ? fmtUK(status.last_fetch, { hour: '2-digit', minute: '2-digit' })
        : '';
      lbl.textContent = `EPG loaded — ${status.channels} channels${when ? ' · ' + when : ''}`;
    } else {
      lbl.textContent = 'EPG not loaded';
    }
  }

  // ── Recordings list ─────────────────────────────────────────────────────

  pub.loadRecordings = async function() {
    try {
      const recs = await api('GET', '/api/recordings');
      renderRecordings(recs);
    } catch (e) {
      toast('Failed to load recordings: ' + e.message, 'error');
    }
  };

  function renderRecordings(recs) {
    const list  = document.getElementById('recordings-list');
    const empty = document.getElementById('recordings-empty');

    if (!recs || recs.length === 0) {
      list.innerHTML = '';
      empty.style.display = 'flex';
      return;
    }
    empty.style.display = 'none';

    // Group: active/recording first, then upcoming, then recurring, then done
    const order = { recording: 0, scheduled: 1, recurring: 2, completed: 3, failed: 4, cancelled: 5 };
    recs.sort((a, b) => (order[a.status] ?? 9) - (order[b.status] ?? 9) ||
                         new Date(a.start_time) - new Date(b.start_time));

    list.innerHTML = recs.map(r => {
      const s = parseInt(r.season)  || 0;
      const e = parseInt(r.episode) || 0;
      const epLabel = s && e ? `S${String(s).padStart(2,'0')}E${String(e).padStart(2,'0')}`
                    : e      ? `E${String(e).padStart(2,'0')}`
                    : '';
      const timeStr = r.status === 'recurring'
        ? _recurrenceLabel(r.recurrence)
        : `${fmtDateTimeUK(r.start_time)} → ${fmtTimeUK(r.end_time)}`;

      const q = r.quality || {};
      const qualLabel = q.codec ? `${q.codec.toUpperCase()} ${q.resolution || ''}`.trim() : '';

      const ps = parseInt(r.padding_start) || 0;
      const pe = parseInt(r.padding_end)   || 0;
      const padLabel = (ps || pe)
        ? (ps && pe ? `+${ps}m / +${pe}m` : ps ? `+${ps}m early` : `+${pe}m late`)
        : '';

      return `
        <div class="recording-item">
          <div class="rec-status ${r.status}" title="${r.status}"></div>
          <div class="rec-info">
            <div class="rec-title">${esc(r.show_name)}${epLabel ? ` — ${epLabel}` : ''}</div>
            <div class="rec-meta">
              ${esc(r.channel_name)} &nbsp;·&nbsp; ${esc(timeStr)}
              ${qualLabel ? `&nbsp;·&nbsp; <span class="badge badge-hevc">${esc(qualLabel)}</span>` : ''}
              ${padLabel  ? `&nbsp;·&nbsp; <span class="badge" style="background:#2a3a2a;color:#8bc34a;" title="Padding: starts ${ps}m early, ends ${pe}m late">⏱ ${esc(padLabel)}</span>` : ''}
              ${r.output_file ? `<br><span style="color:var(--text-dim);font-size:10px;">${esc(r.output_file)}</span>` : ''}
            </div>
          </div>
          <div class="rec-actions">
            ${r.status === 'recording'
              ? `<button class="btn btn-danger btn-sm" onclick="app.stopRecording('${r.id}')">Stop</button>`
              : ''}
            ${r.status === 'scheduled' || r.status === 'recurring'
              ? `<button class="btn btn-ghost btn-sm" onclick="app.editRecording('${r.id}')">Edit</button>`
              : ''}
            <button class="btn btn-ghost btn-sm" onclick="app.deleteRecording('${r.id}', ${JSON.stringify(r.show_name).replace(/"/g, '&quot;')})">Delete</button>
          </div>
        </div>
      `;
    }).join('');
  }

  function _recurrenceLabel(rec) {
    if (!rec) return '';
    const patterns = {
      daily: 'Every day',
      weekly: `Every ${['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][rec.day_of_week] || ''}`,
      weekdays: 'Weekdays',
      weekends: 'Weekends',
    };
    return `${patterns[rec.pattern] || rec.pattern} at ${rec.time} (${rec.duration || '?'} min)`;
  }

  pub.stopRecording = async function(id) {
    try {
      await api('POST', `/api/recordings/${id}/stop`);
      toast('Recording stopped', 'info');
      pub.loadRecordings();
    } catch (e) {
      toast('Error: ' + e.message, 'error');
    }
  };

  pub.deleteRecording = async function(id, name) {
    if (!confirm(`Delete recording "${name}"?`)) return;
    try {
      await api('DELETE', `/api/recordings/${id}`);
      toast('Recording deleted', 'info');
      pub.loadRecordings();
    } catch (e) {
      toast('Error: ' + e.message, 'error');
    }
  };

  pub.editRecording = async function(id) {
    let rec;
    try {
      rec = await api('GET', `/api/recordings/${id}`);
    } catch (e) {
      toast('Failed to load recording: ' + e.message, 'error');
      return;
    }

    // Find the channel group so we can pre-select its category
    const matchedGroup = channels.find(g =>
      g.primary_stream_id == rec.channel_id ||
      (g.variants && g.variants.some(v => v.stream_id == rec.channel_id))
    );

    // Populate category dropdown
    const catSel = document.getElementById('rec-category');
    catSel.innerHTML = '<option value="">All categories</option>' +
      _getCategories().map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join('');

    // Reset search, set category to matched group's category
    _recSearchFilter = '';
    document.getElementById('rec-channel-search').value = '';
    _recCategoryFilter = matchedGroup ? (matchedGroup.group_title || '') : '';
    catSel.value = _recCategoryFilter;

    // Populate channel list and pre-select the channel
    _renderRecChannelOptions(rec.channel_id);

    // Try to select the specific variant if different from primary
    const varSel = document.getElementById('rec-variant');
    const varRow = document.getElementById('rec-variant-row');
    if (varRow.style.display !== 'none' && varSel.querySelector(`option[value="${rec.channel_id}"]`)) {
      varSel.value = rec.channel_id;
    }

    // File naming fields
    document.getElementById('rec-show-name').value = rec.show_name || '';
    document.getElementById('rec-season').value    = rec.season  || '';
    document.getElementById('rec-episode').value   = rec.episode || '';
    document.getElementById('rec-save-path').value = rec.save_path || '';

    // Padding
    document.getElementById('rec-pad-start').value = rec.padding_start ?? 0;
    document.getElementById('rec-pad-end').value   = rec.padding_end   ?? 0;

    // Quality overrides
    const q = rec.quality || {};
    document.getElementById('rec-codec').value      = q.codec      || '';
    document.getElementById('rec-resolution').value = q.resolution || '';

    // Recurrence
    const recEl = document.getElementById('rec-recurrence');
    if (rec.recurrence) {
      recEl.value = rec.recurrence.pattern || '';
      pub.onRecurrenceChange();
      document.getElementById('rec-recurrence-time').value = rec.recurrence.time || '21:00';
      document.getElementById('rec-dow').value             = rec.recurrence.day_of_week ?? 0;
      document.getElementById('rec-duration').value        = rec.recurrence.duration    ?? 60;
    } else {
      recEl.value = '';
      pub.onRecurrenceChange();
      document.getElementById('rec-start').value = isoToLocalInput(rec.start_time);
      document.getElementById('rec-end').value   = isoToLocalInput(rec.end_time);
    }

    // Switch modal to edit mode
    _editingRecId = id;
    document.getElementById('schedule-modal-title').textContent = 'Edit Recording';
    document.getElementById('schedule-modal').classList.add('open');
  };

  // ── Settings ───────────────────────────────────────────────────────────

  pub.loadSettings = async function() {
    try {
      settings = await api('GET', '/api/settings');
      document.getElementById('s-host').value      = settings.xtream_host || '';
      document.getElementById('s-username').value  = settings.xtream_username || '';
      document.getElementById('s-save-path').value = settings.default_save_path || '';
      const q = settings.default_quality || {};
      document.getElementById('s-codec').value      = q.codec || 'hevc';
      document.getElementById('s-resolution').value = q.resolution || '1920x1080';
      document.getElementById('s-crf').value        = q.crf ?? 18;
      document.getElementById('s-preset').value     = q.preset || 'medium';

      const tz = settings.timezone || 'Europe/London';
      document.getElementById('s-timezone').value = tz;
      applyActiveTZ(tz);
    } catch (e) {
      toast('Failed to load settings', 'error');
    }
  };

  pub.saveSettings = async function() {
    const tz = document.getElementById('s-timezone').value;
    const body = {
      xtream_host:     document.getElementById('s-host').value.trim(),
      xtream_username: document.getElementById('s-username').value.trim(),
      default_save_path: document.getElementById('s-save-path').value.trim(),
      default_quality: {
        codec:      document.getElementById('s-codec').value,
        resolution: document.getElementById('s-resolution').value,
        crf:        parseInt(document.getElementById('s-crf').value) || 18,
        preset:     document.getElementById('s-preset').value,
        audio_codec: 'aac',
      },
      timezone: tz,
    };
    applyActiveTZ(tz);
    const pwd = document.getElementById('s-password').value;
    if (pwd) body.xtream_password = pwd;

    try {
      await api('POST', '/api/settings', body);
      settings = { ...settings, ...body };
      toast('Settings saved', 'success');
      // Refresh channels with new credentials
      if (body.xtream_host) loadChannels();
    } catch (e) {
      toast('Failed to save: ' + e.message, 'error');
    }
  };

  pub.factoryReset = async function() {
    if (!confirm(
      'Factory Reset will delete ALL settings, credentials, and scheduled recordings.\n\n' +
      'The installer will then re-open to set everything up from scratch.\n\n' +
      'This cannot be undone. Continue?'
    )) return;

    try {
      await api('POST', '/api/factory-reset');
      toast('Reset complete — launching installer…', 'info', 5000);

      // Clear all local state
      channels = []; filteredChs = []; settings = {};
      epg.epgData = {};

      // Brief pause, then open the installer via the backend
      setTimeout(() => {
        window.location.href = '/api/launch-installer';
      }, 1500);
    } catch (e) {
      toast('Reset failed: ' + e.message, 'error');
    }
  };

  pub.testConnection = async function() {
    const result = document.getElementById('connection-result');
    result.textContent = 'Testing…';
    result.style.color = 'var(--text-dim)';

    const body = {
      host:     document.getElementById('s-host').value.trim(),
      username: document.getElementById('s-username').value.trim(),
      password: document.getElementById('s-password').value ||
                (settings.xtream_password_set ? '(stored)' : ''),
    };

    try {
      const r = await api('POST', '/api/settings/test', body);
      if (r.ok) {
        result.style.color = 'var(--success)';
        const d = r.detail || {};
        result.textContent =
          `Connected! Status: ${d.status}, Expires: ${d.expiry || 'N/A'}, ` +
          `Connections: ${d.active_connections}/${d.max_connections}`;
      } else {
        result.style.color = 'var(--rec)';
        result.textContent = 'Failed: ' + (r.detail || 'Unknown error');
      }
    } catch (e) {
      result.style.color = 'var(--rec)';
      result.textContent = 'Error: ' + e.message;
    }
  };

  // ── Setup Wizard ─────────────────────────────────────────────────────────

  pub.wizard = {
    show() {
      document.getElementById('wizard-overlay').classList.remove('hidden');
      this.go(0);
    },

    hide() {
      document.getElementById('wizard-overlay').classList.add('hidden');
    },

    go(step) {
      document.querySelectorAll('.wz-dot').forEach((d, i) => {
        d.classList.toggle('active', i <= step);
      });
      document.querySelectorAll('.wz-panel').forEach((p, i) => {
        p.classList.toggle('active', parseInt(p.dataset.panel) === step);
      });
    },

    async testConnection() {
      const host = document.getElementById('wz-host').value.trim();
      const user = document.getElementById('wz-username').value.trim();
      const pass = document.getElementById('wz-password').value.trim();
      const el   = document.getElementById('wz-test-result');
      el.textContent = 'Testing…';
      el.style.color = 'var(--text-dim)';
      try {
        const res  = await fetch('/api/settings/test', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ host, username: user, password: pass }),
        });
        const data = await res.json();
        if (data.ok) {
          el.textContent = '✓ Connected — ' + (data.detail?.status || 'active');
          el.style.color = 'var(--success)';
        } else {
          el.textContent = '✗ ' + (data.detail || 'Connection failed');
          el.style.color = 'var(--accent2)';
        }
      } catch (e) {
        el.textContent = '✗ ' + e.message;
        el.style.color = 'var(--accent2)';
      }
    },

    async finish() {
      const host     = document.getElementById('wz-host').value.trim();
      const user     = document.getElementById('wz-username').value.trim();
      const pass     = document.getElementById('wz-password').value.trim();
      const savePath = document.getElementById('wz-save-path').value.trim();
      const codec    = document.getElementById('wz-codec').value;
      const res      = document.getElementById('wz-resolution').value;

      if (!host || !user || !pass) {
        toast('Please fill in your IPTV server details first.', 'error');
        this.go(1);
        return;
      }

      try {
        await api('POST', '/api/settings', {
          xtream_host:      host,
          xtream_username:  user,
          xtream_password:  pass,
          default_save_path: savePath,
          default_quality:  { codec, resolution: res, crf: 18, preset: 'medium', audio_codec: 'aac' },
          setup_complete:   '1',
        });
        settings.setup_complete = '1';
        this.go(3);
        loadChannels();
      } catch (e) {
        toast('Failed to save settings: ' + e.message, 'error');
      }
    },

    done() {
      this.hide();
      pub.loadSettings();
      const _initView = new URLSearchParams(window.location.search).get('view');
      if (_initView) pub.navigateTo(_initView);
    },
  };

  pub.loadChannels = loadChannels;

  // ── Update check ──────────────────────────────────────────────────────

  let _updateInfo = null;

  async function checkForUpdate() {
    try {
      const info = await api('GET', '/api/update/check');
      if (info.update_available) {
        _updateInfo = info;
        document.getElementById('update-banner-msg').textContent =
          `Current version: ${info.current_version} - Available version: ${info.latest_version}`;
        document.getElementById('update-banner').style.display = '';
      }
    } catch (e) {
      // Non-critical — fail silently
    }
  }

  pub.downloadUpdate = async function() {
    if (!_updateInfo || !_updateInfo.download_url) return;
    const btn = document.getElementById('update-install-btn');
    btn.disabled = true;
    btn.textContent = 'Downloading…';
    try {
      const result = await api('POST', '/api/update/download', {
        download_url: _updateInfo.download_url,
        filename:     _updateInfo.filename,
      });
      btn.textContent = 'Downloaded';
      document.getElementById('update-banner-msg').textContent =
        `IPTV Manager ${_updateInfo.latest_version} has been saved to your Downloads folder. ` +
        `Extract the ZIP and drag the files into your current IPTV Manager folder to overwrite them ` +
        `(don\u2019t delete the existing folder first).`;
      document.getElementById('update-banner-actions').style.display = 'none';

      if (_updateInfo.is_major_update) {
        const title = document.getElementById('donate-modal-title');
        const msg   = document.getElementById('donate-modal-msg');
        title.textContent = `Thanks for upgrading to v${_updateInfo.latest_version}!`;
        msg.innerHTML =
          `This is a major new release. If IPTV Manager has been useful,<br>` +
          `a small donation helps fund continued development.`;
        document.getElementById('donate-modal').classList.add('open');
      }
    } catch (e) {
      btn.disabled = false;
      btn.textContent = 'Download Update';
      toast('Download failed: ' + e.message, 'error', 6000);
    }
  };

  // ── Donate ────────────────────────────────────────────────────────────

  pub.openDonate = function() {
    document.getElementById('donate-modal-title').textContent = 'Support IPTV Manager';
    document.getElementById('donate-modal-msg').innerHTML =
      'IPTV Manager is sold for a small one-off payment. If you find it useful,<br>a small donation helps keep it going.';
    document.getElementById('donate-modal').classList.add('open');
  };

  pub.closeDonate = function() {
    document.getElementById('donate-modal').classList.remove('open');
  };

  pub.submitDonate = function() {
    document.getElementById('donate-form').submit();
    pub.closeDonate();
  };

  // ── Init ───────────────────────────────────────────────────────────────

  async function init() {
    // Close modals on backdrop click
    document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
      backdrop.addEventListener('click', e => {
        if (e.target === backdrop) {
          backdrop.classList.remove('open');
          if (backdrop.id === 'player-modal') pub.closePlayer();
          if (backdrop.id === 'donate-modal') pub.closeDonate();
        }
      });
    });

    // Nav click handlers
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', () => pub.navigateTo(item.dataset.view));
    });

    // Load settings first so we can check setup_complete
    await pub.loadSettings();

    // Show wizard if setup not complete and no existing credentials
    if (!settings.setup_complete && !settings.xtream_host) {
      pub.wizard.show();
    } else {
      loadChannels();
      checkForUpdate();
      // Support ?view=settings (or other view) from menubar "Open Settings" link
      const _initView = new URLSearchParams(window.location.search).get('view');
      if (_initView) pub.navigateTo(_initView);
    }

    // Auto-refresh recordings status every 30s
    setInterval(() => {
      const recView = document.getElementById('view-recordings');
      if (recView && recView.classList.contains('active')) {
        pub.loadRecordings();
      }
    }, 30000);
  }

  init();
  return pub;
})();
