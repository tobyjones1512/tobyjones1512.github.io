@echo off
setlocal

set "DIR=%~dp0"
set "DIR=%DIR:~0,-1%"

REM Ensure trial flag is present
if not exist "%DIR%\data" mkdir "%DIR%\data"
echo.> "%DIR%\data\trial.flag"

REM Launch the standard start script
call "%DIR%\Start IPTV Manager.bat"
