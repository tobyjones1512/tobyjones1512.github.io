#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# Start IPTV Manager - Trial Version
# Ensures trial mode is active, then launches the app.
# ─────────────────────────────────────────────────────────────────────────────

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Ensure trial flag is present
mkdir -p "$DIR/data"
touch "$DIR/data/trial.flag"

# Launch the standard start script
bash "$DIR/Start IPTV Manager.command"
