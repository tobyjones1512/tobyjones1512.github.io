#!/usr/bin/env python3
"""
IPTV Manager — XTream Codes web UI for macOS.

Run:  python app.py
Then open:  http://localhost:5001
"""
import logging
import os
import threading
import uuid
import webbrowser
from datetime import datetime, timedelta

import pytz
import requests
from dateutil import parser as dateutil_parser
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.date import DateTrigger
from flask import Flask, jsonify, render_template, request, Response

import database as db
import recorder
from channel_groups import group_channels
from xtream import XtreamClient, load_channel_cache, save_channel_cache, clear_channel_cache

# ─── Version ──────────────────────────────────────────────────────────────────

UPDATE_CSV_URL = "https://tobyjones.ca/software/downloads/iptv-manager-versions.csv"


def _read_version() -> str:
    try:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "version.txt")
        return open(p).read().strip()
    except Exception:
        return "0.0.0"


def _parse_version(v: str) -> tuple:
    try:
        return tuple(int(x) for x in v.strip().split("."))
    except Exception:
        return (0,)


APP_VERSION = _read_version()


# ─── Setup ────────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

UK_TZ = pytz.timezone("Europe/London")
UTC = pytz.utc

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False

scheduler = BackgroundScheduler(timezone="Europe/London")

# Global XTream client (refreshed when settings change)
_xtream_lock = threading.Lock()
_xtream_client = None

# In-memory channel groups cache
_channel_groups_cache = None
_channel_groups_lock = threading.Lock()

# XMLTV EPG cache  {epg_channel_id: [entry, ...]}
_xmltv_cache: dict = {}
_xmltv_cache_lock = threading.Lock()
_xmltv_last_fetch = None   # datetime or None


# ─── XTream client management ────────────────────────────────────────────────

def get_xtream_client():
    global _xtream_client
    with _xtream_lock:
        if _xtream_client:
            return _xtream_client
        settings = db.get_settings()
        host = settings.get("xtream_host", "")
        user = settings.get("xtream_username", "")
        pwd = settings.get("xtream_password", "")
        if host and user and pwd:
            _xtream_client = XtreamClient(host, user, pwd)
        return _xtream_client


def refresh_xtream_client():
    global _xtream_client
    with _xtream_lock:
        settings = db.get_settings()
        host = settings.get("xtream_host", "")
        user = settings.get("xtream_username", "")
        pwd = settings.get("xtream_password", "")
        if host and user and pwd:
            _xtream_client = XtreamClient(host, user, pwd)
        else:
            _xtream_client = None


def get_channel_groups(force_refresh: bool = False):
    global _channel_groups_cache
    with _channel_groups_lock:
        if _channel_groups_cache and not force_refresh:
            return _channel_groups_cache

        client = get_xtream_client()
        if not client:
            return []

        try:
            channels = client.get_live_streams()
            groups = group_channels(channels)
            _channel_groups_cache = [g.to_dict() for g in groups]
            save_channel_cache(_channel_groups_cache)
            return _channel_groups_cache
        except Exception as e:
            logger.error(f"Channel refresh failed: {e}")
            # Fall back to disk cache
            cached = load_channel_cache()
            if cached:
                _channel_groups_cache = cached
                return cached
            return []


# ─── Recording scheduler jobs ─────────────────────────────────────────────────

def _do_recording(rec_id: str):
    """APScheduler job: start the FFmpeg process for a scheduled recording."""
    rec = db.get_recording(rec_id)
    if not rec:
        logger.warning(f"Recording {rec_id} not found in DB")
        return

    if rec["status"] not in ("scheduled", "recurring"):
        logger.info(f"Recording {rec_id} status={rec['status']}, skipping")
        return

    client = get_xtream_client()
    if not client:
        logger.error("No XTream client — cannot start recording")
        db.update_recording_status(rec_id, "failed")
        return

    # Determine stream ID: use primary or a specific variant
    channel_id = rec.get("channel_id")
    if not channel_id:
        logger.error(f"Recording {rec_id} has no channel_id")
        db.update_recording_status(rec_id, "failed")
        return

    stream_url = client.get_stream_url(int(channel_id))

    # Calculate duration, including any padding
    padding_start = int(rec.get("padding_start") or 0)
    padding_end   = int(rec.get("padding_end")   or 0)
    start_str = rec["start_time"]
    end_str   = rec["end_time"]
    try:
        start_dt = dateutil_parser.parse(start_str)
        end_dt   = dateutil_parser.parse(end_str)
        # padding_start is already baked into the trigger time (job fires early),
        # so total duration = programme duration + both padding values
        duration_secs = int((end_dt - start_dt).total_seconds())
        duration_secs += (padding_start + padding_end) * 60
    except Exception:
        duration_secs = None

    # Resolve output path
    epg_title = ""  # Could pass from EPG if available
    output_path = recorder.build_output_path(
        save_path=rec["save_path"],
        show_name=rec["show_name"],
        season=rec["season"],
        episode=rec["episode"],
        quality=rec["quality"],
        title=epg_title,
    )

    db.update_recording_status(rec_id, "recording", output_path)

    try:
        recorder.start_recording(
            recording_id=rec_id,
            stream_url=stream_url,
            output_path=output_path,
            duration_seconds=duration_secs,
            quality=rec["quality"],
        )
        # Schedule a follow-up to mark completion
        if duration_secs:
            run_at = datetime.now(UTC) + timedelta(seconds=duration_secs + 60)
            scheduler.add_job(
                _finish_recording,
                trigger=DateTrigger(run_date=run_at),
                args=[rec_id],
                id=f"finish_{rec_id}",
                replace_existing=True,
            )
    except Exception as e:
        logger.error(f"Failed to start recording {rec_id}: {e}")
        db.update_recording_status(rec_id, "failed")


def _finish_recording(rec_id: str):
    """Called after the expected end time to clean up."""
    recorder.stop_recording(rec_id)
    rec = db.get_recording(rec_id)
    if rec and rec["status"] == "recording":
        db.update_recording_status(rec_id, "completed")

    # For recurring recordings, update episode counter
    if rec and rec.get("recurrence"):
        next_ep = rec["episode"] + 1
        db.update_recording_episode(rec_id, next_ep)
        logger.info(f"Recurring recording {rec_id} — next episode will be {next_ep}")



def _schedule_recording(rec: dict):
    """Register a recording with APScheduler."""
    rec_id        = rec["id"]
    padding_start = int(rec.get("padding_start") or 0)

    start_dt = dateutil_parser.parse(rec["start_time"])
    if start_dt.tzinfo is None:
        start_dt = UK_TZ.localize(start_dt)

    # Fire the job early so the pre-roll padding is captured
    trigger_dt = start_dt - timedelta(minutes=padding_start)

    recurrence = rec.get("recurrence")

    if recurrence:
        # For recurring jobs the cron time already encodes the user's desired
        # start; shift it back by padding_start so FFmpeg rolls early.
        trigger = _build_cron_trigger(recurrence, offset_minutes=-padding_start)
        scheduler.add_job(
            _do_recording,
            trigger=trigger,
            args=[rec_id],
            id=f"rec_{rec_id}",
            replace_existing=True,
            misfire_grace_time=300,
        )
    else:
        # One-time recording
        if trigger_dt < datetime.now(UK_TZ):
            logger.warning(f"Recording {rec_id} trigger time is in the past, skipping")
            return
        scheduler.add_job(
            _do_recording,
            trigger=DateTrigger(run_date=trigger_dt),
            args=[rec_id],
            id=f"rec_{rec_id}",
            replace_existing=True,
            misfire_grace_time=300,
        )


def _build_cron_trigger(recurrence: dict, offset_minutes: int = 0) -> CronTrigger:
    """Convert a recurrence dict to an APScheduler CronTrigger.
    offset_minutes shifts the fire time (negative = earlier)."""
    pattern  = recurrence.get("pattern", "weekly")
    time_str = recurrence.get("time", "21:00")
    total_minutes = sum(x * y for x, y in zip(map(int, time_str.split(":")), [60, 1]))
    total_minutes += offset_minutes
    # Normalise into 0-1439 range
    total_minutes %= 1440
    hour, minute = divmod(total_minutes, 60)

    if pattern == "daily":
        return CronTrigger(hour=hour, minute=minute, timezone=UK_TZ)
    elif pattern == "weekly":
        dow = recurrence.get("day_of_week", 0)  # 0=Mon … 6=Sun
        return CronTrigger(day_of_week=dow, hour=hour, minute=minute, timezone=UK_TZ)
    elif pattern == "weekdays":
        return CronTrigger(day_of_week="mon-fri", hour=hour, minute=minute, timezone=UK_TZ)
    elif pattern == "weekends":
        return CronTrigger(day_of_week="sat,sun", hour=hour, minute=minute, timezone=UK_TZ)
    else:
        return CronTrigger(hour=hour, minute=minute, timezone=UK_TZ)


# ─── API routes: settings ─────────────────────────────────────────────────────

@app.errorhandler(Exception)
def handle_exception(e):
    """Always return JSON errors so fetch() never receives unexpected HTML."""
    from werkzeug.exceptions import HTTPException
    if isinstance(e, HTTPException):
        return jsonify({"error": e.description}), e.code
    logger.exception("Unhandled exception in request handler")
    return jsonify({"error": str(e)}), 500


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/settings", methods=["GET"])
def api_get_settings():
    settings = db.get_settings()
    # Don't send password in plaintext — just indicate it's set
    safe = dict(settings)
    safe["xtream_password_set"] = bool(safe.get("xtream_password"))
    safe.pop("xtream_password", None)
    return jsonify(safe)


@app.route("/api/settings", methods=["POST"])
def api_save_settings():
    data = request.get_json(force=True, silent=True) or {}
    allowed = {
        "xtream_host", "xtream_username", "xtream_password",
        "default_save_path", "default_quality", "setup_complete",
    }
    updates = {k: v for k, v in data.items() if k in allowed}

    # Don't overwrite password if blank (frontend sends empty when unchanged)
    if "xtream_password" in updates and not updates["xtream_password"]:
        del updates["xtream_password"]

    db.save_settings(updates)
    refresh_xtream_client()
    return jsonify({"ok": True})


@app.route("/api/settings/test", methods=["POST"])
def api_test_connection():
    data = request.get_json(force=True, silent=True) or {}
    host = data.get("host", "").strip()
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()
    if not host or not username or not password:
        return jsonify({"ok": False, "detail": "Host, username and password are all required"}), 400
    client = XtreamClient(host, username, password)
    ok, result = client.test_connection()
    return jsonify({"ok": ok, "detail": result})


# ─── API routes: channels ─────────────────────────────────────────────────────

@app.route("/api/channels")
def api_channels():
    force = request.args.get("refresh") == "1"
    groups = get_channel_groups(force_refresh=force)
    return jsonify(groups)


@app.route("/api/channels/refresh", methods=["POST"])
def api_channels_refresh():
    groups = get_channel_groups(force_refresh=True)
    return jsonify({"ok": True, "count": len(groups)})


# ─── API routes: EPG ──────────────────────────────────────────────────────────

@app.route("/api/epg/<int:stream_id>")
def api_epg_single(stream_id: int):
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    limit = int(request.args.get("limit", 20))
    entries = client.get_epg_for_stream(stream_id, limit=limit)
    return jsonify(entries)


@app.route("/api/epg/bulk", methods=["POST"])
def api_epg_bulk():
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503

    data  = request.get_json(force=True, silent=True) or {}
    limit = int(data.get("limit", 10))

    # Accept either new format {channels:[{stream_id, epg_channel_id}]}
    # or legacy format {stream_ids:[...]}
    channels = data.get("channels", [])
    if not channels:
        for sid in data.get("stream_ids", []):
            channels.append({"stream_id": sid, "epg_channel_id": ""})
    if len(channels) > 100:
        channels = channels[:100]

    result: dict = {}
    need_json_api: list = []

    with _xmltv_cache_lock:
        xmltv = _xmltv_cache  # snapshot reference under lock

    for ch in channels:
        sid    = str(ch["stream_id"])
        epg_id = (ch.get("epg_channel_id") or "").strip()

        if epg_id and epg_id in xmltv:
            # Serve from XMLTV cache; sort by start time and cap at limit
            entries = sorted(
                (e for e in xmltv[epg_id] if e.get("start")),
                key=lambda x: x["start"],
            )
            result[sid] = entries[:limit]
        else:
            need_json_api.append(int(ch["stream_id"]))

    # Fall back to the JSON API for any channels not covered by XMLTV
    if need_json_api:
        try:
            json_result = client.get_epg_bulk(need_json_api, limit=limit)
            result.update(json_result)
        except Exception as e:
            logger.warning(f"JSON EPG fallback failed: {e}")

    return jsonify(result)


@app.route("/api/epg/xmltv/refresh", methods=["POST"])
def api_xmltv_refresh():
    global _xmltv_cache, _xmltv_last_fetch
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    try:
        data = client.fetch_epg_xmltv()
        with _xmltv_cache_lock:
            _xmltv_cache = data
            _xmltv_last_fetch = datetime.now(UTC)
        return jsonify({"ok": True, "channels": len(data)})
    except Exception as e:
        logger.error(f"XMLTV refresh failed: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/epg/xmltv/status", methods=["GET"])
def api_xmltv_status():
    with _xmltv_cache_lock:
        loaded      = bool(_xmltv_cache)
        num_channels = len(_xmltv_cache)
        last_fetch  = _xmltv_last_fetch
    return jsonify({
        "loaded":    loaded,
        "channels":  num_channels,
        "last_fetch": last_fetch.isoformat() if last_fetch else None,
    })


# ─── API routes: streaming ────────────────────────────────────────────────────

@app.route("/api/stream/url/<int:stream_id>")
def api_stream_url(stream_id: int):
    client = get_xtream_client()
    if not client:
        return jsonify({"error": "Not configured"}), 503
    url = client.get_stream_url(stream_id)
    return jsonify({"url": url, "stream_id": stream_id})


@app.route("/api/hls/<int:stream_id>.m3u8")
def api_hls_proxy(stream_id: int):
    """
    Proxy the HLS master playlist from the XTream server, rewriting all
    absolute segment/sub-playlist URLs to go through our local proxy.
    This avoids browser CORS issues.
    """
    client = get_xtream_client()
    if not client:
        return Response("Not configured", status=503)

    remote_url = client.get_stream_url(stream_id, fmt="m3u8")
    try:
        resp = requests.get(remote_url, timeout=10, headers={"User-Agent": "Mozilla/5.0"})
        resp.raise_for_status()
    except Exception as e:
        return Response(f"Error fetching stream: {e}", status=502)

    content = resp.text
    import re as _re
    content = _re.sub(
        r'(https?://[^\s\r\n]+)',
        lambda m: f"/api/hls/proxy/{stream_id}?url={requests.utils.quote(m.group(1))}",
        content
    )

    return Response(
        content,
        content_type="application/x-mpegURL",
        headers={"Access-Control-Allow-Origin": "*"},
    )


@app.route("/api/hls/proxy/<int:stream_id>")
def api_hls_segment_proxy(stream_id: int):
    """Proxy an individual HLS segment or sub-playlist."""
    target_url = request.args.get("url")
    if not target_url:
        return Response("Missing url parameter", status=400)

    try:
        resp = requests.get(
            target_url,
            stream=True,
            timeout=10,
            headers={"User-Agent": "Mozilla/5.0"},
        )
        content_type = resp.headers.get("Content-Type", "video/MP2T")

        if "mpegurl" in content_type.lower() or target_url.endswith(".m3u8"):
            # Sub-playlist — rewrite URLs too
            content = resp.text
            import re as _re
            content = _re.sub(
                r'(https?://[^\s\r\n]+)',
                lambda m: f"/api/hls/proxy/{stream_id}?url={requests.utils.quote(m.group(1))}",
                content
            )
            return Response(content, content_type="application/x-mpegURL",
                            headers={"Access-Control-Allow-Origin": "*"})

        return Response(
            resp.iter_content(chunk_size=65536),
            content_type=content_type,
            headers={"Access-Control-Allow-Origin": "*"},
        )
    except Exception as e:
        return Response(f"Proxy error: {e}", status=502)


# ─── API routes: recordings ───────────────────────────────────────────────────

@app.route("/api/recordings", methods=["GET"])
def api_list_recordings():
    recs = db.get_all_recordings()
    # Sweep completed processes
    finished = recorder.sweep_finished()
    for fid in finished:
        db.update_recording_status(fid, "completed")
    # Attach live status
    active = recorder.get_active_recordings()
    for rec in recs:
        if rec["id"] in active:
            rec["active"] = active[rec["id"]]
    return jsonify(recs)


@app.route("/api/recordings", methods=["POST"])
def api_create_recording():
    data = request.get_json(force=True, silent=True) or {}

    # Validate required fields
    required = ["channel_id", "channel_name", "show_name", "save_path",
                "start_time", "end_time"]
    missing = [f for f in required if not data.get(f)]
    if missing:
        return jsonify({"error": f"Missing fields: {', '.join(missing)}"}), 400

    settings = db.get_settings()

    rec = {
        "id": str(uuid.uuid4()),
        "type": data.get("type", "once"),
        "channel_id": str(data["channel_id"]),
        "channel_name": data["channel_name"],
        "show_name": data["show_name"],
        "season": int(data.get("season", 1)),
        "episode": int(data.get("episode", 1)),
        "save_path": data.get("save_path") or settings.get("default_save_path", ""),
        "quality": data.get("quality") or settings.get("default_quality", {}),
        "start_time": data["start_time"],
        "end_time": data["end_time"],
        "status": "recurring" if data.get("recurrence") else "scheduled",
        "recurrence": data.get("recurrence"),
        "output_file": None,
        "created_at": datetime.now(UTC).isoformat(),
        "scheduler_id": None,
        "padding_start": int(data.get("padding_start") or 0),
        "padding_end":   int(data.get("padding_end")   or 0),
    }

    db.save_recording(rec)
    _schedule_recording(rec)

    return jsonify(rec), 201


@app.route("/api/recordings/<rec_id>", methods=["GET"])
def api_get_recording(rec_id: str):
    rec = db.get_recording(rec_id)
    if not rec:
        return jsonify({"error": "Not found"}), 404
    return jsonify(rec)


@app.route("/api/recordings/<rec_id>", methods=["PUT"])
def api_update_recording(rec_id: str):
    rec = db.get_recording(rec_id)
    if not rec:
        return jsonify({"error": "Not found"}), 404

    data = request.get_json(force=True, silent=True) or {}
    updatable = ["show_name", "season", "episode", "save_path", "quality",
                 "start_time", "end_time", "recurrence", "type",
                 "padding_start", "padding_end"]
    for field in updatable:
        if field in data:
            rec[field] = data[field]

    # Coerce padding to int
    rec["padding_start"] = int(rec.get("padding_start") or 0)
    rec["padding_end"]   = int(rec.get("padding_end")   or 0)

    # Update status to match type
    if data.get("recurrence"):
        rec["status"] = "recurring"
    elif rec.get("status") in ("recurring",):
        rec["status"] = "scheduled"

    # Re-schedule if times changed
    try:
        scheduler.remove_job(f"rec_{rec_id}")
    except Exception:
        pass

    db.save_recording(rec)
    _schedule_recording(rec)

    return jsonify(rec)


@app.route("/api/recordings/<rec_id>", methods=["DELETE"])
def api_delete_recording(rec_id: str):
    rec = db.get_recording(rec_id)
    if not rec:
        return jsonify({"error": "Not found"}), 404

    # Stop if active
    recorder.stop_recording(rec_id)

    # Remove scheduler job
    try:
        scheduler.remove_job(f"rec_{rec_id}")
    except Exception:
        pass

    db.delete_recording(rec_id)
    return jsonify({"ok": True})


@app.route("/api/recordings/<rec_id>/stop", methods=["POST"])
def api_stop_recording(rec_id: str):
    stopped = recorder.stop_recording(rec_id)
    if stopped:
        db.update_recording_status(rec_id, "completed")
    return jsonify({"ok": stopped})


@app.route("/api/launch-installer")
def api_launch_installer():
    """Open the installer script in Terminal, then shut down this process."""
    import subprocess, signal, os as _os
    installer = _os.path.join(_os.path.dirname(__file__), "Install IPTV Manager.command")
    if _os.path.exists(installer):
        subprocess.Popen(["open", installer])
    # Shut down: give the browser a moment to receive the redirect first
    def _shutdown():
        import time as _time
        _time.sleep(1.5)
        _os.kill(_os.getpid(), signal.SIGTERM)
    threading.Thread(target=_shutdown, daemon=True).start()
    return """<!doctype html><html><head>
      <meta http-equiv="refresh" content="2;url=http://localhost:5001">
      <style>body{font-family:sans-serif;background:#0d0d0f;color:#aaa;
        display:flex;align-items:center;justify-content:center;height:100vh;margin:0;}
      </style></head><body>
      <p>Launching installer… IPTV Manager will restart when installation is complete.</p>
      </body></html>"""


@app.route("/api/update/check")
def api_update_check():
    try:
        resp = requests.get(UPDATE_CSV_URL, timeout=10)
        resp.raise_for_status()
        lines = [l.strip() for l in resp.text.splitlines() if l.strip()]
        data_lines = [l for l in lines if l and l[0].isdigit()]
        if not data_lines:
            return jsonify({"update_available": False, "current_version": APP_VERSION})
        parts    = [p.strip() for p in data_lines[0].split(",")]
        latest   = parts[0] if len(parts) > 0 else ""
        filename = parts[3] if len(parts) > 3 else ""
        dl_url   = f"https://tobyjones.ca/software/downloads/{filename}" if filename else ""
        current_major = _parse_version(APP_VERSION)[0]
        latest_major  = _parse_version(latest)[0]
        return jsonify({
            "update_available": _parse_version(latest) > _parse_version(APP_VERSION),
            "current_version":  APP_VERSION,
            "latest_version":   latest,
            "download_url":     dl_url,
            "filename":         filename,
            "is_major_update":  latest_major > current_major,
        })
    except Exception as e:
        logger.warning(f"Update check failed: {e}")
        return jsonify({"update_available": False, "current_version": APP_VERSION})


@app.route("/api/update/download", methods=["POST"])
def api_update_download():
    data = request.get_json(force=True, silent=True) or {}
    download_url = data.get("download_url", "").strip()
    filename     = data.get("filename", "update.zip").strip()
    if not download_url:
        return jsonify({"error": "No download URL provided"}), 400
    try:
        resp = requests.get(download_url, timeout=120, stream=True)
        resp.raise_for_status()
        downloads_dir = os.path.expanduser("~/Downloads")
        dest = os.path.join(downloads_dir, filename)
        with open(dest, "wb") as f:
            for chunk in resp.iter_content(chunk_size=65536):
                f.write(chunk)
        return jsonify({"ok": True, "saved_to": dest})
    except Exception as e:
        logger.error(f"Update download failed: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/factory-reset", methods=["POST"])
def api_factory_reset():
    global _xtream_client, _channel_groups_cache, _xmltv_cache, _xmltv_last_fetch

    # Stop every active recording gracefully
    for rec_id in list(recorder.get_active_recordings()):
        recorder.stop_recording(rec_id)

    # Cancel all scheduled jobs
    try:
        scheduler.remove_all_jobs()
    except Exception:
        pass

    # Wipe the database
    db.reset_db()

    # Clear all in-memory caches so they don't survive the reset
    with _xtream_lock:
        _xtream_client = None
    with _channel_groups_lock:
        _channel_groups_cache = None
    with _xmltv_cache_lock:
        _xmltv_cache = {}
        _xmltv_last_fetch = None

    # Delete the on-disk channel cache
    clear_channel_cache()

    logger.info("Factory reset complete")
    return jsonify({"ok": True})


@app.route("/api/recordings/active")
def api_active_recordings():
    active = recorder.get_active_recordings()
    return jsonify(active)


# ─── Startup ──────────────────────────────────────────────────────────────────

def restore_scheduled_recordings():
    """On startup, re-register any scheduled/recurring recordings in APScheduler."""
    for rec in db.get_recordings_by_status("scheduled"):
        try:
            _schedule_recording(rec)
        except Exception as e:
            logger.warning(f"Could not restore schedule for {rec['id']}: {e}")

    for rec in db.get_recordings_by_status("recurring"):
        try:
            _schedule_recording(rec)
        except Exception as e:
            logger.warning(f"Could not restore recurring for {rec['id']}: {e}")

    # Mark any recordings that were "recording" when the app crashed
    for rec in db.get_recordings_by_status("recording"):
        db.update_recording_status(rec["id"], "failed")


def open_browser():
    import time
    time.sleep(1.5)
    webbrowser.open("http://localhost:5001")


if __name__ == "__main__":
    db.init_db()
    scheduler.start()
    restore_scheduled_recordings()

    # Pre-load channel cache from disk (non-blocking)
    cached = load_channel_cache()
    if cached:
        with _channel_groups_lock:
            _channel_groups_cache = cached
        logger.info(f"Loaded {len(cached)} channel groups from disk cache")

    # Open browser in background thread
    threading.Thread(target=open_browser, daemon=True).start()

    print("\n" + "═" * 50)
    print("  IPTV Manager")
    print("  http://localhost:5001")
    print("  Press Ctrl+C to stop")
    print("═" * 50 + "\n")

    app.run(host="0.0.0.0", port=5001, debug=False, use_reloader=False)
