"""
FFmpeg recording manager.

Each recording is managed by a watchdog thread that:
  - Launches FFmpeg for the current remaining duration.
  - If FFmpeg exits before the expected end time, restarts it automatically.
  - Collects all segment files and stitches them together at the end.

This means a dropped stream or transient FFmpeg crash will not cut a recording
short — the watchdog picks up where it left off.
"""
import logging
import os
import re
import subprocess
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path

import pytz

logger = logging.getLogger(__name__)
UK_TZ = pytz.timezone("Europe/London")

# Global registry: rec_id → info dict
_active: dict = {}
_lock = threading.Lock()

# How long to wait before restarting after an unexpected FFmpeg exit
_RESTART_DELAY = 3  # seconds
# Minimum remaining duration (seconds) worth restarting for
_MIN_REMAINING = 5


# ─── Public API ───────────────────────────────────────────────────────────────

def start_recording(
    recording_id: str,
    stream_url: str,
    output_path: str,
    duration_seconds,
    quality: dict,
) -> int:
    """Start a recording. Returns immediately; a watchdog thread handles the rest."""
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    stop_event  = threading.Event()
    expected_end = time.monotonic() + duration_seconds if duration_seconds else None

    with _lock:
        _active[recording_id] = {
            "current_process": None,
            "pid":             None,
            "output_path":     str(out),
            "started_at":      datetime.now(UK_TZ).isoformat(),
            "stop_event":      stop_event,
            "running":         True,
        }

    t = threading.Thread(
        target=_watchdog,
        args=[recording_id, stream_url, str(out), expected_end, quality],
        daemon=True,
        name=f"rec-{recording_id[:8]}",
    )
    t.start()
    return 0  # PID is not known until the watchdog launches FFmpeg


def stop_recording(recording_id: str) -> bool:
    """Gracefully stop an active recording."""
    with _lock:
        info = _active.get(recording_id)
    if not info:
        return False

    info["stop_event"].set()

    proc = info.get("current_process")
    if proc and proc.poll() is None:
        try:
            proc.stdin.write("q")
            proc.stdin.flush()
            proc.wait(timeout=8)
        except Exception:
            pass
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
    return True


def is_recording_active(recording_id: str) -> bool:
    with _lock:
        info = _active.get(recording_id)
    return bool(info and info.get("running"))


def get_active_recordings() -> dict:
    with _lock:
        result = {}
        for rec_id, info in _active.items():
            if info.get("running"):
                proc = info.get("current_process")
                result[rec_id] = {
                    "pid":         info.get("pid"),
                    "output_path": info["output_path"],
                    "started_at":  info["started_at"],
                    "running":     proc is not None and proc.poll() is None,
                }
        return result


def sweep_finished() -> list:
    """Remove finished recordings from the registry; return their IDs."""
    with _lock:
        done = [rid for rid, i in _active.items() if not i.get("running", True)]
        for rid in done:
            del _active[rid]
    return done


# ─── Watchdog ─────────────────────────────────────────────────────────────────

def _watchdog(
    recording_id: str,
    stream_url: str,
    output_path: str,
    expected_end,        # time.monotonic() deadline, or None for open-ended
    quality: dict,
):
    """
    Manage one recording session end-to-end:
      1. Launch FFmpeg for the remaining duration.
      2. If it exits early and time remains, restart.
      3. On completion (or stop signal), stitch segments → final output file.
    """
    logger.info(f"Recording {recording_id}: _watchdog started, quality={quality}")

    with _lock:
        info = _active.get(recording_id)
    if not info:
        return

    stop_event = info["stop_event"]
    out        = Path(output_path)
    segments   = []
    seg_idx    = 0

    try:
        while not stop_event.is_set():
            # How long should this segment run?
            if expected_end is not None:
                remaining = expected_end - time.monotonic()
                if remaining < _MIN_REMAINING:
                    break
            else:
                remaining = None

            seg_path = str(out.parent / f".{out.stem}.part{seg_idx:03d}{out.suffix}")
            log_path = str(out) + ".ffmpeg.log"
            cmd      = _build_command(stream_url, seg_path, remaining, quality)

            logger.info(
                "Recording %s: starting segment %d, cmd: %s",
                recording_id, seg_idx, " ".join(cmd),
            )

            # Redirect FFmpeg output to log file
            log_file = open(log_path, "a")
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=log_file,
            )
            # Store the log file handle to close it later
            process._log_file = log_file

            with _lock:
                if recording_id in _active:
                    _active[recording_id]["current_process"] = process
                    _active[recording_id]["pid"]             = process.pid

            process.wait()

            # Close the log file
            if hasattr(process, '_log_file'):
                process._log_file.close()

            logger.info(
                "Recording %s: segment %d exited with code %d",
                recording_id, seg_idx, process.returncode,
            )

            # Keep segment if it has real content
            seg_size = os.path.getsize(seg_path) if os.path.exists(seg_path) else 0
            if seg_size > 1024:
                segments.append(seg_path)
                logger.info(
                    "Recording %s: segment %d saved (%d MB)",
                    recording_id, seg_idx, seg_size // (1024 * 1024),
                )
            else:
                logger.warning(
                    "Recording %s: segment %d is empty — skipping", recording_id, seg_idx
                )

            if stop_event.is_set():
                break

            # Check whether there is meaningful time left
            if expected_end is not None:
                remaining = expected_end - time.monotonic()
                if remaining < _MIN_REMAINING:
                    break
                # FFmpeg exited before we expected — restart after a short pause
                logger.warning(
                    "Recording %s: FFmpeg exited early — restarting in %ds "
                    "(%.0fs remaining)",
                    recording_id, _RESTART_DELAY, remaining,
                )
                stop_event.wait(_RESTART_DELAY)
            else:
                break   # No time limit: treat FFmpeg exit as natural completion

            seg_idx += 1

    except Exception:
        logger.exception("Recording %s: watchdog error", recording_id)
    finally:
        _finalize(recording_id, output_path, segments)
        with _lock:
            if recording_id in _active:
                _active[recording_id]["running"] = False


def _finalize(recording_id: str, output_path: str, segments: list):
    """Rename a single segment or stitch multiple segments into output_path."""
    valid = [s for s in segments if os.path.exists(s) and os.path.getsize(s) > 1024]

    if not valid:
        logger.warning("Recording %s: no valid segments — nothing to save", recording_id)
        return

    if len(valid) == 1:
        try:
            os.replace(valid[0], output_path)
            logger.info("Recording %s: saved → %s", recording_id, output_path)
        except Exception:
            logger.exception("Recording %s: could not rename segment", recording_id)
        return

    # Multiple segments — stitch with FFmpeg concat demuxer
    logger.info(
        "Recording %s: stitching %d segments → %s",
        recording_id, len(valid), output_path,
    )
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        concat_path = f.name
        for seg in valid:
            f.write(f"file '{seg}'\n")

    try:
        cmd = [
            "ffmpeg", "-y", "-loglevel", "error",
            "-f", "concat", "-safe", "0",
            "-i", concat_path,
            "-c", "copy",
            output_path,
        ]
        r = subprocess.run(cmd, capture_output=True, timeout=7200)
        if r.returncode == 0:
            logger.info("Recording %s: stitch complete", recording_id)
            for seg in valid:
                try:
                    os.remove(seg)
                except Exception:
                    pass
        else:
            logger.error(
                "Recording %s: stitch failed — %s",
                recording_id,
                r.stderr.decode(errors="replace")[:300],
            )
    finally:
        try:
            os.unlink(concat_path)
        except Exception:
            pass


# ─── Output path builder ──────────────────────────────────────────────────────

def build_output_path(
    save_path: str,
    show_name: str,
    season: int,
    episode: int,
    quality: dict,
    title: str = "",
) -> str:
    """
    Construct the output file path.  Season and episode are optional — pass 0
    (or None) to omit them.

    Examples:
      season=1, episode=3  → Show/Season 1/Show Name - S01E03.mkv
      season=0, episode=3  → Show/Show Name - E03.mkv
      season=0, episode=0  → Show/Show Name.mkv   (one-off / custom name)
    """
    # Handle None quality (use defaults)
    if quality is None:
        quality = {}

    container = quality.get("container", "mkv")
    codec     = quality.get("codec", "copy")
    ext       = "ts" if codec == "copy" else container
    safe_show = _safe_filename(show_name)
    safe_title = _safe_filename(title) if title else ""

    has_season  = bool(season)
    has_episode = bool(episode)

    # Build the episode tag
    if has_season and has_episode:
        ep_tag = f"S{int(season):02d}E{int(episode):02d}"
    elif has_episode:
        ep_tag = f"E{int(episode):02d}"
    else:
        ep_tag = ""

    # Build filename
    parts = [safe_show]
    if ep_tag:
        parts.append(ep_tag)
    if safe_title:
        parts.append(safe_title)
    filename = " - ".join(parts) + "." + ext

    # Build directory structure
    base = Path(save_path) / safe_show
    if has_season:
        return str(base / f"Season {int(season)}" / filename)
    else:
        return str(base / filename)


def _safe_filename(name: str) -> str:
    """Strip characters not safe in filenames."""
    return re.sub(r'[<>:"/\\|?*]', "", name).strip()


# ─── FFmpeg command builder ───────────────────────────────────────────────────

def _build_command(
    stream_url: str,
    output_path: str,
    duration_seconds,
    quality: dict,
) -> list:
    # Handle None quality (use defaults)
    if quality is None:
        quality = {}

    # Default recording codec (copy = no re-encode)
    codec       = quality.get("codec", "copy")
    resolution  = quality.get("resolution", "original")
    crf         = int(quality.get("transcode_crf", quality.get("crf", 28)))
    preset      = quality.get("transcode_preset", quality.get("preset", "medium"))
    audio_codec = quality.get("transcode_audio_codec", quality.get("audio_codec", "aac"))
    audio_bitrate = quality.get("transcode_audio_bitrate", quality.get("audio_bitrate", "128k"))

    cmd = [
        "ffmpeg", "-y",
        "-loglevel", "warning",
        "-stats",
        "-i", stream_url,
    ]

    if duration_seconds:
        cmd += ["-t", str(int(duration_seconds))]

    # ── Video ──
    if codec == "copy":
        cmd += ["-c:v", "copy"]
    else:
        if codec == "hevc":
            cmd += ["-c:v", "libx265", "-crf", str(crf), "-preset", preset]
        else:
            cmd += ["-c:v", "libx264", "-crf", str(crf), "-preset", preset]

        if resolution and resolution != "original":
            w, h = resolution.split("x")
            cmd += ["-vf", (
                f"scale={w}:{h}:force_original_aspect_ratio=decrease,"
                f"pad={w}:{h}:(ow-iw)/2:(oh-ih)/2"
            )]

    # ── Audio ──
    if codec == "copy" or audio_codec == "copy":
        cmd += ["-c:a", "copy"]
    else:
        # Handle bitrate - add 'k' if not present and not 'copy'
        if audio_bitrate != "copy" and not audio_bitrate.endswith('k'):
            audio_bitrate = audio_bitrate + 'k'
        if audio_bitrate != "copy":
            cmd += ["-c:a", audio_codec, "-b:a", audio_bitrate]
        else:
            cmd += ["-c:a", "copy"]

    cmd.append(output_path)
    return cmd

# ── FTP Upload ─────────────────────────────────────────────────────

def upload_to_ftp(local_path: str, remote_path: str, ftp_settings: dict) -> bool:
    """Upload a file to FTP server. Returns True on success."""
    try:
        from ftplib import FTP
        import os

        host = ftp_settings.get("ftp_host", "")
        port = int(ftp_settings.get("ftp_port", 21))
        username = ftp_settings.get("ftp_username", "")
        password = ftp_settings.get("ftp_password", "")

        if not host:
            logger.warning("FTP upload skipped: no host configured")
            return False

        logger.info(f"FTP upload starting: {local_path} → {remote_path}")
        ftp = FTP()
        ftp.connect(host, port)
        ftp.login(username, password)

        # Create remote directory if needed
        remote_dir = os.path.dirname(remote_path)
        if remote_dir and remote_dir != "/":
            _ftp_makedirs(ftp, remote_dir)

        # Upload file - use full remote path
        with open(local_path, 'rb') as f:
            ftp.storbinary(f"STOR {remote_path}", f)

        ftp.quit()
        logger.info(f"FTP upload complete: {remote_path}")
        return True

    except Exception as e:
        logger.error(f"FTP upload failed: {e}")
        return False


def _ftp_makedirs(ftp, path: str):
    """Create FTP directory recursively."""
    dirs = []
    while path and path != "/":
        dirs.append(path)
        path = os.path.dirname(path)

    for dir in reversed(dirs):
        try:
            ftp.mkd(dir)
        except Exception:
            pass  # Directory may already exist


def upload_recording(recording_id: str, output_path: str, show_name: str,
                       season: int = 0, episode: int = 0,
                       ftp_path_type: str = None, ftp_custom_path: str = None) -> bool:
    """Upload a completed recording to FTP based on settings."""
    try:
        import database as db
        settings = db.get_settings()

        if not settings.get("ftp_enabled"):
            return False

        # Check if FTP is disabled for this recording
        if ftp_path_type == 'disabled':
            return False

        ftp_settings = {
            "ftp_host": settings.get("ftp_host", ""),
            "ftp_port": settings.get("ftp_port", 21),
            "ftp_username": settings.get("ftp_username", ""),
            "ftp_password": settings.get("ftp_password", ""),
        }

        # Determine remote path based on per-recording setting or show type
        if ftp_path_type and ftp_path_type != 'default':
            if ftp_path_type == 'custom' and ftp_custom_path:
                remote_dir = ftp_custom_path
            elif ftp_path_type == 'films':
                remote_dir = settings.get("ftp_path_films", "")
            elif ftp_path_type == 'tv':
                remote_dir = settings.get("ftp_path_tv", "")
            else:  # misc or any other fallback
                remote_dir = settings.get("ftp_path_misc", "")
        else:
            # Use default logic based on show type
            if season > 0:
                # TV Show - use TV path with season folder
                tv_path = settings.get("ftp_path_tv", "")
                if not tv_path:
                    tv_path = settings.get("ftp_path_films", "")
                remote_dir = f"{tv_path}/{show_name}/Season {season}" if season else f"{tv_path}/{show_name}"
            elif episode > 0:
                # TV Show without season
                tv_path = settings.get("ftp_path_tv", "")
                if not tv_path:
                    tv_path = settings.get("ftp_path_films", "")
                remote_dir = f"{tv_path}/{show_name}"
            else:
                # Film or miscellaneous - put directly in the base path, no subfolder
                films_path = settings.get("ftp_path_films", "")
                misc_path = settings.get("ftp_path_misc", "")
                remote_dir = films_path if films_path else misc_path

        # Strip " - transcoded" from filename if present
        basename = os.path.basename(output_path)
        if basename.endswith(" - transcoded.mkv"):
            basename = basename.replace(" - transcoded", "")
        remote_path = f"{remote_dir}/{basename}"

        success = upload_to_ftp(output_path, remote_path, ftp_settings)

        return success

    except Exception as e:
        logger.error(f"FTP upload_recording failed: {e}")
        return False
